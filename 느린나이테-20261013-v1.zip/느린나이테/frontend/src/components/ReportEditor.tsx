import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../api";
import { attempt } from "../notify";
import { dropDraft, loadDraft, useDraftKeeper, useUnsaved } from "../unsaved";
import { filesBase, renderMarkdown } from "../markdown";
import { copyAsExcelCell, copyAsPlainText, toPlainText } from "../plaintext";
import type { Report } from "../types";
import type { Attachment } from "../upload";
import { formatBytes, formatRate, uploadAttachment } from "../upload";
import PasteOfferBar from "./PasteOffer";
import { type PasteOffer, handleEditorPaste, spliceAtCaret } from "../table";
import { scrollEditorIntoView } from "../util";
import AttachmentList from "./AttachmentList";
import XlsxPreview from "./XlsxPreview";
import PreviewToggle, { usePreview } from "./PreviewToggle";
import AiPromptPanel from "./AiPromptPanel";
import ReportDiff from "./ReportDiff";
import VersionPanel from "./VersionPanel";

interface UploadState {
  key: string;
  name: string;
  loaded: number;
  total: number;
  startedAt: number;
  abort: () => void;
  error?: string;
}

interface Props {
  report: Report;
  dirName?: string;
  /** 피보고자 자동완성 목록 */
  audiences: string[];
  onChanged: () => void;
  onClose: () => void;
  /** 지워졌을 때. onChanged 와 나눠 둔 이유는 아래 [삭제] 주석 참고. */
  onDeleted: () => void;
  /** 이 문서의 vault 기준 경로. 있으면 [이전 버전]을 열 수 있다 (TODO 37-1). */
  docPath?: string;
}

export default function ReportEditor({ report, dirName, audiences, onChanged, onClose, onDeleted, docPath }: Props) {
  const [showVersions, setShowVersions] = useState(false);
  const [body, setBody] = useState(report.body ?? "");
  const [audience, setAudience] = useState(report.audience ?? "");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploads, setUploads] = useState<UploadState[]>([]);
  const [previewing, setPreviewing] = useState<Attachment | null>(null);
  // 보고일. 초안일 때만 고칠 수 있다 — 확정된 보고의 날짜는 "언제 보고했는가"라는 사실이다.
  const [reportDate, setReportDate] = useState(report.report_date);
  // 보고 자리에서 받은 지시 (TODO 107). 확정된 보고에만 적고, 본문과 따로 저장한다.
  const [feedback, setFeedback] = useState(report.feedback ?? "");
  const [feedbackDirty, setFeedbackDirty] = useState(false);
  const [preview, togglePreview] = usePreview();
  // "지난주와 뭐가 달라졌나" — 보고 자리에서 가장 많이 받는 질문이다.
  const [showDiff, setShowDiff] = useState(false);
  // AI 에게 넘길 글. 곧바로 복사하지 않고 **먼저 보여 준다** (TODO 71).
  const [showPrompt, setShowPrompt] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [pasteOffer, setPasteOffer] = useState<PasteOffer | null>(null);
  const closeOffer = useCallback(() => setPasteOffer(null), []);

  // 보고 문서를 열면 좌측 칸이 맨 위로 올라온다. 문서가 있는 자리로 데려간다.
  useEffect(() => scrollEditorIntoView(rootRef.current), []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const base = filesBase(dirName, report.doc_dir);
  const frozen = report.frozen;

  const refresh = useCallback(() => {
    api.listReportAttachments(report.id).then(setAttachments).catch(() => undefined);
  }, [report.id]);

  useEffect(refresh, [refresh]);
  useEffect(() => setBody(report.body ?? ""), [report.id, report.body]);
  // 쓰던 보고 — 떠날 때 묻고, 임시 보관한다 (TODO 162). 확정된 보고는 본문을 고칠 수 없으니 빼고.
  const draftKey = `report:${report.id}`;
  const [restored, setRestored] = useState(false);
  useUnsaved(draftKey, !frozen && (dirty || feedbackDirty));
  useDraftKeeper(frozen ? null : draftKey, body, body === (report.body ?? ""));
  useEffect(() => {
    if (frozen) return;
    let alive = true;
    const original = report.body ?? "";
    void loadDraft<string>(draftKey, (content) => content === original).then((kept) => {
      if (!alive || typeof kept !== "string") return;
      setBody(kept);
      setDirty(true);
      setRestored(true);
    });
    return () => {
      alive = false;
    };
    // 문서를 바꿔 열 때만 — 저장해서 본문이 바뀐 것은 되살릴 일이 아니다
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [report.id]);
  useEffect(() => setAudience(report.audience ?? ""), [report.id, report.audience]);
  useEffect(() => setReportDate(report.report_date), [report.id, report.report_date]);
  useEffect(() => {
    setFeedback(report.feedback ?? "");
    setFeedbackDirty(false);
  }, [report.id, report.feedback]);

  async function save(): Promise<void> {
    // 보고일은 초안일 때만 보낸다. 바뀌면 서버가 문서 폴더도 함께 옮긴다.
    await api.updateReport(report.id, {
      body,
      audience,
      ...(frozen ? {} : { report_date: reportDate }),
    });
    setDirty(false);
    onChanged();
  }

  /** 초안에 딸려 온 "진행 내용"만 지우고 보고서 뼈대는 남긴다. */
  function clearProgressSection() {
    if (!window.confirm("초안에 붙어 온 '진행 내용'을 지울까요? 요약·특이사항·다음 계획은 남습니다.")) {
      return;
    }
    setBody((prev) => {
      const start = prev.indexOf("## 진행 내용");
      if (start < 0) return prev;
      const rest = prev.slice(start + 1);
      const nextHeading = rest.indexOf("\n## ");
      return nextHeading < 0 ? prev.slice(0, start).trimEnd() + "\n" : prev.slice(0, start) + rest.slice(nextHeading + 1);
    });
    setDirty(true);
  }

  function insertAtCursor(snippet: string) {
    const textarea = textareaRef.current;
    const start = textarea ? textarea.selectionStart : body.length;
    setBody((prev) => `${prev.slice(0, start)}\n${snippet}\n${prev.slice(start)}`);
    setDirty(true);
  }

  async function handleFiles(files: File[]) {
    for (const file of files) {
      const key = `${file.name}-${Date.now()}`;
      const handle = uploadAttachment(`/api/reports/${report.id}/attachments`, file, (loaded, total) =>
        setUploads((prev) => prev.map((item) => (item.key === key ? { ...item, loaded, total } : item))),
      );
      setUploads((prev) => [
        ...prev,
        { key, name: file.name, loaded: 0, total: file.size, startedAt: Date.now(), abort: handle.abort },
      ]);
      try {
        await handle.promise;
        setUploads((prev) => prev.filter((item) => item.key !== key));
        refresh();
      } catch (err) {
        setUploads((prev) =>
          prev.map((item) => (item.key === key ? { ...item, error: (err as Error).message } : item)),
        );
      }
    }
  }

  async function copy(kind: "excel" | "plain") {
    const text = toPlainText(body);
    try {
      if (kind === "excel") await copyAsExcelCell(text);
      else await copyAsPlainText(text);
      setNotice(kind === "excel" ? "엑셀 한 칸에 붙여넣을 수 있게 복사했습니다." : "평문으로 복사했습니다.");
      window.setTimeout(() => setNotice(null), 4000);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <div
      ref={rootRef}
      className={`report-editor card${frozen ? " frozen" : ""}`}
      onKeyDown={(event) => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
          event.preventDefault();
          if (!frozen) void save().catch((err: Error) => setError(err.message));
        }
      }}
      onDragOver={frozen ? undefined : (event) => event.preventDefault()}
      onDrop={
        frozen
          ? undefined
          : (event) => {
              event.preventDefault();
              void handleFiles(Array.from(event.dataTransfer.files));
            }
      }
    >
      <div className="card-head">
        <h2>
          {report.report_date} 보고
          {frozen ? (
            <span className="frozen-tag">확정됨 · 읽기 전용</span>
          ) : (
            <span className="draft-tag">작성 중</span>
          )}
        </h2>
        <div className="form-actions" style={{ margin: 0 }}>
          {!frozen && body.includes("## 진행 내용") && (
            <button data-write className="ghost" onClick={clearProgressSection}>
              진행 내용 지우기
            </button>
          )}
          <button
            className={showDiff ? "ghost on" : "ghost"}
            onClick={() => setShowDiff((prev) => !prev)}
            title="직전에 확정한 보고와 비교합니다."
          >
            지난 보고 대비
          </button>
          {/* 프롬프트는 **저장된 본문**으로 만든다(서버가 만든다). 고치던 중이면 먼저 저장해
              화면에 보이는 글과 복사되는 글이 어긋나지 않게 한다. [지난 보고 대비]와 같은 방식이다. */}
          <button
            className={showPrompt ? "ghost on" : "ghost"}
            title="AI 에게 넘길 글을 만들어 보여 줍니다. 이 도구가 AI 를 부르지는 않습니다."
            onClick={async () => {
              if (showPrompt) {
                setShowPrompt(false);
                return;
              }
              if (dirty && !frozen) {
                try {
                  await save();
                } catch (err) {
                  setError((err as Error).message);
                  return;
                }
              }
              setShowPrompt(true);
            }}
          >
            AI 요약 프롬프트
          </button>
          <button className="ghost" onClick={() => copy("excel")}>
            엑셀 셀로 복사
          </button>
          <button className="ghost" onClick={() => copy("plain")}>
            평문 복사
          </button>
          {docPath && (
            <button data-write
              className={showVersions ? "ghost on" : "ghost"}
              onClick={() => setShowVersions((prev) => !prev)}
              title="이 보고 문서의 이전 내용으로 되돌립니다."
            >
              이전 버전
            </button>
          )}
          <button className="ghost" onClick={onClose}>
            닫기
          </button>
        </div>
      </div>

      <div className="report-meta">
        <label className="report-date-field">
          보고일
          <input
            type="date"
            value={reportDate}
            disabled={frozen}
            title={frozen ? "확정된 보고의 날짜는 바꿀 수 없습니다. 확정을 풀면 고칠 수 있습니다." : undefined}
            onChange={(event) => {
              setReportDate(event.target.value);
              setDirty(true);
            }}
          />
        </label>
        <label>
          피보고자 · 회의체
          <input
            list="audience-options"
            value={audience}
            onChange={(event) => {
              setAudience(event.target.value);
              setDirty(true);
            }}
            placeholder="예: 팀장, 주간회의체"
          />
          <datalist id="audience-options">
            {audiences.map((name) => (
              <option key={name} value={name} />
            ))}
          </datalist>
        </label>
        {frozen && (
          <button
            className="ghost small"
            disabled={audience === (report.audience ?? "")}
            onClick={async () => {
              if (!(await attempt(() => api.updateReport(report.id, { audience })))) return;
              setDirty(false);
              onChanged();
            }}
          >
            피보고자만 저장
          </button>
        )}
        {/* 자동완성 목록은 칸을 눌러야 뜨고 브라우저마다 모양이 달라, 있는 줄 모르고
            매번 손으로 치게 된다. 쓰던 것을 눌러서 넣게 한다 (진행일지 태그와 같은 방식). */}
        {!frozen && audiences.length > 0 && (
          <div className="tag-suggest audience-suggest">
            <span className="muted">쓰던 피보고자</span>
            {audiences
              .filter((name) => name !== audience)
              .slice(0, 8)
              .map((name) => (
                <button
                  key={name}
                  type="button"
                  className="tag-pick"
                  onClick={() => {
                    setAudience(name);
                    setDirty(true);
                  }}
                >
                  {name}
                </button>
              ))}
          </div>
        )}

        <span className="hint">
          {report.covers_from
            ? `포함 기간 ${report.covers_from} ~ ${report.covers_to} · 진행일지 ${report.entry_count}건`
            : "포함된 진행일지가 없습니다."}
          {report.author && ` · 작성 ${report.author}`}
        </span>
      </div>

      {docPath && showVersions && <VersionPanel path={docPath} onRestored={onChanged} />}

      {showDiff && <ReportDiff reportId={report.id} />}

      {showPrompt && <AiPromptPanel reportId={report.id} />}

      {frozen ? (
        <>
          <div className="markdown snapshot" dangerouslySetInnerHTML={{ __html: renderMarkdown(body, base) }} />
          {/* 보고 결과 · 지시사항 (TODO 107). 본문은 굳었지만 "그 자리에서 무슨 말을 들었는가"는
              보고가 끝난 뒤에야 적을 수 있다. 다음 초안이 이 칸을 맨 위에 물고 나온다. */}
          <section className="feedback-box" data-testid="report-feedback">
            <div className="feedback-head">
              <b>보고 결과 · 지시사항</b>
              {report.feedback?.trim() ? (
                report.feedback_done ? (
                  <span className="feedback-state done">답변함 · {report.feedback_done}</span>
                ) : (
                  <span className="feedback-state open">답하지 않음 — 다음 초안 맨 위에 딸려 갑니다</span>
                )
              ) : (
                <span className="hint">비워 두면 아무 데도 나타나지 않습니다.</span>
              )}
            </div>
            <textarea
              className="feedback-text"
              rows={3}
              value={feedback}
              placeholder="보고 자리에서 받은 지시·질문·결정 사항"
              onChange={(event) => {
                setFeedback(event.target.value);
                setFeedbackDirty(true);
              }}
              onPaste={(event) => {
                // 지시가 엑셀 표로 오기도 한다 — 표만 받는다(첨부는 보고 자료 칸의 일) (TODO 137)
                const area = event.currentTarget;
                handleEditorPaste(event, {
                  onInsert: (text) => {
                    setFeedback((prev) => spliceAtCaret(area, prev, text));
                    setFeedbackDirty(true);
                  },
                });
              }}
            />
            <div className="form-actions feedback-actions">
              <button
                className="small"
                disabled={!feedbackDirty || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    await api.updateReport(report.id, { feedback });
                    setFeedbackDirty(false);
                    onChanged();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                지시사항 저장
              </button>
              {report.feedback?.trim() && (
                <button
                  className="ghost small"
                  disabled={busy || feedbackDirty}
                  title={feedbackDirty ? "먼저 지시사항을 저장하세요." : undefined}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await api.feedbackDone(report.id, !report.feedback_done);
                      onChanged();
                    } catch (err) {
                      setError((err as Error).message);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  {report.feedback_done ? "아직 답하지 않음으로" : "답변함"}
                </button>
              )}
            </div>
          </section>
        </>
      ) : (
        <>
        <PreviewToggle on={preview} onToggle={togglePreview} />
        <div className={preview ? "split" : "split solo"}>
          <textarea
            ref={textareaRef}
            value={body}
            onChange={(event) => {
              setBody(event.target.value);
              setDirty(true);
            }}
            onPaste={(event) =>
              // 보고 문서야말로 엑셀 표를 그대로 옮겨 오는 일이 잦다 — 표가 그림보다 먼저다 (TODO 137)
              handleEditorPaste(event, {
                onInsert: (text) => {
                  insertAtCursor(text);
                  setDirty(true);
                },
                onFiles: (files) => void handleFiles(files),
                onOffer: setPasteOffer,
              })
            }
            spellCheck={false}
          />
          {preview && (
            <div className="preview markdown" dangerouslySetInnerHTML={{ __html: renderMarkdown(body, base) }} />
          )}
        </div>
        </>
      )}

      <PasteOfferBar
        offer={pasteOffer}
        area={textareaRef.current}
        setValue={(next) => {
          setBody(next);
          setDirty(true);
        }}
        onFiles={(files) => void handleFiles(files)}
        onClose={closeOffer}
      />

      {uploads.length > 0 && (
        <ul className="uploads">
          {uploads.map((upload) => {
            const percent = upload.total ? Math.round((upload.loaded / upload.total) * 100) : 0;
            const elapsed = (Date.now() - upload.startedAt) / 1000;
            return (
              <li key={upload.key} className={upload.error ? "upload-error" : undefined}>
                <div className="upload-head">
                  <span className="upload-name">{upload.name}</span>
                  <span className="muted">
                    {upload.error
                      ? upload.error
                      : `${formatBytes(upload.loaded)} / ${formatBytes(upload.total)} · ${formatRate(
                          elapsed > 0 ? upload.loaded / elapsed : 0,
                        )}`}
                  </span>
                  {!upload.error && (
                    <button className="ghost small" onClick={upload.abort}>
                      취소
                    </button>
                  )}
                </div>
                <div className="progress">
                  <div className="progress-bar" style={{ width: `${percent}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <div className="attachment-panel">
        <div className="card-head">
          <h3>보고 자료 ({attachments.length})</h3>
          {!frozen && (
            <div className="attach-actions">
              <span className="hint">엑셀·이미지를 끌어다 놓아도 됩니다.</span>
              <button className="attach-button" onClick={() => fileInputRef.current?.click()}>
                📎 파일 첨부
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                hidden
                onChange={(event) => {
                  void handleFiles(Array.from(event.target.files ?? []));
                  event.target.value = "";
                }}
              />
            </div>
          )}
        </div>
        {/* 확정된 보고의 첨부는 지우지 않는다 — 그 문서는 "그때 무엇을 보고했는가" 다
            (본문·삭제를 막는 것과 같은 이유, TODO 103-F). 확정을 풀면 지울 수 있다. */}
        <AttachmentList
          attachments={attachments}
          onPreview={(attachment) => setPreviewing(attachment)}
          onInsert={frozen ? undefined : (attachment) => insertAtCursor(attachment.markdown)}
          onDelete={
            frozen
              ? undefined
              : async (attachment) => {
                  // 본문에서 쓰이는 중이면 그 사실을 말해 준다 (TODO 129). 막지는 않는다 —
                  // 보관함으로 가므로 되돌릴 수 있고, 막으면 급할 때 못 쓴다.
                  const stored = attachment.rel_path.split("/").pop() ?? "";
                  const used = stored !== "" && body.includes(stored);
                  const warn = used
                    ? "\n\n이 첨부는 **본문에서 쓰이는 중**입니다. 지우면 그 자리가 깨집니다."
                    : "";
                  if (!window.confirm(`${attachment.orig_name} 을(를) 삭제 보관함으로 옮길까요?${warn}`))
                    return;
                  try {
                    await api.deleteAttachment(attachment.id);
                    refresh();
                  } catch (err) {
                    setError((err as Error).message);
                  }
                }
          }
        />
      </div>

      {restored && dirty && (
        <p className="hint restored">
          저장하지 않은 작성 중 내용을 복구했습니다.{" "}
          <button
            className="ghost small"
            onClick={() => {
              dropDraft(draftKey);
              setBody(report.body ?? "");
              setDirty(false);
              setRestored(false);
            }}
          >
            복구한 내용 버리기
          </button>
        </p>
      )}
      {notice && <p className="hint notice">{notice}</p>}
      {error && <p className="form-error">{error}</p>}

      <div className="editor-footer">
        <span className="muted save-state">{dirty ? "저장 안 됨" : ""}</span>
        <div className="form-actions">
          {frozen ? (
            <button
              className="ghost"
              onClick={async () => {
                if (!window.confirm("확정을 해제하면 문서를 다시 고칠 수 있습니다. 해제할까요?")) return;
                if (await attempt(() => api.unfreezeReport(report.id))) onChanged();
              }}
            >
              확정 해제
            </button>
          ) : (
            <>
              {/* 초안을 잘못 만들었을 때 만든 자리에서 바로 지운다. 지금까지는 편집기를 닫고
                  과제 상세의 보고 이력 목록까지 가야 했다. 확정된 보고에는 두지 않는다 —
                  그 문서는 "언제 무엇을 보고했는가"라는 기록이라, 확정을 먼저 풀어야 한다. */}
              <button
                className="ghost danger"
                disabled={busy}
                onClick={async () => {
                  if (!window.confirm("이 보고 초안을 삭제 보관함으로 옮길까요?\n\n설정 → 삭제 보관함에서 되돌릴 수 있습니다."))
                    return;
                  setBusy(true);
                  try {
                    await api.deleteReport(report.id);
                    // onChanged 를 쓰면 안 된다 — 그쪽은 "바뀌었으니 이 보고를 다시 읽어라"
                    // 라는 뜻이라, 방금 지운 문서를 다시 불러 404 가 난다.
                    onDeleted();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                삭제
              </button>
              <button data-write className="ghost" disabled={busy || !dirty} onClick={() => void save()}>
                저장
              </button>
              <button
                className="commit"
                disabled={busy}
                onClick={async () => {
                  if (!window.confirm("보고를 확정하면 이 문서는 읽기 전용이 되고, 미보고 분량이 초기화됩니다.")) return;
                  setBusy(true);
                  try {
                    if (dirty) await save();
                    await api.freezeReport(report.id);
                    onChanged();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                보고 확정
              </button>
            </>
          )}
        </div>
      </div>

      {previewing && <XlsxPreview attachment={previewing} onClose={() => setPreviewing(null)} />}
    </div>
  );
}
