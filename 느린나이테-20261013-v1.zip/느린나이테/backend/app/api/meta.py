from __future__ import annotations

import sqlite3

import hashlib
import json

from fastapi import APIRouter, Depends, Request, Response

from ..config import (
    ACTIVITY_KINDS, CLASSIFICATIONS, CLASSIFIED_TYPE, COLLAPSED_STATUSES, INTAKE_STATUSES,
    STATUSES, get_settings,
)
from ..deps import get_db
from .. import share
from ..services import buildinfo
from ..services import home as home_service
from ..services import settings as settings_service
from ..vault import indexer
from ..vault.indexer import reindex_all

router = APIRouter(prefix="/api", tags=["meta"])


@router.get("/health")
def health() -> dict:
    settings = get_settings()
    return {"status": "ok", "vault": str(settings.vault_dir)}


@router.get("/meta")
def meta(request: Request, response: Response, conn: sqlite3.Connection = Depends(get_db)):
    """화면이 켤 때마다 받는 묶음(5KB). 내용이 같으면 **304** 로 답한다 — 여러 사람이 함께 볼 때 같은 5KB 를 되풀이하지 않게 (TODO 190)."""
    body = _meta(conn)
    # 읽기 전용 공유 (TODO 191 · 192) — 바깥에는 서버 폴더 경로를 주지 않고 readonly 를, 주인에게는 공유 주소와 오늘 접속 수를
    if getattr(request.state, "readonly", False):
        body["vault"] = ""
        body["readonly"] = True
        body["share"] = None
    else:
        body["readonly"] = False
        body["share"] = {"url": share.share_url(request.url.port), **share.visitors_today()} if share.enabled() else None
    tag = '"' + hashlib.sha1(json.dumps(body, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:20] + '"'
    if request.headers.get("if-none-match") == tag:
        return Response(status_code=304, headers={"ETag": tag})
    response.headers["ETag"] = tag
    return body


def _meta(conn: sqlite3.Connection) -> dict:
    groups = [
        row["grp"]
        for row in conn.execute(
            "SELECT DISTINCT grp FROM project WHERE grp IS NOT NULL AND grp <> '' ORDER BY grp"
        )
    ]
    # 태그는 **실제로 붙어 있는 것만** 준다 (TODO 96).
    #
    # `tag` 표는 한 번 쓴 이름을 지우지 않는다 — 오타로 한 번 친 태그도, 나중에 떼어 낸
    # 태그도 그대로 남는다. 그 표를 그냥 읽으면 거르기 상자에 **골라도 0건인 항목**이 선다.
    # 자동완성용(`tags`)은 과제·진행일지 어디든 붙어 있는 것, 과제 목록의 거르기 상자용
    # (`project_tags`)은 **과제에 붙어 있는 것**이다. 진행일지에만 있는 태그로 과제를
    # 거르면 늘 0건이라, 두 자리는 같은 목록일 수 없다.
    tags = [
        row["name"]
        for row in conn.execute(
            "SELECT DISTINCT t.name FROM tag t"
            " WHERE EXISTS (SELECT 1 FROM project_tag pt WHERE pt.tag_id = t.id)"
            "    OR EXISTS (SELECT 1 FROM entry_tag et WHERE et.tag_id = t.id)"
            " ORDER BY t.name"
        )
    ]
    project_tags = [
        row["name"]
        for row in conn.execute(
            "SELECT DISTINCT t.name FROM tag t"
            " JOIN project_tag pt ON pt.tag_id = t.id ORDER BY t.name"
        )
    ]
    owners = [
        row["name"]
        for row in conn.execute("SELECT DISTINCT name FROM project_owner ORDER BY name")
    ]
    # 유관부서 (TODO 92). 지금까지 적어 둔 팀·사람을 모아 자동완성과 거르기에 쓴다.
    partner_teams = [
        row["team"]
        for row in conn.execute(
            "SELECT DISTINCT team FROM project_partner WHERE team <> '' ORDER BY team"
        )
    ]
    partner_people = [
        row["person"]
        for row in conn.execute(
            "SELECT DISTINCT person FROM project_partner WHERE person <> '' ORDER BY person"
        )
    ]
    audiences = [
        row["audience"]
        for row in conn.execute(
            "SELECT DISTINCT audience FROM report WHERE audience IS NOT NULL AND audience <> ''"
            " ORDER BY audience"
        )
    ]
    return {
        "statuses": [
            {"key": key, "label": label, "candidate": candidate, "collapsed": key in COLLAPSED_STATUSES}
            for key, label, candidate in STATUSES
        ],
        # 과제 속성은 설정에서 더하고 빼고 고칠 수 있다 (TODO 100).
        "types": settings_service.project_types(),
        # 팀원 역량 이력의 구분 (TODO 72). 과제의 속성과 다른 축이다.
        "activity_kinds": [{"key": key, "label": label} for key, label in ACTIVITY_KINDS],
        # 팀원 면담 (TODO 182) — 구분 목록 · 주기(일)
        "meeting_kinds": settings_service.meeting_kinds(),
        "meeting_cycle_days": settings_service.meeting_cycle_days(),
        "groups": groups,
        # 과제 중 **그룹을 안 적은 것**이 있으면 [미지정] 으로 고를 수 있어야 한다.
        # 홈의 그룹별 표가 이미 그 줄을 세우고 `group=none` 으로 이어 준다 (TODO 90).
        "groups_none": conn.execute(
            "SELECT COUNT(*) AS n FROM project WHERE grp IS NULL OR TRIM(grp) = ''"
        ).fetchone()["n"] > 0,
        "tags": tags,
        # 과제 목록의 태그 거르기 상자용 — 과제에 실제로 붙어 있는 태그만.
        "project_tags": project_tags,
        # 과제가 실제로 있는 해. 거르기 상자는 이것만 세운다 — 없는 해를 고르면 0건이다.
        "years": home_service.years(conn),
        "owners": owners,
        # 유관부서 — 팀과 그쪽 담당자를 나눠 준다. 거르기는 둘 중 어느 쪽으로도 된다.
        "partner_teams": partner_teams,
        "partner_people": partner_people,
        # 지금 돌고 있는 배포본 (TODO 117). 저장소에서 실행하면 None.
        "build": buildinfo.read(),
        "audiences": audiences,
        # 담당자 명부 — 자동완성이 이것을 먼저 쓰고, 없는 이름이면 화면에서 물어본다.
        # **떠난 사람도 여기 남는다** — 빼면 지난해 담당자가 "명부에 없는 이름" 으로 잡힌다.
        "people": settings_service.known_names(),
        # 그중 떠난 사람 (TODO 122). 화면이 딱지를 붙이고 자동완성에서 뒤로 민다.
        "people_left": settings_service.left_people(),
        "project_code": settings_service.project_code(),
        "vault": str(get_settings().vault_dir),
        "report_cycle_days": get_settings().report_cycle_days,
        # 주간 보고 요일 (0=월 … 6=일). 화면이 안내 문구에 쓴다.
        "report_weekday": settings_service.report_weekday(),
        # 과제 분류 넷 (TODO 136) — 입력 칸의 목록과 이름표. 분류 칸을 세우는 속성도 함께.
        "classifications": [
            {"key": key, "label": label, "items": lists[key]}
            for key, label, _ in CLASSIFICATIONS
            for lists in [settings_service.classifications()]
        ],
        "classified_type": CLASSIFIED_TYPE,
        # 접수 (TODO 136) — 상태 이름표와 묵힘 기준일
        "intake_statuses": [
            {"key": key, "label": label, "pool": pool} for key, label, pool in INTAKE_STATUSES
        ],
        "intake_stale_days": settings_service.intake_stale_days(),
        # 사전점검 체크리스트 (TODO 155) — 항목·단계·점수와 구간 기준
        "precheck": _precheck_meta(),
        # 마지막으로 vault 를 훑었을 때 읽지 못한 파일 · 값 (TODO 164) — 홈 · 과제목록이 늘 띄운다
        "problems": [{"path": item.rel_path, "reason": item.reason} for item in indexer.LAST_PROBLEMS],
    }


@router.post("/reindex")
def reindex(conn: sqlite3.Connection = Depends(get_db)) -> dict:
    indexed, problems = reindex_all(conn)
    return {
        "indexed": indexed,
        # 읽지 못한 파일은 조용히 넘기지 않고 화면에 알린다.
        "problems": [{"path": item.rel_path, "reason": item.reason} for item in problems],
    }


def _precheck_meta() -> dict:
    from ..services import precheck

    items = precheck.definition()
    return {
        "items": items,
        "thresholds": precheck.thresholds(),
        "max": sum(max(c[1] for c in item["choices"]) for item in items),
        "bands": [{"key": key, "label": label} for key, label in precheck.BANDS],
    }
