import { useCallback, useEffect, useState } from "react";
import { api } from "../api";
import type { Dashboard as DashboardData, OpenDraft } from "../types";
import { projectLink } from "../nav";
import { todayIso, useLatest } from "../util";
import { storageGet, storageSet } from "../storage";

const OPEN_KEY = "md-mgmt:dashboard";
/** 리마인더를 닫은 날. 같은 날 다시 띄우지 않는다. */
const REMINDER_KEY = "md-mgmt:reminder-closed";
/** 담당 줄에 처음 세우는 사람 수. 넘치면 [+N명]으로 접어 둔다. */
const OWNER_CHIPS = 8;
/**
 * 배너에 초안 **이름**을 세우는 것은 몇 건까지인가 (TODO 91).
 *
 * 실제 운영은 주 2~3건이라 평소에는 늘 이름이 보인다. 그 위는 배너가 두세 줄로
 * 자라기 시작하므로 목록 화면(보고 대상)에 맡긴다.
 */
const DRAFT_CHIPS = 3;

interface Filters {
  status: string;
  type: string;
  owner: string;
  due: string;
  /** 목록과 같은 연도를 봐야 수와 목록이 어긋나지 않는다 (DESIGN 5.8). */
  year: string;
}

/**
 * 배너가 데려갈 곳 (TODO 91).
 *
 * | 상태 | 어디로 |
 * |---|---|
 * | 초안 1건 | **그 초안 편집기로 직행** |
 * | 초안 2~3건 | 과제명을 칩으로 세우고, 각 칩이 그 초안으로 |
 * | 초안 4건 이상 | 보고 대상 화면 — 맨 위에 확정 대기 목록이 있다 |
 * | 오늘 보고를 마침 | 보고 이력(그날) |
 * | 초안 0건 | 보고 대상 후보 — 거기서 이번 주 묶음을 고른다 |
 */
function ReminderGo({ reminder }: { reminder: NonNullable<DashboardData["reminder"]> }) {
  // 개수는 reminder.drafts 가 맞고, 목록은 앞의 몇 건만 온다 — 이름을 세울 때만 쓴다.
  const drafts: OpenDraft[] = reminder.draft_items ?? [];
  // 온 곳을 함께 실어 준다 — 확정하고 나서 [← 돌아가기]가 제자리를 찾는다.
  const go = (draft: OpenDraft) => projectLink(draft.project_id, { report: draft.id });

  if (reminder.phase === "report") {
    if (drafts.length === 1) {
      return (
        <a className="reminder-go" href={go(drafts[0])}>
          {drafts[0].project_title} 초안 확정하러 가기 →
        </a>
      );
    }
    if (drafts.length > 1 && drafts.length <= DRAFT_CHIPS) {
      return (
        <span className="reminder-chips">
          {drafts.map((draft) => (
            <a key={draft.id} className="reminder-chip" href={go(draft)}>
              {draft.project_title}
            </a>
          ))}
        </span>
      );
    }
    if (reminder.drafts > 0) {
      return (
        <a className="reminder-go" href="#/reports">
          초안 {reminder.drafts}건 확정하기 →
        </a>
      );
    }
    if (reminder.done > 0) {
      // 오늘 할 일은 끝났다. 여기서 볼 것은 후보가 아니라 **오늘 보고한 것**이다.
      return (
        <a
          className="reminder-go"
          href={`#/history?from=${reminder.report_date}&to=${reminder.report_date}`}
        >
          오늘 보고한 {reminder.done}건 보기 →
        </a>
      );
    }
  }
  return (
    <a className="reminder-go" href="#/reports">
      보고 대상 고르러 가기 →
    </a>
  );
}

interface Props {
  /** 값이 바뀌면 다시 읽는다 (과제를 추가했거나 다시 읽기를 눌렀을 때). */
  refreshKey: number;
  filters: Filters;
  onFilter: (key: "status" | "type" | "owner" | "due" | "year", value: string) => void;
}

/**
 * 메인 상단 대시보드.
 *
 * 목적은 "지금 무엇을 봐야 하는가" 하나다. 그래서 지표를 늘리지 않고,
 * 모든 숫자는 누르면 그 조건으로 걸러진 목록으로 이어진다.
 * 이미 걸려 있는 조건을 다시 누르면 해제된다.
 */
/** 오늘 날짜 (YYYY-MM-DD). 리마인더를 "오늘 하루만" 닫아 두는 데 쓴다. */
function today(): string {
  return todayIso(); // util 과 한 가지 셈 (TODO 207)
}

export default function Dashboard({ refreshKey, filters, onFilter }: Props) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [open, setOpen] = useState(() => storageGet(OPEN_KEY) !== "off");
  const [allOwners, setAllOwners] = useState(false);
  const [reminderClosed, setReminderClosed] = useState(() => storageGet(REMINDER_KEY));
  // 못 불러오면 조용히 사라지지 않고 한 줄 + [다시 시도] (TODO 209 ③)
  const [error, setError] = useState<string | null>(null);
  // 연도를 빨리 바꾸면 앞 요청이 늦게 와 표와 다른 해를 보일 수 있다 — 마지막 것만 (TODO 210 ①)
  const latest = useLatest();

  const load = useCallback(() => {
    const mine = latest();
    // "all" 은 조건이 없는 것이다 (ProjectList 의 ALL_YEARS 와 같은 규칙).
    api
      .dashboard(filters.year === "all" ? "" : filters.year)
      .then((next) => {
        if (!mine()) return;
        setData(next);
        setError(null);
      })
      .catch((err: Error) => {
        if (!mine()) return;
        setData(null);
        setError(err.message);
      });
  }, [filters.year, latest]);

  useEffect(load, [load, refreshKey]);

  if (error)
    return (
      <p className="inline-load-error dash-error" role="alert">
        대시보드를 불러오지 못했습니다 — {error}{" "}
        <button className="ghost small" onClick={load}>
          다시 시도
        </button>
      </p>
    );
  if (!data || data.total === 0) return null;

  const toggle = (key: "status" | "type" | "owner" | "due", value: string) =>
    onFilter(key, filters[key] === value ? "" : value);

  // 한 과제에 담당자가 여러 명일 수 있어 담당 칩의 합은 전체보다 클 수 있다.
  // 상태·속성 줄은 합이 딱 맞으므로, 다를 때만 그 사실을 밝혀 둔다.
  const ownerSum = data.owners.reduce((sum, item) => sum + item.count, 0);
  const shownOwners = allOwners ? data.owners : data.owners.slice(0, OWNER_CHIPS);
  const hiddenOwners = data.owners.length - shownOwners.length;

  // 오늘이 선정일·보고일이 아니면 reminder 는 null 이라 배너 자체가 없다.
  const reminder = data.reminder && reminderClosed !== today() ? data.reminder : null;

  return (
    <section className={`dashboard${open ? "" : " closed"}`}>
      {reminder && (
        <div className={`report-reminder ${reminder.phase}`}>
          <span className="reminder-mark">{reminder.phase === "report" ? "오늘 보고" : "오늘 선정"}</span>
          <span className="reminder-text">
            {reminder.phase === "report" ? (
              <>
                <b>{reminder.report_date} 보고하는 날</b>입니다.
                {reminder.drafts > 0
                  ? ` 초안 ${reminder.drafts}건이 확정을 기다리고 있습니다.`
                  : reminder.done > 0
                    ? ` ${reminder.done}건을 보고했습니다.`
                    : " 아직 만든 초안이 없습니다."}
              </>
            ) : (
              <>
                <b>내일({reminder.report_date}) 보고</b>입니다. 오늘 보고 대상을 고르세요.
                {reminder.pending > 0
                  ? ` 보고할 진행이 쌓인 과제 ${reminder.pending}건.`
                  : " 아직 새로 쌓인 진행일지가 없습니다."}
              </>
            )}
          </span>
          {/* **말한 것과 데려가는 곳이 같아야 한다** (TODO 91).
              "초안 1건이 확정을 기다립니다" 라고 적어 놓고 후보 목록으로 보내면,
              방금 이름까지 들은 그 한 건을 사용자가 다시 찾아야 한다. */}
          <ReminderGo reminder={reminder} />
          <button
            className="ghost small"
            title="오늘은 다시 띄우지 않습니다."
            onClick={() => {
              storageSet(REMINDER_KEY, today());
              setReminderClosed(today());
            }}
          >
            닫기
          </button>
        </div>
      )}
      {/* "작년에 시작해 아직 하고 있는 과제 N건이 빠져 있다" 는 안내(TODO 67)는 뺐다 — 연도가 수행기간이 되어(181)
          그 과제들이 그 해에 보인다. */}

      <div className="dash-row">
        <button
          className="dash-fold"
          onClick={() => {
            const next = !open;
            setOpen(next);
            storageSet(OPEN_KEY, next ? "on" : "off");
          }}
          title={open ? "대시보드 접기" : "대시보드 펼치기"}
        >
          {open ? "▾" : "▸"} 과제 {data.total}건
        </button>

        {open && (
          <>
            <div className="dash-chips">
              {data.statuses.map((item) => (
                <button
                  key={item.key}
                  className={`dash-chip${filters.status === item.key ? " on" : ""}`}
                  onClick={() => toggle("status", item.key)}
                >
                  {item.label} <b>{item.count}</b>
                </button>
              ))}
            </div>

            <div className="dash-warn">
              {data.due_soon > 0 && (
                <button
                  className={`dash-mini warn${filters.due === String(data.due_soon_days) ? " on" : ""}`}
                  onClick={() => toggle("due", String(data.due_soon_days))}
                >
                  마감 임박 {data.due_soon}
                </button>
              )}
              {data.overdue > 0 && (
                <button
                  className={`dash-mini danger${filters.due === "overdue" ? " on" : ""}`}
                  onClick={() => toggle("due", "overdue")}
                >
                  기한 초과 {data.overdue}
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {open && (
        <>
          <div className="dash-row">
            <span className="dash-label">속성</span>
            <div className="dash-chips">
              {data.types.map((item) => (
                <button
                  key={item.key}
                  className={`dash-chip type${filters.type === item.key ? " on" : ""}`}
                  onClick={() => toggle("type", item.key)}
                >
                  {item.label} <b>{item.count}</b>
                </button>
              ))}
            </div>
          </div>

          {data.owners.length > 0 && (
            <div className="dash-row">
              <span className="dash-label">
                담당
                {ownerSum > data.total && <span className="dash-note"> 중복 포함</span>}
              </span>
              <div className="dash-chips">
                {shownOwners.map((item) => (
                  <button
                    key={item.key}
                    className={`dash-chip type${filters.owner === item.key ? " on" : ""}`}
                    onClick={() => toggle("owner", item.key)}
                  >
                    {item.label} <b>{item.count}</b>
                  </button>
                ))}
                {hiddenOwners > 0 && (
                  <button className="dash-chip more" onClick={() => setAllOwners(true)}>
                    +{hiddenOwners}명
                  </button>
                )}
                {allOwners && data.owners.length > OWNER_CHIPS && (
                  <button className="dash-chip more" onClick={() => setAllOwners(false)}>
                    접기
                  </button>
                )}
              </div>
            </div>
          )}

          {data.candidates.length > 0 && (
            /* 목록 자체는 [보고 대상] 화면에 있다. 같은 자료를 두 곳에 세우면
               한쪽만 고쳐져 어긋나기 쉽다. 여기서는 길만 열어 둔다 (TODO 52). */
            <div className="dash-row dash-candidates">
              <span className="dash-label">{data.report_date} 보고</span>
              <a className="dash-mini go" href="#/reports">
                {/* 세는 수와 누른 뒤 나오는 수가 같아야 한다 (DESIGN 5.8, TODO 82).
                    화면에 세운 상위 몇 건의 길이가 아니라 **전체 후보 수**를 적는다. */}
                보고 대상 {data.candidate_total ?? data.candidates.length}건 보기 →
              </a>
            </div>
          )}

        </>
      )}
    </section>
  );
}
