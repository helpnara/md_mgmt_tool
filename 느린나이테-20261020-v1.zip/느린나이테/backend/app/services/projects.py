"""과제 생성·수정. 파일을 먼저 쓰고 인덱스를 갱신한다."""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Any

from .. import clock
from ..config import CLASSIFICATION_KEYS, DEFAULT_STATUS, STATUS_KEYS, LEGACY_STATUS_MAP, get_settings, normalize_status
from .. import schemas as rules
from ..vault import markdown as md
from ..vault import versions
from ..vault import paths
from ..vault.indexer import index_project, refresh_problems
from . import activities as activities_service
from . import settings as settings_service
from . import trash as trash_service

# 카드 제목이 "과제 개요"이므로 본문은 같은 제목을 반복하지 않는다.
# 각 항목이 무엇을 적는 자리인지 괄호로 안내하고, 사용자는 그 줄을 지우고 쓰면 된다.
# 안내 문구는 인용문(>)으로 넣는다. 화면에서 흐리게 보여 실제 내용과 구분되고,
# 사용자는 그 줄을 지우고 쓰면 된다.
INDEX_TEMPLATE = """## 배경

> 왜 이 과제를 하는지 — 문제 상황, 요청 배경 (이 줄을 지우고 작성하세요)

## 목표

> 무엇을 달성하면 끝인지 — 가능하면 수치로 (성과지표: KPI · 현수준 · 목표)

## 추진내용

> 과제 범위 · 적용 대상 · 단계별 추진계획 · 유관부서 협의

## 산출물

> 과제가 끝났을 때 남기는 결과물 — 예: 평가 보고서, 시제품, 측정 데이터, 특허 초안

## 정성적 효과

> 숫자로 표현하기 어려운 효과 — 품질 향상, 리스크 저감, 기술 확보, 대응 속도 등
> 근거 자료(엑셀·PPT)는 아래 [파일 첨부]로 붙이고 여기에 링크하면 된다

## 효과 산출 근거

> 위 기대효과 금액이 어떤 계산에서 나왔는지 — 단가 × 물량 × 개선율, 가정, 출처
> 근거 없는 숫자는 보고 자리에서 방어하지 못한다

## 활용 방안 및 향후 계획

> 결과를 어디에 어떻게 쓰는지, 끝난 뒤 이어질 일

## 관련 링크

> 참고할 사내 위키·공유 폴더 주소, 관련 과제 번호 등
"""

# 예전 서식들 (TODO 136 에서 섹션 둘을 더하기 전). 그 서식 그대로인 개요도 **아직 작성 전**으로
# 알아봐야 한다 — 서식을 바꿨다고 이미 만든 과제들이 갑자기 "작성됨" 이 되면 안 된다 (106-B).
LEGACY_INDEX_TEMPLATES = (
    """## 배경

> 왜 이 과제를 하는지 — 문제 상황, 요청 배경 (이 줄을 지우고 작성하세요)

## 목표

> 무엇을 달성하면 끝인지 — 가능하면 수치로

## 산출물

> 과제가 끝났을 때 남기는 결과물 — 예: 평가 보고서, 시제품, 측정 데이터, 특허 초안

## 정성적 효과

> 숫자로 표현하기 어려운 효과 — 품질 향상, 리스크 저감, 기술 확보, 대응 속도 등
> 근거 자료(엑셀·PPT)는 아래 [파일 첨부]로 붙이고 여기에 링크하면 된다

## 효과 산출 근거

> 위 기대효과 금액이 어떤 계산에서 나왔는지 — 단가 × 물량 × 개선율, 가정, 출처
> 근거 없는 숫자는 보고 자리에서 방어하지 못한다

## 관련 링크

> 참고할 사내 위키·공유 폴더 주소, 관련 과제 번호 등
""",
)

META_ORDER = [
    "id", "title", "status", "type",
    # 과제 분류 넷 (TODO 136) — 속성 바로 뒤. 파일을 열었을 때 한 덩이로 읽힌다.
    "nature", "category", "delivery", "cost_kind",
    "group", "tags", "owners",
    "start_date", "due_date", "completed_at", "effect_expected", "effect_verified",
    "no_report", "no_effect", "partners",
    # 이 과제가 어느 접수에서 승격됐는가 (TODO 136). 직접 만든 과제는 비어 있다.
    "intake_id",
    # 선행 과제 — 다년도 과제의 앞 단계 번호들 (TODO 172). 1단계면 비어 있다. 여럿일 수 있다.
    "predecessors",
    "created_by", "created_at", "updated_at",
]

# 상태가 이것이 되는 순간 완료일이 남는다 (TODO 104).
DONE_STATUS = "done"


# 효과 금액의 소수 자릿수. 단위가 **억원/년** 이므로 둘째 자리는 100만 원이다.
# 한 자리(=천만 원)로는 1억 2,500만 원짜리 효과를 적을 수 없다 (TODO 76).
EFFECT_DECIMALS = 2


def normalize_effect(value: object) -> float | None:
    """효과 금액(억원/년)을 숫자로 맞춘다. 비우는 것은 정상이다.

    실증효과는 과제가 끝나야 나오므로 진행 중에는 대부분 비어 있다.

    **여기서 소수 둘째 자리로 자른다.** 파일이 진실의 원천이므로, 화면이 두 자리로
    보여 준다면 파일에도 두 자리만 있어야 한다. 그러지 않으면 API 로 넣은 `1.234` 가
    화면에는 `1.23` 으로 보이면서 파일에는 그대로 남아 둘이 어긋난다.
    """
    return normalize_effect_field(value, "effect")


def normalize_effect_field(value: object, field: str) -> float | None:
    """칸 이름을 문구에 싣는 쪽 (TODO 205) — NaN · 무한대 · 음수 · 지나친 값은 `schemas.finite_number` 가 거절한다."""
    number = rules.finite_number(value, field)
    return None if number is None else round(number, EFFECT_DECIMALS)


def normalize_label(value: object) -> str | None:
    """분류 넷의 값 (TODO 136). 글자 그대로 두되 앞뒤·겹친 공백만 정리한다.

    **목록에 있는지는 따지지 않는다.** 목록은 설정에서 바뀌는데, 바뀔 때마다 예전 값을
    가진 과제를 저장할 수 없게 되면 안 된다. 화면은 목록에서 고르게 하고, 파일은 무엇이든 받는다.
    """
    text = " ".join(str(value or "").split())
    return text[:40] or None


def normalize_owners(value: object) -> list[str]:
    """담당자는 한 명일 수도, 여러 명일 수도 있다. 쉼표로 적어도 받아 준다.

    태그와 **같은 규칙**이다 — `schemas.split_list` (TODO 205).
    """
    return rules.split_list(value)


def normalize_tags(conn: sqlite3.Connection, value: object) -> list[str]:
    """태그 — 쉼표 규칙(`split_list`) 위에 표기 맞추기 (TODO 214 D12).

    앞의 `#` 를 떼고 겹친 공백을 하나로. 대소문자 · 띄어쓰기만 다른 태그가 **이미 쓰이고 있으면 그 표기**를 쓴다
    ("AI" 가 있으면 "ai" · "#AI" · " A I " 는 "AI"). 같은 요청 안에서 겹친 것은 하나로.
    """
    known: dict[str, str] = {}
    for row in conn.execute(
        "SELECT t.name FROM tag t WHERE EXISTS (SELECT 1 FROM project_tag pt WHERE pt.tag_id = t.id)"
        " OR EXISTS (SELECT 1 FROM entry_tag et WHERE et.tag_id = t.id) ORDER BY t.id"
    ):
        known.setdefault(rules.tag_key(row["name"]), row["name"])
    out: list[str] = []
    seen: set[str] = set()
    for item in rules.split_list(value):
        text = rules.clean_tag(item)
        key = rules.tag_key(text)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(known.get(key, text))
    return out


def same_title_ids(conn: sqlite3.Connection, title: str, exclude: str | None = None) -> list[str]:
    """이름이 같은 과제의 번호들 (TODO 205 ㉞) — 막지는 않고 알린다. 대소문자 · 앞뒤 공백은 같은 것으로 본다."""
    wanted = " ".join(str(title or "").split()).casefold()
    if not wanted:
        return []
    return [item["id"] for item in same_title_projects(conn, title, exclude)]


def same_title_projects(conn: sqlite3.Connection, title: str, exclude_id: str | None = None) -> list[dict]:
    """이름이 같은 과제들 `[{"id", "title"}]` (TODO 214 D11) — 저장 **전에** 묻는 자리(제목 수정 · 승격 · 새 과제)가 함께 쓴다.

    앞뒤 · 겹친 공백과 대소문자는 같은 것으로 본다. `exclude_id` 는 지금 고치는 그 과제.
    """
    wanted = " ".join(str(title or "").split()).casefold()
    if not wanted:
        return []
    return [
        {"id": row["id"], "title": row["title"]}
        for row in conn.execute("SELECT id, title FROM project ORDER BY id")
        if row["id"] != exclude_id and " ".join(str(row["title"] or "").split()).casefold() == wanted
    ]


def normalize_partners(value: object) -> list[dict]:
    """유관부서와 그 담당자 (TODO 92).

    `[{"team": "설비기술팀", "people": "김철수, 박민수"}, …]` 을 받아
    `[{"team": "설비기술팀", "people": ["김철수", "박민수"]}, …]` 으로 맞춘다.

    **사람 이름을 나누는 일은 여기(서버)에서 한다.** 화면만 고치면 API 를 직접 부르는
    길로 `"김철수,박민수"` 한 덩이가 사람 하나로 굳는다 — 역량 이력에서 실제로 겪은
    사고다 (TODO 74). 팀 이름은 나누지 않는다. 부서명에 쉼표가 들어갈 수 있고,
    무엇보다 **팀은 줄마다 하나**라는 것이 이 구조의 약속이다.

    담당자가 비어 있어도 줄은 남긴다 — 팀은 정해졌는데 사람은 나중에 정해지는 일이 흔하다.
    """
    if not value:
        return []
    rows = value if isinstance(value, list) else [value]
    out: list[dict] = []
    seen: dict[str, dict] = {}
    for row in rows:
        if isinstance(row, str):
            team, people = row, []
        elif isinstance(row, dict):
            team = str(row.get("team") or "").strip()
            people = activities_service.split_people(
                row.get("people") if isinstance(row.get("people"), str) else None
            ) or [
                name
                for name in (str(item).strip() for item in (row.get("people") or []))
                if name
            ]
        else:
            continue
        team = str(team).strip()
        if not team:
            continue
        # 같은 팀을 두 줄로 적었으면 한 줄로 합친다 — 표와 검색에서 두 번 세지 않는다.
        if team in seen:
            for name in people:
                if name not in seen[team]["people"]:
                    seen[team]["people"].append(name)
            continue
        entry = {"team": team, "people": list(dict.fromkeys(people))}
        seen[team] = entry
        out.append(entry)
    return out


def now_iso() -> str:
    return clock.now().replace(microsecond=0).isoformat()


def project_year(start_date: str | None = None) -> int:
    """과제 번호에 쓸 연도 — **착수년도**다 (TODO 95).

    지난해에 한 과제를 올해 뒤늦게 등록하는 일이 실제로 있다. 그때 번호가 `2026-…` 으로
    붙으면 그 과제는 홈·대시보드·목록에서 전부 올해 것으로 세인다 — 연도를 가르는 기준이
    **과제 번호 앞 네 자리**이기 때문이다 (DESIGN 5.8). 그래서 **등록한 날이 아니라
    시작일**을 본다.

    시작일을 비워 두면 올해다 — 지금 착수하는 과제라고 보는 것이 가장 흔한 경우다.
    """
    text = (start_date or "").strip()
    if len(text) >= 4 and text[:4].isdigit():
        year = int(text[:4])
        # 오타로 `0025-01-01` 같은 값이 들어오면 없는 연도의 번호가 생긴다. 그때는 올해로.
        if 1900 <= year <= 2999:
            return year
    return clock.today().year


def next_project_id(year: int | None = None, code: str | None = None) -> str:
    """다음 과제 번호.

    팀 코드를 비워 두면 `2026-001`, `소재` 를 넣으면 `2026-소재-001` 이 된다.
    일련번호는 **코드별로 따로 센다** — 팀마다 자기 번호를 갖는 편이 자연스럽고,
    코드가 다르면 번호가 같아도 과제 번호는 겹치지 않는다.
    연도는 **착수년도**다 (`project_year`) — 등록한 날이 아니다.

    **이미 만든 과제의 번호는 바꾸지 않는다.** 번호는 식별자라 섞여도 되고,
    바꾸면 폴더명과 문서 안의 링크가 모두 흔들린다.
    (시작일을 잘못 적어 연도가 어긋난 과제만은 사용자가 눌러서 옮긴다 — `renumber.year_*`)
    """
    settings = get_settings()
    settings.ensure_dirs()
    year = year or clock.today().year
    if code is None:
        code = settings_service.project_code()
    prefix = f"{year}-{code}-" if code else f"{year}-"

    # 번호는 한 번 쓰면 다시 쓰지 않는다 — 삭제 보관함에 간 과제의 번호도 센다 (TODO 146).
    names = [child.name for child in settings.projects_dir.iterdir() if child.is_dir()]
    names += list(trash_service.used_folder_names("projects"))
    return f"{prefix}{max_sequence(names, prefix) + 1:03d}"


def max_sequence(names: list[str], prefix: str) -> int:
    """`prefix` 로 시작하는 이름들의 가장 큰 일련번호. 없으면 0."""
    used = 0
    for name in names:
        if not name.startswith(prefix):
            continue
        seq = name[len(prefix):].split("-")[0]
        if seq.isdigit():
            used = max(used, int(seq))
    return used


def project_dir(conn: sqlite3.Connection, project_id: str) -> Path:
    row = conn.execute("SELECT dir_name FROM project WHERE id = ?", (project_id,)).fetchone()
    if row is None:
        raise KeyError(project_id)
    return paths.safe_join(get_settings().projects_dir, row["dir_name"])


def create_project(conn: sqlite3.Connection, data: dict[str, Any], warnings: list[str] | None = None) -> str:
    """과제를 만든다. `warnings` 를 주면 막지는 않고 알릴 것(선행 연도 · 효과)을 거기 담는다 (TODO 214)."""
    settings = get_settings()
    settings.ensure_dirs()
    title = rules.require_title(data.get("title"))
    title = rules.one_line(title, "title", rules.TITLE_MAX)  # 100자 · 한 줄 (TODO 214 D14)
    group = rules.one_line(data.get("group"), "group", rules.GROUP_MAX) or None
    body = rules.check_body(data.get("body"))

    status = data.get("status") or DEFAULT_STATUS
    if status not in STATUS_KEYS:
        raise ValueError(f"알 수 없는 상태: {status}")

    project_type = data.get("type") or None
    if project_type and project_type not in settings_service.type_keys():
        raise ValueError(f"알 수 없는 속성: {project_type}")
    # 선행 과제 (TODO 172) — 폴더를 만들기 전에 본다(거절하면 빈 폴더가 남지 않게).
    # 새 과제는 아직 번호가 없으므로 고리가 생길 수 없다. 있는 과제인지만 본다.
    predecessors = check_predecessors(conn, None, data.get("predecessors"))
    # 날짜 · 기간 (TODO 205 ⑯) — 틀린 날짜는 400. 예전에는 받아 두고 **파일에 원문을 적어** 재색인마다 경고였다.
    start_date = rules.strict_day(data.get("start_date"), "start_date")
    due_date = rules.strict_day(data.get("due_date"), "due_date")
    rules.check_period(start_date, due_date, "start_date", "due_date")
    # 완료일 (TODO 214 D1) — 완료면 비울 때 오늘 · 시작일 ≤ 완료일 ≤ 오늘, 완료가 아니면 서버가 비운다.
    completed_at = settle_completed_at(status, normalize_day(data.get("completed_at")), start_date)
    effect_expected = normalize_effect_field(data.get("effect_expected"), "effect_expected")
    effect_verified = normalize_effect_field(data.get("effect_verified"), "effect_verified")
    no_effect = bool(data.get("no_effect"))
    created_by = settings_service.current_author(rules.clean_author(data.get("created_by"))) or None  # F13

    # TODO 201 — **모든 검증을 폴더 만들기 앞에.** 효과 금액 · 완료일 · 담당자 · 유관부서 … 가 400 으로
    # 거절돼도 `projects/2026-031-…/{logs,assets,reports}` 가 이미 만들어져 남고 번호가 소모됐다
    # (번호는 다시 쓰지 않는다 — 146). 머리 정보를 먼저 다 만들고, 번호와 폴더는 그 다음이다.
    stamp = now_iso()
    meta = {
        "id": None,  # 번호는 검증이 다 끝난 뒤 붙인다 (아래)
        "title": title,
        "status": status,
        "type": project_type,
        "group": group,
        "tags": normalize_tags(conn, data.get("tags")),  # 쉼표 규칙 + 표기 맞추기 (TODO 205 · 214 D12)
        "owners": normalize_owners(data.get("owners") or data.get("owner")),
        # 유관부서와 그 담당자. 팀 하나에 사람 여럿, 팀도 여럿일 수 있다 (TODO 92).
        "partners": normalize_partners(data.get("partners")),
        "start_date": start_date,
        "due_date": due_date,
        # 완료 상태로 등록하면 완료일이 곧 등록일이다 — 지난 과제를 뒤늦게 넣을 때는
        # 폼에서 손으로 고친다 (TODO 104).
        "completed_at": completed_at,
        "effect_expected": effect_expected,
        "effect_verified": effect_verified,
        # 과제 분류 넷 (TODO 136). 주로 스마트과제에서 쓴다 — 다른 과제는 비어 있어도 된다.
        **{key: normalize_label(data.get(key)) for key in CLASSIFICATION_KEYS},
        # 접수에서 승격된 과제면 그 접수 번호 (TODO 136)
        "intake_id": (str(data.get("intake_id") or "").strip() or None),
        "predecessors": predecessors,
        # 단순 현황 관리를 과제로 세운 경우가 있다. 그런 과제는 보고 대상 후보에서 뺀다
        # — 매주 "이건 보고 안 해도 되는데" 를 눈으로 걸러 내지 않아도 되게 (TODO 80).
        "no_report": bool(data.get("no_report")),
        # 효과 금액으로 관리하지 않는 과제 (TODO 125)
        "no_effect": no_effect,
        # 담당자(누가 하는가)와 다른, "누가 등록했는가". 소급이 안 되므로 지금부터 남긴다.
        # 로그인이 생기면 이 자리에 로그인 사용자가 들어온다.
        "created_by": created_by,
        "created_at": stamp,
        "updated_at": stamp,
    }

    # 번호의 연도는 **등록한 날이 아니라 착수년도**다 (TODO 95). 여기부터는 거절할 것이 없다.
    project_id = next_project_id(project_year(start_date))
    meta["id"] = project_id
    if warnings is not None:
        warnings.extend(predecessor_year_warnings(conn, start_date or project_id, predecessors))
        warnings.extend(effect_warnings(status, effect_expected, effect_verified, no_effect))
    dir_name = paths.project_dir_name(project_id, title)
    directory = paths.safe_join(settings.projects_dir, dir_name)
    (directory / "logs").mkdir(parents=True, exist_ok=True)
    (directory / "assets").mkdir(parents=True, exist_ok=True)
    (directory / "reports").mkdir(parents=True, exist_ok=True)
    md.save(directory / "index.md", md.MarkdownDoc(meta, body or INDEX_TEMPLATE))
    index_project(conn, directory)
    conn.commit()
    return project_id


def settle_completed_at(status: str, completed_at: str | None, start_date: str | None, *, check: bool = True) -> str | None:
    """완료일의 규칙 한 곳 (TODO 214 D1 · F10).

    * 완료가 아니면 **비운다** — 진행중일 때 받아 둔 옛 완료일이 나중에 완료로 바꿀 때 되살아났다.
    * 완료인데 비었으면 오늘 — 화면의 안내 "비워 두면 오늘" 과 같다(F10).
    * 완료일은 시작일보다 앞설 수 없고, 오늘보다 뒤일 수 없다 — 미래 완료일 과제는 그 해까지 "진행중" 으로 셌다.
    """
    if status != DONE_STATUS:
        return None
    value = completed_at or date_today()
    if check:
        if start_date and value < start_date:
            raise ValueError(f"완료일이 시작일보다 빠릅니다 ({start_date} → {value}).")
        if value > date_today():
            raise ValueError(f"완료일이 오늘보다 뒤입니다 ({value}).")
    return value


def effect_warnings(status: str, expected: float | None, verified: float | None, no_effect: bool) -> list[str]:
    """효과 금액 — 막지 않고 알린다 (TODO 214 D2 · D3). 합계에서 빠지는 값이 왜 빠지는지 저장할 때 보이게."""
    if no_effect:
        if expected or verified:
            return ["효과 관리 안 함 과제라 적힌 효과 금액은 합계에 들지 않습니다."]
        return []
    out = []
    if verified and not expected:
        out.append("기대효과 없이 실증효과만 적혀 있습니다.")
    return out


def predecessor_year_warnings(conn: sqlite3.Connection, start_or_id: str | None, predecessors: Iterable[str]) -> list[str]:
    """선행 과제가 이 과제보다 늦게 착수했으면 알린다 (TODO 214 D15) — 막지는 않는다(다년도 과제를 늦게 이은 경우도 있다)."""
    mine = str(start_or_id or "")[:4]
    if not mine.isdigit():
        return []
    out = []
    for pred in predecessors:
        row = conn.execute("SELECT id, start_date FROM project WHERE id = ?", (pred,)).fetchone()
        if row is None:
            continue
        theirs = str(row["start_date"] or row["id"])[:4]
        if theirs.isdigit() and theirs > mine:
            out.append(f"선행 과제 {pred} 의 착수년도({theirs})가 이 과제({mine})보다 늦습니다 — 순서를 확인하세요.")
    return out


def overview_is_blank(body: str | None) -> bool:
    """개요가 아직 서식 그대로인가 (TODO 106-B).

    서식 그대로인 개요는 화면에서 진짜 내용처럼 보이고, 검색 발췌에도 안내 문장이
    본문인 양 실린다. 공백·줄바꿈 차이는 무시한다 — 저장하며 끝의 개행이 흔들린다.
    """
    def squash(text: str | None) -> str:
        return " ".join((text or "").split())

    text = squash(body)
    return text == "" or any(
        text == squash(template) for template in (INDEX_TEMPLATE, *LEGACY_INDEX_TEMPLATES)
    )


def date_today() -> str:
    return clock.today().isoformat()


def normalize_day(value: object, field: str = "completed_at") -> str | None:
    """`YYYY-MM-DD` 만 받는다. 비우면 None — "모른다" 를 "0000-00-00" 으로 적지 않는다.

    규칙은 `schemas.strict_day` 한 곳 (TODO 205) — 시작일 · 마감일 · 접수의 날짜도 같은 것을 부른다.
    """
    return rules.strict_day(value, field)


# 상태 변경 기록에 붙는 태그. 화면이 이 태그로 알아보고 흐리게 세운다.
STATUS_CHANGE_TAG = "상태변경"


def _log_status_change(directory: Path, old: str, new: str) -> None:
    """상태가 바뀔 때 진행일지에 한 줄 (TODO 105).

    "이 과제 언제 보류됐지?" 에 답할 자리가 없었다. 기록은 사람이 쓴 진행일지와 같은
    폴더에 같은 형식으로 남는다 — 별도 표를 두면 타임라인에서 안 보이고 검색도 안 된다.
    **실패해도 상태 변경 자체를 막지 않는다.** 이력을 남기려다 본 작업이 막히면 본말이
    뒤바뀐다.
    """
    from ..config import STATUS_LABELS

    log_system_line(
        directory,
        f"(상태) {STATUS_LABELS.get(old, old)} → {STATUS_LABELS.get(new, new)}",
        f"상태를 **{STATUS_LABELS.get(old, old)}** 에서 **{STATUS_LABELS.get(new, new)}** 로 바꿨다.\n",
    )


def log_system_line(directory: Path, title: str, body: str) -> None:
    """도구가 남기는 진행일지 한 줄 — 상태 변경(105)·접수 연결(145). 사람이 쓴 기록과 같은 자리·같은
    형식이고, `상태변경` 태그라 타임라인에서 흐리게 서며 미보고 분량에 세지 않는다.
    **실패해도 본 작업을 막지 않는다.**
    """
    from . import entries as entries_service

    try:
        today = date_today()
        logs_dir = directory / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        target = paths.unique_path(logs_dir, entries_service.entry_stem(today, title), ".md")
        stamp = now_iso()
        meta = {
            "date": today,
            "title": title,
            "author": settings_service.current_author(None) or None,
            "tags": [STATUS_CHANGE_TAG],
            "attachments": [],
            "created_at": stamp,
            "updated_at": stamp,
        }
        md.save(target, md.MarkdownDoc(meta, body))
    except (OSError, paths.FileInUseError):  # 잠긴 파일(TODO 200)도 본 작업을 막지 않는다
        pass


def check_predecessors(
    conn: sqlite3.Connection, project_id: str | None, value: object, keep: Iterable[str] = ()
) -> list[str]:
    """선행 과제 번호들을 받는다 (TODO 172). 비우면 [].

    * 여럿일 수 있다 — 앞 단계의 과제 둘을 이어받는 과제가 있다.
    * 있는 과제여야 한다 — 없는 번호를 적어 두면 위쪽 줄이 늘 "찾을 수 없음" 이 된다.
    * 자기 자신이나 **자기의 후속 과제**를 선행으로 둘 수 없다 — 고리가 생기면 단계를 셀 수 없다.
    * `keep` — 파일에 **이미 적혀 있던** 번호는 따지지 않고 둔다 (TODO 214 D15). 선행이 보관함으로 가면
      그 과제의 다른 칸을 저장할 때마다 400 이었다. 새로 넣는 번호만 검사한다.
    """
    if value is None or value == "":
        return []
    kept = {str(item).strip() for item in keep if str(item or "").strip()}
    items = value if isinstance(value, list) else str(value).split(",")
    out: list[str] = []
    for item in items:
        # 화면이 "2025-003 고강도 소재" 처럼 이름까지 보내도 번호만 쓴다
        text = str(item or "").strip().split()[0] if str(item or "").strip() else ""
        if not text or text in out:
            continue
        if text in kept and text != project_id:
            out.append(text)
            continue
        if project_id is not None and text == project_id:
            raise ValueError("자기 자신을 선행 과제로 둘 수 없습니다.")
        if conn.execute("SELECT 1 FROM project WHERE id = ?", (text,)).fetchone() is None:
            raise ValueError(f"선행 과제 {text} 를 찾을 수 없습니다.")
        if project_id is not None and project_id in _ancestors(conn, text):
            raise ValueError(f"{text} 는 이 과제의 후속 과제라 선행 과제로 둘 수 없습니다.")
        out.append(text)
    return out


def _predecessors_of(conn: sqlite3.Connection, project_id: str) -> list[str]:
    return [row[0] for row in conn.execute(
        "SELECT predecessor_id FROM project_predecessor WHERE project_id = ? ORDER BY predecessor_id", (project_id,)
    ).fetchall()]


def _successors_of(conn: sqlite3.Connection, project_id: str) -> list[str]:
    return [row[0] for row in conn.execute(
        "SELECT project_id FROM project_predecessor WHERE predecessor_id = ? ORDER BY project_id", (project_id,)
    ).fetchall()]


def _ancestors(conn: sqlite3.Connection, project_id: str) -> set[str]:
    """이 과제의 앞 단계 전부(선행의 선행 …)."""
    seen: set[str] = set()
    stack = _predecessors_of(conn, project_id)
    while stack:
        current = stack.pop()
        if current in seen:
            continue
        seen.add(current)
        stack.extend(_predecessors_of(conn, current))
    return seen


def assign_stages(nodes: Iterable[str], preds: dict[str, list[str]]) -> dict[str, int]:
    """이어진 과제들의 단계 (TODO 172 · 178) — 과제 상세 · 단계 띠 · 로드맵이 **모두 이 함수 하나로** 센다.

    1. 앞에서부터 — 선행을 따라 가장 길게 거슬러 올라간 길이 + 1 (172 의 규칙).
    2. **뒤로 당긴다** — 후속이 있는 과제는 가장 이른 후속의 바로 앞 단계까지 당겨 선다.

    2 가 없을 때(v11 사용자 확인): 1년차 A → 2년차 B → 3년차 D 에, 2년차에 **새로 시작해** D 로 합쳐지는 C 를 이으면
    C 는 앞 과제가 없어 1단계가 됐다 — "1단계에 둘, 2단계에 하나". C 는 D 의 바로 앞 단계(2단계)가 맞다.
    끝에서 멈춘 갈래(후속 없음)는 당기지 않는다 — 2단계에서 끝난 과제가 마지막 단계로 밀려가면 안 된다.
    고리(손으로 고친 파일)와 찾을 수 없는 선행(보관함)에도 넘어지지 않는다 — 찾을 수 없는 과제는 앞이 없는 과제로 본다.
    """
    members = list(dict.fromkeys(nodes))
    inside = set(members)
    before = {node: [p for p in preds.get(node, []) if p in inside and p != node] for node in members}
    after: dict[str, list[str]] = {node: [] for node in members}
    for node in members:
        for pred in before[node]:
            after[pred].append(node)

    forward: dict[str, int] = {}

    def ahead(node: str, trail: frozenset[str]) -> int:
        if node in forward:
            return forward[node]
        if node in trail:
            return 1
        value = 1 + max((ahead(p, trail | {node}) for p in before[node]), default=0)
        forward[node] = value
        return value

    for node in members:
        ahead(node, frozenset())

    final: dict[str, int] = {}

    def pulled(node: str, trail: frozenset[str]) -> int:
        if node in final:
            return final[node]
        if node in trail or not after[node]:
            return forward[node]
        nearest = min(pulled(s, trail | {node}) for s in after[node])
        value = max(forward[node], nearest - 1)
        final[node] = value
        return value

    return {node: pulled(node, frozenset()) for node in members}


def stage_map(conn: sqlite3.Connection) -> dict[str, int]:
    """선행으로 이어진 과제마다 몇 단계인가 (TODO 175) — 과제명 뒤의 단계 띠가 쓴다.

    이어진 과제가 없는 과제는 **빠진다**(띠를 붙이지 않는다). 규칙은 `assign_stages` 하나 — 과제 상세 · 로드맵과 같다.
    표 한 번을 읽어 모두 센다: 과제목록처럼 여러 과제를 그릴 때 과제마다 따로 묻지 않게.
    """
    preds: dict[str, list[str]] = {}
    linked: set[str] = set()
    for row in conn.execute("SELECT project_id, predecessor_id FROM project_predecessor"):
        preds.setdefault(row["project_id"], []).append(row["predecessor_id"])
        linked.update((row["project_id"], row["predecessor_id"]))
    if not linked:
        return {}
    present = {row["id"] for row in conn.execute("SELECT id FROM project")}
    # 찾을 수 없는 과제(보관함)는 앞이 없는 과제로 — 그 너머는 보지 않는다
    usable = {node: items for node, items in preds.items() if node in present}
    stages = assign_stages(sorted(linked), usable)
    return {node: value for node, value in stages.items() if node in present}


LINEAGE_LIMIT = 60  # 한 줄기에 이보다 많으면 무언가 잘못 이어진 것이다 — 화면이 무거워지지 않게 끊는다


def lineage(conn: sqlite3.Connection, project_id: str) -> dict[str, Any]:
    """다년도 과제의 줄기 (TODO 172) — 선행 · 후속으로 이어진 과제 **전부**를 단계별로.

    한 단계에 과제가 여럿일 수 있고(1단계 둘을 이어받는 2단계), 선행도 여럿일 수 있다.
    단계는 **선행을 따라 가장 길게 거슬러 올라간 길이 + 1** — 1단계 과제와 2단계 과제를 함께 이어받으면 3단계.
    선행이 보관함에 있거나 지워졌으면 그 자리에 `missing` 으로 남긴다 — 줄기가 끊겼다는 사실도 보여야 한다.
    """
    # 이어진 과제를 모두 모은다(선행 · 후속 양쪽으로)
    nodes: dict[str, dict[str, Any]] = {}
    queue = [project_id]
    while queue and len(nodes) < LINEAGE_LIMIT:
        current = queue.pop(0)
        if current in nodes:
            continue
        row = conn.execute(
            "SELECT id, title, status, start_date, due_date, completed_at FROM project WHERE id = ?", (current,)
        ).fetchone()
        # 기간의 끝 — 끝난 과제는 끝낸 날, 아니면 마감일 (과제 상세의 단계 칸이 연도를 적는다, TODO 176)
        nodes[current] = (
            {
                "id": row["id"], "title": row["title"], "status": row["status"], "start_date": row["start_date"],
                "end_date": (row["completed_at"] if row["status"] == DONE_STATUS and row["completed_at"] else row["due_date"]),
                "missing": False,
            }
            if row else {"id": current, "title": None, "status": None, "start_date": None, "end_date": None, "missing": True}
        )
        if row is None:
            continue  # 찾을 수 없는 과제 너머로는 가지 않는다
        queue.extend(_predecessors_of(conn, current))
        queue.extend(_successors_of(conn, current))
    if len(nodes) <= 1:
        return {"stage": None, "stages": [], "predecessors": [], "successors": []}

    # 단계 — 과제 상세 · 단계 띠 · 로드맵이 같은 함수로 센다 (TODO 178). 찾을 수 없는 과제는 앞이 없는 과제로.
    stage = assign_stages(
        nodes,
        {node: _predecessors_of(conn, node) for node, info in nodes.items() if not info["missing"]},
    )
    grouped: dict[int, list[dict[str, Any]]] = {}
    for node, info in nodes.items():
        grouped.setdefault(stage.get(node, 1), []).append({**info, "here": node == project_id})
    return {
        "stage": stage.get(project_id),
        "stages": [
            {"stage": number, "items": sorted(items, key=lambda item: (item["start_date"] or "9999", item["id"]))}
            for number, items in sorted(grouped.items())
        ],
        "predecessors": _predecessors_of(conn, project_id),
        "successors": _successors_of(conn, project_id),
    }


def rewrite_project_refs(conn: sqlite3.Connection, mapping: dict[str, str]) -> int:
    """과제 번호가 바뀌었을 때 **다른 파일이 적어 둔 그 번호**를 고친다 (TODO 172).

    번호 일괄 변경 · 연도 맞추기가 과제 자신의 id 와 폴더만 바꿔, 후속 과제의 `predecessors` 와 접수의
    `project_id` · `merged_into` · `demoted_from` 이 옛 번호를 가리킨 채 남았다(접수 링크는 136 부터 있던 틈).
    """
    if not mapping:
        return 0
    settings = get_settings()
    changed = 0
    for path in settings.projects_dir.glob("*/index.md"):
        try:
            doc = md.load(path)
        except Exception:  # 읽지 못하는 파일은 색인이 따로 알린다
            continue
        old = doc.meta.get("predecessors")
        if not isinstance(old, list) or not any(str(item) in mapping for item in old):
            continue
        doc.meta["predecessors"] = [mapping.get(str(item), str(item)) for item in old]
        md.save(path, doc)
        changed += 1
    for path in settings.intakes_dir.glob("*/request.md"):
        try:
            doc = md.load(path)
        except Exception:
            continue
        updates = {key: mapping[str(doc.meta.get(key))]
                   for key in ("project_id", "merged_into", "demoted_from") if str(doc.meta.get(key) or "") in mapping}
        if not updates:
            continue
        doc.meta.update(updates)
        md.save(path, doc)
        changed += 1
    return changed


def update_project(conn: sqlite3.Connection, project_id: str, updates: dict[str, Any]) -> list[str]:
    """과제를 고친다. 막지 않고 알릴 것(선행 연도 · 효과)을 돌려준다 (TODO 214)."""
    directory = project_dir(conn, project_id)
    index_md = directory / "index.md"
    known = conn.execute("SELECT file_mtime FROM project WHERE id = ?", (project_id,)).fetchone()
    md.ensure_unchanged(index_md, known["file_mtime"] if known else None)
    doc = md.load(index_md)
    warnings: list[str] = []

    if "status" in updates and updates["status"] not in STATUS_KEYS:
        raise ValueError(f"알 수 없는 상태: {updates['status']}")
    if updates.get("type") and updates["type"] not in settings_service.type_keys():
        raise ValueError(f"알 수 없는 속성: {updates['type']}")

    body = updates.pop("body", None)
    if body is not None and body != doc.body:
        rules.check_body(body)  # 2,000,000자 · 제어문자 (TODO 214 D14) — 고칠 때만
    # 제목 — 생성과 같은 규칙 (TODO 205 ⑱). `""` 이면 목록에 폴더명이, `"   "` 이면 폴더가 `untitled` 가 됐다.
    # 길이 · 한 줄 (TODO 214 D14) 은 **제목을 바꿀 때만** — 예전의 긴 제목 때문에 다른 칸 저장이 막히지 않게.
    if "title" in updates:
        updates["title"] = rules.require_title(updates["title"])
        if updates["title"] != rules.clean_text(doc.meta.get("title")):
            rules.one_line(updates["title"], "title", rules.TITLE_MAX)
    if "group" in updates:
        group = rules.clean_text(updates["group"])
        if group != rules.clean_text(doc.meta.get("group")):
            group = rules.one_line(group, "group", rules.GROUP_MAX)
        updates["group"] = group or None
    # 날짜 — 생성과 같은 규칙 (TODO 205 ⑯). `""` · null 은 비운다.
    for field in ("start_date", "due_date"):
        if field in updates:
            updates[field] = rules.strict_day(updates[field], field)
    for field in ("effect_expected", "effect_verified"):
        if field in updates:
            updates[field] = normalize_effect_field(updates[field], field)
    if "tags" in updates:
        updates["tags"] = normalize_tags(conn, updates["tags"])  # TODO 214 D12
    if "no_report" in updates:
        updates["no_report"] = bool(updates["no_report"])
    if "no_effect" in updates:
        updates["no_effect"] = bool(updates["no_effect"])
    if "partners" in updates:
        updates["partners"] = normalize_partners(updates["partners"])
    for key in CLASSIFICATION_KEYS:
        if key in updates:
            updates[key] = normalize_label(updates[key])
    # 승격으로 붙은 접수 번호는 화면에서 고치지 않는다 — 양쪽 링크가 어긋난다.
    updates.pop("intake_id", None)
    if "predecessors" in updates:
        # 파일에 이미 있던 번호는 그대로 둔다 — 보관함에 간 선행 때문에 저장이 막히지 않게 (TODO 214 D15)
        stored = doc.meta.get("predecessors")
        stored_ids = stored if isinstance(stored, list) else str(stored or "").split(",")
        updates["predecessors"] = check_predecessors(conn, project_id, updates["predecessors"], keep=stored_ids)
    if "owners" in updates or "owner" in updates:
        updates["owners"] = normalize_owners(updates.pop("owners", None) or updates.pop("owner", None))
    if "completed_at" in updates:
        updates["completed_at"] = normalize_day(updates["completed_at"])
    changes = {k: v for k, v in updates.items() if k in META_ORDER or k == "group"}
    start_now = _day_or_none(changes["start_date"] if "start_date" in changes else doc.meta.get("start_date"))
    # 기간 — 보낸 쪽과 파일에 있던 쪽을 합쳐서 본다 (TODO 205 ㉞). **시작일 · 마감일을 보낼 때만** 따진다 —
    # 손으로 거꾸로 적은 파일이 다른 칸 저장까지 막지 않게 (TODO 214 D18). 그 파일은 문제 목록에 뜬다.
    if "start_date" in changes or "due_date" in changes:
        rules.check_period(
            start_now,
            _day_or_none(changes["due_date"] if "due_date" in changes else doc.meta.get("due_date")),
            "start_date", "due_date",
        )
    # 예전 문서의 owner(단수) 키가 남아 있으면 owners로 옮겨 적는다.
    if "owners" in changes and "owner" in doc.meta:
        doc.meta.pop("owner")

    # ── 완료일 (TODO 104 · 214 D1 · F10) ── 완료가 아니면 비운다(옛 완료일이 되살아나지 않게).
    # 완료로 **바뀌는** 순간에는 보낸 값, 없으면 오늘 — 파일에 남아 있던 옛 값을 쓰지 않는다.
    # 완료인 채로 완료일을 비우면 오늘("비워 두면 오늘"). 따지는 것(시작일 ≤ 완료일 ≤ 오늘)은
    # 상태 · 완료일 · 시작일을 보낼 때만 — 손으로 고친 파일이 다른 칸 저장을 막지 않게.
    raw_status = str(doc.meta.get("status") or "").strip()
    old_status = normalize_status(raw_status)[0] if raw_status else ""
    # 손으로 적은 모르는 상태값(문제 목록에 뜬다)이면, 상태를 보내지 않는 저장은 완료일을 건드리지 않는다
    unknown_status = bool(raw_status) and raw_status not in STATUS_KEYS and raw_status not in LEGACY_STATUS_MAP
    new_status = str(changes.get("status") or old_status)
    if unknown_status and "status" not in changes:
        pass
    elif new_status == DONE_STATUS:
        if "completed_at" in changes:
            wanted = changes["completed_at"]
        elif old_status != DONE_STATUS:
            wanted = None
        else:
            wanted = _day_or_none(doc.meta.get("completed_at"))
        check = bool({"status", "completed_at", "start_date"} & set(changes))
        settled = settle_completed_at(DONE_STATUS, wanted, start_now, check=check)
        if settled != doc.meta.get("completed_at") or "completed_at" in changes:
            changes["completed_at"] = settled
    elif doc.meta.get("completed_at") or "completed_at" in changes:
        changes["completed_at"] = None

    if "predecessors" in changes or "start_date" in changes:
        warnings.extend(predecessor_year_warnings(conn, start_now or project_id, changes.get(
            "predecessors", _as_ids(doc.meta.get("predecessors")))))
    if {"effect_expected", "effect_verified", "no_effect", "status"} & set(changes):
        def now(key: str) -> Any:
            return changes[key] if key in changes else doc.meta.get(key)
        warnings.extend(effect_warnings(
            new_status, _number_or_none(now("effect_expected")), _number_or_none(now("effect_verified")),
            _truthy(now("no_effect")),
        ))

    meta = md.merge_meta(doc.meta, changes)
    meta["updated_at"] = now_iso()
    md.save(index_md, md.MarkdownDoc(meta, body if body is not None else doc.body))

    # ── 상태 변경 이력 (TODO 105) ── 진행일지에 한 줄 남긴다. 파일이 원본이라는 원칙에
    # 맞고, 타임라인에 그대로 보이며, 다음 보고 초안에 "이 기간에 보류됐음" 이 저절로 든다.
    if new_status != old_status and old_status:
        _log_status_change(directory, old_status, new_status)

    new_title = meta.get("title")
    if new_title:
        expected = paths.project_dir_name(project_id, str(new_title))
        if expected != directory.name:
            target = paths.safe_join(get_settings().projects_dir, expected)
            if target.exists():  # 남아 있던 폴더와 겹치면 뒤에 번호를 붙인다
                target = paths.unique_path(get_settings().projects_dir, expected, "")
            try:
                paths.move(directory, target)
            except (paths.FileInUseError, OSError):
                # TODO 200 — index.md 는 이미 저장됐는데 폴더 이동만 실패했다(엑셀이 잡고 있음 등). 그대로
                # 올리면 색인의 file_mtime 이 옛값이라 다음 저장이 "도구 밖에서 수정됨" 409 — [다시 읽기] 를
                # 눌러도 영영 409 였다. 저장된 파일을 색인에 반영해 두고 나서 알린다. 폴더 이름은 다음 저장 때 다시 맞춘다.
                index_project(conn, directory)
                conn.commit()
                raise
            versions.follow(directory, target)  # 이전 버전도 따라온다 (TODO 142)
            # 보관함 기록의 되돌아갈 자리도 새 폴더로 (TODO 203) — 아니면 지운 진행일지를 되돌릴 때 옛 폴더를 되살렸다.
            # 번호 변경(renumber)과 같은 길이다.
            trash_service.rewrite_origins({directory.name: target.name})
            # 옛 폴더 이름으로 적혀 있던 문제는 걷는다 — 새 폴더로 다시 읽으며 남은 것만 다시 선다 (TODO 214 D18)
            refresh_problems(f"projects/{directory.name}/", [])
            directory = target

    index_project(conn, directory)
    conn.commit()
    return warnings


def _as_ids(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item or "").strip()]
    return [part.strip() for part in str(value or "").split(",") if part.strip()]


def _truthy(value: object) -> bool:
    """색인(`indexer._as_bool`)과 같은 읽기 — 손으로 적은 `"예"` · `1` 도 참."""
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"true", "yes", "y", "1", "예"}


def _number_or_none(value: object) -> float | None:
    try:
        return float(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _day_or_none(value: object) -> str | None:
    """기간 비교용 — 날짜로 읽히는 값만. 손으로 고친 파일의 틀린 값으로 저장 전체를 막지 않는다."""
    try:
        return rules.strict_day(value, "date")
    except ValueError:
        return None


def clone_draft(conn: sqlite3.Connection, source_id: str) -> dict[str, Any]:
    """이 과제를 바탕으로 새 과제 — **미리 채울 값만** 돌려준다 (TODO 109 · 173).

    해마다 도는 과제("2025년 수명평가 표준화" → "2026년 …")는 속성·그룹·담당자·유관부서가
    같다. 지금까지는 처음부터 다시 쳤다. **가져오는 것**은 그 정보와 개요 본문이고,
    **가져오지 않는 것**은 진행일지·보고·첨부·효과 금액·날짜다 — 새 과제의 이력은 비어
    있어야 하고, 효과와 기간은 새로 정할 일이다. 원래 과제를 **선행 과제**로 이어(172) 두 과제가
    한 줄기임이 파일과 상세 위쪽에 보이게 한다.

    여기서는 **만들지 않는다**(173). 처음(109)에는 누르는 순간 만들고 수정 칸을 열었는데, 그 칸의
    [취소]가 만든 과제를 지우지 않아 "취소했는데 과제가 생겼다" — 게다가 번호는 다시 쓰지 않으므로(146)
    취소할 때마다 그해 번호가 하나씩 비었다. 화면이 이 값으로 새 과제 칸을 채우고, [만들기]가
    보통의 과제 만들기(`POST /api/projects`)를 부른다.
    """
    row = conn.execute("SELECT * FROM project WHERE id = ?", (source_id,)).fetchone()
    if row is None:
        raise KeyError(source_id)
    doc = md.load(project_dir(conn, source_id) / "index.md")
    meta = doc.meta
    return {
        "title": str(meta.get("title") or row["title"]),
        "status": "planned",
        "type": meta.get("type"),
        "group": meta.get("group"),
        "tags": list(meta.get("tags") or []),
        "owners": list(meta.get("owners") or []),
        "partners": normalize_partners(meta.get("partners")),
        "no_report": bool(meta.get("no_report")),
        "no_effect": bool(meta.get("no_effect")),
        # 같은 줄기의 과제라 분류도 같다 (TODO 136). 접수 번호는 넘기지 않는다.
        **{key: meta.get(key) for key in CLASSIFICATION_KEYS},
        # 다음 단계 과제 — 원래 과제를 선행으로 잇는다 (TODO 172). 칸에서 뺄 수 있다.
        "predecessors": [source_id],
        "body": doc.body or "",
    }


def clone_project(conn: sqlite3.Connection, source_id: str) -> str:
    """미리 채운 값 그대로 만든다 — 시험과 손으로 부르는 길을 위해 남긴다."""
    return create_project(conn, clone_draft(conn, source_id))


def archive_project(conn: sqlite3.Connection, project_id: str) -> None:
    """삭제하지 않고 .trash/ 로 옮긴다."""
    settings = get_settings()
    directory = project_dir(conn, project_id)
    settings.trash_dir.mkdir(parents=True, exist_ok=True)
    target = paths.unique_path(settings.trash_dir, f"{directory.name}-{datetime.now():%Y%m%d%H%M%S}", "")
    row = conn.execute("SELECT title FROM project WHERE id = ?", (project_id,)).fetchone()
    paths.move(directory, target)
    trash_service.record(
        "project",
        label=f"{project_id} {row['title'] if row else directory.name}",
        moved_to=target,
        origin=directory,
        project_id=project_id,
    )
    conn.execute("DELETE FROM project WHERE id = ?", (project_id,))
    conn.execute("DELETE FROM search_fts WHERE project_id = ?", (project_id,))
    # 이 과제로 착수·병합된 접수는 풀로 돌아간다 — 미아가 되지 않게 (TODO 145)
    from . import intakes as intakes_service

    intakes_service.detach_from_project(conn, project_id, row["title"] if row else directory.name)
    conn.commit()
