from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, StrictBool

from ..deps import get_db
from ..services import renumber as renumber_svc
from ..services import settings as svc
from ..vault.paths import FileInUseError

router = APIRouter(prefix="/api/settings", tags=["settings"])


class SettingsUpdate(BaseModel):
    author: str | None = None
    # 과제 속성별 진행일지 서식. "" 키가 공통 서식이다.
    entry_templates: dict[str, str] | None = None
    # 보고 초안 서식. {summary} 자리에 미보고 진행일지가 들어간다.
    report_template: str | None = None
    # 과제 번호의 팀·부문 코드. 비우면 2026-001, "소재" 면 2026-소재-001.
    project_code: str | None = None
    # 주간 보고를 하는 요일 (0=월 … 6=일). 보고 예정일과 리마인더가 함께 따라간다.
    report_weekday: int | None = None
    # 자동 백업 (바깥쪽 안전망). 폴더를 비우면 꺼진다.
    backup_dir: str | None = None
    backup_keep: int | None = None
    # 층을 나눠 남긴다 — 일 · 주 · 월 (TODO 119)
    backup_keep_weekly: int | None = None
    backup_keep_monthly: int | None = None
    backup_every_hours: int | None = None
    # AI 요약 프롬프트의 앞뒤에 붙일 글. 도구가 AI 를 부르지는 않는다 (TODO 71).
    ai_prompt_prefix: str | None = None
    ai_prompt_suffix: str | None = None
    # 과제 분류 넷의 목록 · 접수 서식 · 묵힘 기준일 (TODO 136)
    classifications: dict[str, list[str] | str] | None = None
    intake_template: str | None = None
    intake_stale_days: int | None = None
    # 사전점검 (TODO 155) — 항목은 설정 칸의 글(한 줄에 하나) 또는 목록, 기준은 [착수 권장, 보완 필요]
    precheck_items: list[dict] | str | None = None
    precheck_thresholds: list[int] | None = None
    # 팀원 면담 (TODO 182) — 구분(한 줄에 하나 또는 목록, 비우면 기본) · 주기(일)
    meeting_kinds: list[str] | str | None = None
    meeting_cycle_days: int | None = None
    # 백업에 첨부를 넣지 않는다 (TODO 202) — 참/거짓만
    backup_skip_assets: StrictBool | None = None
    # 효과 금액 단위 확인 기준선 (TODO 214 D4) — 억원/년, 0 이면 묻지 않음
    effect_confirm_over: float | None = None


@router.get("")
def read_settings() -> dict:
    from ..vault import versions

    return {
        **svc.load(),
        # 설정 파일에서 읽지 못해 기본값을 쓰는 열쇠 — 설정 화면이 한 줄로 알린다 (TODO 163)
        "unreadable": svc.unreadable_keys(),
        # 이전 버전을 남기지 못한 문서 (TODO 206 ㉕) — 긴 경로 등. 점검 자리가 보일 재료, 저장 자체는 됐다.
        "version_keep_failures": versions.keep_failures(),
    }


@router.put("")
def update_settings(payload: SettingsUpdate, conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """설정 저장은 쓰기 잠금 안에서 (TODO 202 ㉓) — 기록 추가가 명부에 이름을 더하는 것과 겹치면 한쪽이 사라졌다."""
    changes = payload.model_dump(exclude_unset=True)
    if "project_code" in changes:
        try:
            changes["project_code"] = svc.validate_project_code(changes["project_code"])
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    if "report_weekday" in changes:
        try:
            changes["report_weekday"] = svc.validate_report_weekday(changes["report_weekday"])
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    if "backup_dir" in changes:
        from ..services.backup import BackupError, validate_dir

        try:
            changes["backup_dir"] = validate_dir(changes["backup_dir"] or "")
        except BackupError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    # 보내지 않은 항목은 건드리지 않는다.
    # save() 안에서도 값을 검사한다(백업 개수·주기 등). 그 거절은 사용자 실수이지
    # 프로그램 고장이 아니므로 400 으로 돌려준다.
    try:
        return svc.save(changes)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/defaults")
def read_defaults() -> dict:
    """설정을 비웠을 때 쓰이는 기본 서식. 화면에서 안내 문구로 보여 준다."""
    from ..config import DEFAULT_ENTRY_TEMPLATE
    from ..services.ai_prompt import DEFAULT_PREFIX
    from ..services import intakes as intakes_service
    from ..services import precheck
    from ..services.reports import DRAFT_TEMPLATE

    return {
        "entry_template": DEFAULT_ENTRY_TEMPLATE,
        "report_template": DRAFT_TEMPLATE,
        "ai_prompt_prefix": DEFAULT_PREFIX,
        "intake_template": intakes_service.DEFAULT_TEMPLATE,
        # 사전점검 기본 목록 — 설정 칸에 보이는 글 모양 (TODO 155)
        "precheck_items": precheck.to_lines(precheck.DEFAULT_ITEMS),
        "precheck_thresholds": list(precheck.DEFAULT_THRESHOLDS),
    }


# ── 과제 속성 (TODO 100) ──────────────────────────────
#
# 속성은 오래 코드에 박혀 있었다. 팀마다 쓰는 말이 다르고, 하나 더하려면 개발자를
# 불러야 했다. 여기서 더하고 빼고 고친다.
#
# **쓰고 있는 속성은 뺄 수 없다.** 빼면 그 과제들이 색인에서 미지정이 된다.
# 몇 건이 쓰고 있는지는 화면이 이미 알고 있어야 하므로 목록과 함께 준다.

class ProjectTypeIn(BaseModel):
    """열쇠를 비워 보내면 새로 짓는다 — 화면에서 갓 더한 줄이다."""

    key: str = ""
    label: str


class ProjectTypesUpdate(BaseModel):
    types: list[ProjectTypeIn]


def _type_counts(conn: sqlite3.Connection) -> dict[str, int]:
    return {
        row["type"]: row["n"]
        for row in conn.execute(
            "SELECT type, COUNT(*) AS n FROM project WHERE type IS NOT NULL AND type <> ''"
            " GROUP BY type"
        )
    }


@router.get("/project-types")
def read_project_types(conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """지금 목록과 **각 속성을 쓰는 과제 수**. 뺄 수 있는지 화면이 알아야 한다."""
    counts = _type_counts(conn)
    return {
        "types": [{**item, "count": counts.get(item["key"], 0)} for item in svc.project_types()],
        # 목록에 없는 열쇠를 쓰는 과제 — 설정 파일을 손으로 고쳤거나 예전 값이다.
        # 그대로 두면 그 과제들이 미지정으로 보이므로 사실을 알려 준다.
        "orphans": [
            {"key": key, "count": count}
            for key, count in sorted(counts.items())
            if key not in {item["key"] for item in svc.project_types()}
        ],
    }


@router.put("/project-types")
def save_project_types(
    payload: ProjectTypesUpdate, conn: sqlite3.Connection = Depends(get_db)
) -> dict:
    try:
        wanted = svc.validate_project_types([item.model_dump() for item in payload.types])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    # 쓰고 있는 속성이 사라지면 그 과제들이 색인에서 미지정이 된다. 먼저 옮기게 한다.
    counts = _type_counts(conn)
    labels = svc.type_labels()
    keeping = {item["key"] for item in wanted}
    lost = [
        f"{labels.get(key, key)}({count}건)"
        for key, count in sorted(counts.items())
        if key not in keeping and count > 0 and key in labels
    ]
    if lost:
        raise HTTPException(
            status_code=400,
            detail=(
                "아직 쓰고 있는 속성은 뺄 수 없습니다: "
                + ", ".join(lost)
                + ". 그 과제들의 속성을 먼저 바꾼 뒤에 빼 주세요."
            ),
        )

    svc.save({"project_types": wanted})
    return read_project_types(conn)


class RenumberRequest(BaseModel):
    """과제 번호를 새 팀 코드로 한 번에 맞춘다."""

    code: str


@router.post("/project-code/renumber/preview")
def preview_renumber(
    payload: RenumberRequest, conn: sqlite3.Connection = Depends(get_db)
) -> dict:
    """무엇이 어떻게 바뀌는지만 돌려준다. 파일은 건드리지 않는다."""
    try:
        return renumber_svc.plan(conn, payload.code)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/project-code/renumber")
def run_renumber(payload: RenumberRequest, conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """미리보기대로 실제로 바꾸고, 설정의 팀 코드도 함께 맞춘다."""
    try:
        result = renumber_svc.apply(conn, payload.code)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileInUseError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    # 번호를 바꿔 놓고 설정이 예전 코드면 다음에 만드는 과제가 또 어긋난다.
    svc.save({"project_code": result["code"]})
    return result


# ── 자동 백업 (바깥쪽 안전망) ─────────────────────────

@router.get("/backup/status")
def backup_status() -> dict:
    from ..services import backup as backup_svc

    return backup_svc.status()


@router.post("/backup/run")
def backup_now(conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """지금 한 벌 내보낸다. 설정을 바꾼 직후 실제로 되는지 확인하는 자리이기도 하다."""
    from ..services import backup as backup_svc

    try:
        return backup_svc.run(conn, reason="manual")
    except backup_svc.BackupError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
