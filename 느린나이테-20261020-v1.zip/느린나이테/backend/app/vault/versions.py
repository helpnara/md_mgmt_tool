"""이전 버전 보관 — 안쪽 안전망.

`.trash` 는 **파일을 지웠을 때**를 막아 준다. 그런데 실무에서 더 자주 나는 사고는
**내용을 잘못 고쳐 저장한 것**이다. 지금까지는 그걸 되돌릴 방법이 없었다.

그래서 문서를 덮어쓰기 **직전에 지금 내용을 한 벌 남긴다.**

    vault/.versions/projects/2026-001-소재/logs/2026-09-01-시험.md/2026-09-03_142205.md

폴더 구조를 그대로 흉내 낸 이유는, **탐색기로 열어도 무엇인지 알 수 있어야** 하기
때문이다. 이 도구의 자료는 전부 사람이 읽을 수 있는 파일이고, 안전망도 같아야 한다.
파일 하나가 통째로 복사되므로 되돌리기는 "그 파일을 도로 쓰기"일 뿐이다.

밖으로 나가는 것은 없다. 폴더 하나가 늘 뿐이다.
"""
from __future__ import annotations

import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from .. import clock
from ..config import get_settings

# 파일 이름에 쓸 시각. 윈도우가 콜론을 못 쓰므로 `_` 와 숫자만 쓴다.
STAMP_FORMAT = "%Y-%m-%d_%H%M%S"
# 기본 보관 기간 (2026-09-02 사용자 확정). 설정에서 조절한다.
DEFAULT_KEEP_DAYS = 365
# 한 문서가 가질 수 있는 최대 버전 수. 같은 문서를 하루에 수십 번 고쳐도
# 폴더가 무한정 늘지 않게 한다. 넘으면 오래된 것부터 버린다.
MAX_PER_DOCUMENT = 200

# 보관에 실패한 문서 — 경로 → 사유 (TODO 206 ㉕). 실패는 삼키되(저장이 멈추면 본말이 뒤바뀐다) **흔적은 남긴다**:
# 긴 경로(윈도우 260자) 같은 이유로 그 문서만 버전이 영영 안 남는데 어디에도 표시가 없었다.
# 문서마다 한 번만, 많아야 KEEP_FAILURE_LIMIT 건. 설정 → 점검(/api/settings · /api/health)이 보인다.
KEEP_FAILURE_LIMIT = 50
KEEP_FAILURES: dict[str, str] = {}


def _vault_relative(path: Path) -> str | None:
    """vault 안의 문서면 상대경로를, 밖이면 None."""
    settings = get_settings()
    try:
        return path.resolve().relative_to(settings.vault_dir.resolve()).as_posix()
    except ValueError:
        return None


def _bucket(rel_path: str) -> Path:
    return get_settings().vault_dir / ".versions" / rel_path


def _meaningful(text: str) -> str:
    """`updated_at` 만 다른 두 벌은 같은 문서로 본다.

    저장할 때마다 이 값이 바뀌므로, 이것까지 따지면 **아무것도 안 고치고 저장 단추만
    눌러도** 버전이 하나 쌓인다. 되돌릴 거리가 없는 버전은 목록만 흐린다.
    """
    return "\n".join(line for line in text.splitlines() if not line.startswith("updated_at:"))


def keep(path: Path, new_text: str | None = None) -> None:
    """덮어쓰기 직전의 내용을 남긴다.

    `new_text` 를 주면 **정말로 바뀌는지 먼저 본다.** 바뀌는 것이 없으면 남기지 않는다.

    **실패해도 저장 자체를 막지 않는다.** 안전망을 만들다가 본 작업이 멈추면
    본말이 뒤바뀐다 (오류 기록과 같은 원칙).
    """
    try:
        if not path.is_file():
            return  # 새로 만드는 파일 — 남길 이전 내용이 없다
        rel = _vault_relative(path)
        # .versions 안의 파일을 또 보관하면 끝이 없다. .trash 도 이미 원본이 남아 있다.
        if rel is None or rel.startswith((".versions/", ".trash/", ".index/", ".logs/")):
            return

        current = path.read_text(encoding="utf-8")
        # 저장해도 달라지는 것이 없으면 버전을 남길 이유가 없다.
        if new_text is not None and _meaningful(current) == _meaningful(new_text):
            return

        bucket = _bucket(rel)
        bucket.mkdir(parents=True, exist_ok=True)
        existing = _stamps(bucket)
        # 직전 버전과도 같으면 남기지 않는다 (바깥에서 파일을 되돌려 놓은 경우 등).
        if existing:
            last = (bucket / f"{existing[-1]}.md").read_text(encoding="utf-8")
            if _meaningful(last) == _meaningful(current):
                return

        target = _free_name(bucket)
        target.write_text(current, encoding="utf-8")
        _prune(bucket)
    except (OSError, ValueError) as exc:
        _note_failure(path, exc)


def _note_failure(path: Path, exc: Exception) -> None:
    """보관 실패를 한 번 적어 둔다 (TODO 206 ㉕). 여기서도 예외는 내지 않는다."""
    try:
        key = _vault_relative(path) or str(path)
    except Exception:
        key = str(path)
    if key in KEEP_FAILURES or len(KEEP_FAILURES) >= KEEP_FAILURE_LIMIT:
        return
    reason = getattr(exc, "strerror", None) or str(exc) or type(exc).__name__
    if isinstance(exc, OSError) and (exc.errno == 36 or "too long" in str(exc).lower() or getattr(exc, "winerror", None) == 206):
        reason = f"경로가 너무 깁니다 (윈도우 260자 제한) — 데이터 폴더를 더 짧은 경로로 옮기면 해결됩니다. {reason}"
    KEEP_FAILURES[key] = f"{type(exc).__name__}: {reason}"[:300]


def keep_failures() -> list[dict[str, str]]:
    """이전 버전을 남기지 못한 문서 목록 — 설정 → 점검에 보일 모양."""
    return [{"path": path, "reason": reason} for path, reason in KEEP_FAILURES.items()]


def _free_name(bucket: Path) -> Path:
    """같은 초에 여러 번 저장했을 때 덮어쓰지 않도록 뒤에 번호를 붙인다.

    번호는 시각 뒤에 오므로 이름순 정렬이 곧 시간순이다 (`…29` < `…29-2` < `…29-3`).
    """
    stamp = datetime.now().strftime(STAMP_FORMAT)
    target = bucket / f"{stamp}.md"
    counter = 2
    while target.exists():
        target = bucket / f"{stamp}-{counter}.md"
        counter += 1
    return target


def _stamps(bucket: Path) -> list[str]:
    """오래된 것부터 정렬한 버전 이름. 이름이 곧 시각이라 문자열 정렬로 충분하다."""
    try:
        if not bucket.is_dir():
            return []
        return sorted(item.stem for item in bucket.glob("*.md") if item.is_file())
    except (OSError, ValueError):
        # 이름이 너무 길거나 쓸 수 없는 글자가 든 경로 — 버전이 없는 것으로 본다 (TODO 167)
        return []


def _prune(bucket: Path) -> None:
    settings = get_settings()
    keep_days = getattr(settings, "version_keep_days", DEFAULT_KEEP_DAYS)
    cutoff = (datetime.now() - timedelta(days=keep_days)).strftime(STAMP_FORMAT)
    stamps = _stamps(bucket)
    doomed = [s for s in stamps if s < cutoff]
    if len(stamps) - len(doomed) > MAX_PER_DOCUMENT:
        doomed = stamps[: len(stamps) - MAX_PER_DOCUMENT]
    for stamp in doomed:
        (bucket / f"{stamp}.md").unlink(missing_ok=True)


def _readable(stamp: str) -> str:
    """`2026-09-03_142205` → `2026-09-03 14:22:05`"""
    parts = stamp.split("-")
    try:
        when = datetime.strptime("-".join(parts[:3]), STAMP_FORMAT).isoformat(sep=" ")
    except ValueError:
        return stamp
    # 같은 초에 여러 벌이 남았으면 번호를 함께 보인다. 시각만 보이면 목록에서
    # 똑같은 줄이 여러 개로 보여 어느 것을 되돌리는지 알 수 없다.
    return f"{when} ({parts[3]})" if len(parts) > 3 else when


def _body_of(text: str) -> str:
    """front matter 를 뗀 본문 — 되돌리기와 *정보만 바뀐 저장* 가리기가 본문을 본다 (TODO 152)."""
    from . import markdown as md

    try:
        return md.loads(text).body.strip()
    except Exception:  # 손으로 고쳐 front matter 가 깨진 파일도 통째로는 견줄 수 있다
        return text.strip()


def list_for(rel_path: str) -> list[dict[str, Any]]:
    """한 문서의 이전 버전. **새 것부터.**

    `body_changed` — 그 버전 **다음 저장이 본문을 바꿨는가**. 과제명·상태만 바꾼 저장도 문서를 다시
    쓰므로 한 벌이 남는데, 되돌리기는 본문만 가져오므로(152) 그런 버전은 되돌려도 달라지는 것이 없다.
    화면은 그것을 *정보만 바뀐 저장* 으로 접는다.
    """
    bucket = _bucket(rel_path)
    try:
        newer = _body_of((get_settings().vault_dir / rel_path).read_text(encoding="utf-8"))
    except OSError:
        newer = None
    items = []
    for stamp in reversed(_stamps(bucket)):
        file = bucket / f"{stamp}.md"
        try:
            body = _body_of(file.read_text(encoding="utf-8"))
            items.append(
                {
                    "stamp": stamp,
                    "saved_at": _readable(stamp),
                    "size_bytes": file.stat().st_size,
                    "body_changed": newer is None or body != newer,
                }
            )
            newer = body
        except OSError:
            continue
    return items


class VersionError(Exception):
    """되돌릴 수 없는 경우 — 이유를 그대로 화면에 보여 준다."""


def _version_file(rel_path: str, stamp: str) -> Path:
    # stamp 는 사용자가 보낸 값이다. 보관 폴더 밖을 가리키지 못하게 한다.
    if "/" in stamp or "\\" in stamp or stamp in ("", ".", ".."):
        raise VersionError("잘못된 버전입니다.")
    file = _bucket(rel_path) / f"{stamp}.md"
    if not file.is_file():
        raise VersionError("그 버전을 찾을 수 없습니다. 보관 기간이 지났을 수 있습니다.")
    return file


def read(rel_path: str, stamp: str) -> str:
    return _version_file(rel_path, stamp).read_text(encoding="utf-8")


def restore(conn, rel_path: str, stamp: str) -> dict[str, Any]:
    """그 버전의 내용을 원래 자리에 도로 쓴다.

    되돌리기도 **하나의 저장**이라, 지금 내용이 먼저 버전으로 남는다.
    즉 되돌린 것이 잘못이었어도 다시 되돌릴 수 있다.
    """
    from ..vault import paths
    from ..vault.indexer import index_project, reindex_all

    settings = get_settings()
    text = read(rel_path, stamp)
    target = paths.safe_join(settings.vault_dir, rel_path)
    if not target.is_file():
        raise VersionError("되돌릴 원본 문서가 없습니다. 문서가 지워졌거나 옮겨졌습니다.")

    # **본문만** 되돌린다 (TODO 152). 문서 하나에 본문과 정보(front matter — 과제명·상태·담당·기간·
    # 접수 번호 …)가 함께 들어 있어, 통째로 덮으면 *개요 글* 을 되돌리려다 과제명·상태까지 그때로 돌아갔다
    # (폴더 이름은 새 이름 그대로 남아 어긋났다). 정보는 [과제 정보 수정]·판정으로만 바뀐다.
    # 저장은 md.save 로 — 지금 내용이 먼저 버전으로 남는다(되돌린 것도 다시 되돌릴 수 있다).
    from . import markdown as md

    old = md.loads(text)
    current = md.load(target)
    meta = dict(current.meta) if current.meta else dict(old.meta)
    if "updated_at" in meta:
        meta["updated_at"] = clock.now().isoformat(timespec="seconds")
    md.save(target, md.MarkdownDoc(meta, old.body))

    # 과제 폴더 안이면 그 과제만, 아니면 통째로 다시 읽는다.
    parts = rel_path.split("/")
    if len(parts) >= 2 and parts[0] == "projects":
        index_project(conn, settings.projects_dir / parts[1])
    else:
        reindex_all(conn)
    conn.commit()
    return {"rel_path": rel_path, "restored_from": _readable(stamp)}


def overview() -> dict[str, Any]:
    """설정 화면에 세우는 요약 — 몇 벌이 얼마나 자리를 쓰고 있나."""
    root = get_settings().vault_dir / ".versions"
    count = 0
    total = 0
    documents = 0
    if root.is_dir():
        # 보관 폴더 이름이 `…시험.md` 처럼 .md 로 끝나므로, 파일만 세도록 걸러야 한다.
        for file in root.rglob("*.md"):
            if not file.is_file():
                continue
            try:
                total += file.stat().st_size
            except OSError:
                continue
            count += 1
        documents = sum(
            1 for item in root.rglob("*")
            if item.is_dir() and any(child.is_file() for child in item.glob("*.md"))
        )
    return {
        "versions": count,
        "documents": documents,
        "total_bytes": total,
        "keep_days": getattr(get_settings(), "version_keep_days", DEFAULT_KEEP_DAYS),
    }


def forget(rel_path: str) -> int:
    """한 문서의 보관본을 모두 지운다. 되돌릴 일이 없다고 판단했을 때."""
    bucket = _bucket(rel_path)
    if not bucket.is_dir():
        return 0
    removed = len(_stamps(bucket))
    shutil.rmtree(bucket, ignore_errors=True)
    return removed


def move_folder(old_rel: str, new_rel: str) -> bool:
    """과제 폴더 이름이 바뀌면 보관본도 따라 옮긴다 (TODO 95).

    보관본은 **경로를 열쇠로 쓴다**. 그래서 폴더 이름만 바뀌어도 그때까지 쌓인 이전
    버전이 통째로 미아가 된다 — 남아 있지만 어느 문서 것인지 화면이 찾지 못한다.
    번호를 옮기는 길이 생겼으니(과제 번호의 연도 고치기) 여기서 함께 옮긴다.

    **실패해도 본 작업을 막지 않는다** — 안전망 때문에 번호 옮기기가 멈추면
    본말이 뒤바뀐다 (`keep` 과 같은 원칙).
    """
    if old_rel == new_rel:
        return False
    try:
        source = _bucket(old_rel)
        if not source.is_dir():
            return False
        target = _bucket(new_rel)
        if target.exists():
            # 이미 그 이름의 보관본이 있다 — 덮지 않고 그대로 둔다. 잃는 것보다 낫다.
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(target))
        return True
    except OSError:
        return False


def follow(source: Path, target: Path) -> bool:
    """이름이 바뀌어 옮긴 문서·폴더의 보관본을 따라 옮긴다 (TODO 142).

    보관본은 **경로를 열쇠로 쓴다** (`move_folder` 참고). 과제명·진행일지 제목·보고일·접수명을
    고치면 폴더나 파일 이름이 따라 바뀌는데(4.1), 그때 보관본을 두고 오면 [이전 버전]이 0건이 된다.
    이름을 바꾸는 자리마다 옮긴 **직후에** 부른다. 폴더든 파일이든 같다 — 파일의 보관본도
    `.versions/<그 파일 경로>/` 라는 폴더다.

    휴지통으로 옮길 때는 부르지 않는다 — 되돌리면 원래 자리로 오므로 보관본도 그 자리에 있어야 한다.
    """
    old_rel = _vault_relative(source)
    new_rel = _vault_relative(target)
    if old_rel is None or new_rel is None:
        return False
    return move_folder(old_rel, new_rel)

