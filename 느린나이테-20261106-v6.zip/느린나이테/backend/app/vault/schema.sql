PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS project (
  id               TEXT PRIMARY KEY,
  dir_name         TEXT NOT NULL UNIQUE,
  title            TEXT NOT NULL,
  status           TEXT NOT NULL,
  type             TEXT,
  grp              TEXT,
  owner            TEXT,
  start_date       TEXT,
  due_date         TEXT,
  created_at       TEXT,
  updated_at       TEXT,
  last_reported_at TEXT,
  -- 과제 효과 (억원/년). 기대효과는 착수 시, 실증효과는 끝난 뒤 채운다.
  effect_expected  REAL,
  effect_verified  REAL,
  -- 금액 아닌 성과 한 줄 (TODO 237 A4) — "작업 시간 40% 단축" 처럼. 효과 금액 옆에 둔다.
  outcome          TEXT,
  -- 별도 보고가 필요 없는 과제 (단순 현황 관리를 과제로 세운 경우).
  -- 보고 대상 후보에서만 빠진다 — 손으로 보고를 남기는 길은 그대로 열려 있다.
  no_report  INTEGER NOT NULL DEFAULT 0,
  -- 효과 금액으로 관리하지 않는 과제 (TODO 125). 유지보수·기획보고처럼 금액으로 재지
  -- 않는 일이 "완료했는데 실증효과 미입력" 에 계속 남으면 그 경고는 곧 안 보게 된다.
  no_effect  INTEGER NOT NULL DEFAULT 0,
  -- 과제를 등록한 사람. 담당자(누가 하는가)와 다르다 (누가 등록했는가).
  -- 나중에 넣으면 그 전 과제는 영영 빈칸이라 지금부터 남긴다.
  created_by       TEXT,
  -- 과제가 끝난 날 (TODO 104). 상태가 완료가 되는 순간 자동으로 남고, 손으로 고칠 수 있다.
  -- 홈의 "올해 끝낸 과제" 가 이 날짜로 센다 — 번호의 연도로는 지난해 시작해 올해 끝낸
  -- 과제가 올해 성과에 잡히지 않는다. 나중에 넣으면 그 전 과제는 영영 빈칸이다.
  completed_at     TEXT,
  -- 과제 분류 넷 (TODO 136). 값은 글자 그대로다 — 목록은 설정에 있다.
  nature           TEXT,
  category         TEXT,
  delivery         TEXT,
  cost_kind        TEXT,
  -- 이 과제가 승격된 접수 번호 (TODO 136). 직접 만든 과제는 NULL.
  intake_id        TEXT,
  body             TEXT,
  file_mtime       REAL
);

-- 과제 접수 (TODO 136). 과제와 **다른 표**다 — 섞으면 반려될 건이 과제 수·효과 합계에 들어간다.
-- 원본은 intakes/<폴더>/request.md 이고, 이 표는 풀 목록과 집계를 위한 파생물이다.
CREATE TABLE IF NOT EXISTS intake (
  id               TEXT PRIMARY KEY,
  dir_name         TEXT NOT NULL UNIQUE,
  title            TEXT NOT NULL,
  status           TEXT NOT NULL,
  leader           TEXT,
  leader_team      TEXT,
  nature           TEXT,
  category         TEXT,
  delivery         TEXT,
  cost_kind        TEXT,
  start_date       TEXT,
  due_date         TEXT,
  effect_request   REAL,
  priority         TEXT,
  priority_note    TEXT,
  picked           INTEGER NOT NULL DEFAULT 0,
  received_on      TEXT,
  decided_on       TEXT,
  decision_note    TEXT,
  project_id       TEXT,
  merged_into      TEXT,
  tags             TEXT,
  created_by       TEXT,
  created_at       TEXT,
  updated_at       TEXT,
  log_count        INTEGER NOT NULL DEFAULT 0,
  attachment_count INTEGER NOT NULL DEFAULT 0,
  last_log_date    TEXT,
  body             TEXT,
  file_mtime       REAL,
  -- 사전점검 (TODO 155) — 합계(다 매겼을 때만, 100점 환산) · 매긴 항목 수 · 항목 수
  precheck_score   INTEGER,
  precheck_rated   INTEGER,
  precheck_total   INTEGER
);

CREATE TABLE IF NOT EXISTS entry (
  id         INTEGER PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  rel_path   TEXT NOT NULL,
  date       TEXT NOT NULL,
  title      TEXT NOT NULL,
  author     TEXT,
  body       TEXT,
  created_at TEXT,
  updated_at TEXT,
  file_mtime REAL,
  UNIQUE(project_id, rel_path)
);

CREATE TABLE IF NOT EXISTS report (
  id          INTEGER PRIMARY KEY,
  project_id  TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  report_date TEXT NOT NULL,
  title       TEXT,
  rel_path    TEXT NOT NULL,
  covers_from TEXT,
  covers_to   TEXT,
  author      TEXT,
  body        TEXT,
  frozen_at   TEXT,
  report_type TEXT,
  audience    TEXT,
  -- 보고 뒤에 받은 지시·질문 (TODO 107). 확정된 보고에서 유일하게 쓸 수 있는 본문이다.
  -- feedback_done 은 다음 보고에서 답한 날 — 비어 있으면 아직 답하지 않은 지시다.
  feedback      TEXT,
  feedback_done TEXT,
  file_mtime  REAL,
  UNIQUE(project_id, rel_path)
);

CREATE TABLE IF NOT EXISTS report_entry (
  report_id INTEGER REFERENCES report(id) ON DELETE CASCADE,
  entry_id  INTEGER REFERENCES entry(id)  ON DELETE CASCADE,
  PRIMARY KEY(report_id, entry_id)
);

CREATE TABLE IF NOT EXISTS attachment (
  id         INTEGER PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  entry_id   INTEGER REFERENCES entry(id) ON DELETE SET NULL,
  report_id  INTEGER REFERENCES report(id) ON DELETE SET NULL,
  rel_path   TEXT NOT NULL,
  orig_name  TEXT NOT NULL,
  mime       TEXT,
  size_bytes INTEGER,
  sha256     TEXT,
  created_at TEXT,
  UNIQUE(project_id, rel_path)
);

-- 과제 담당자 (한 명부터 여러 명까지)
-- 선행 과제 (TODO 172) — 다년도 과제의 앞 단계. **여럿일 수 있다**(앞 단계의 과제 둘을 이어받는 과제).
-- 선행 쪽에는 FK 를 걸지 않는다 — 보관함에 간 과제를 가리켜도 줄은 남아 "찾을 수 없음" 으로 보인다.
CREATE TABLE IF NOT EXISTS project_predecessor (
  project_id     TEXT REFERENCES project(id) ON DELETE CASCADE,
  predecessor_id TEXT NOT NULL,
  PRIMARY KEY(project_id, predecessor_id)
);
CREATE INDEX IF NOT EXISTS idx_predecessor ON project_predecessor(predecessor_id);

CREATE TABLE IF NOT EXISTS project_owner (
  project_id TEXT REFERENCES project(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  position   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(project_id, name)
);

-- 담당과 역할 (TODO 237) — 사람마다 역할 · 맡은 부분 · 담당 기간 · 회고 세 줄. 원본은 index.md 의 `contributions`.
-- 기록이 없는 담당자도 시작일부터 한 줄로 든다(derived = 1). 지금 담당이 아니면 current = 0 (예전 담당).
CREATE TABLE IF NOT EXISTS project_contribution (
  project_id TEXT REFERENCES project(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  role       TEXT,
  part       TEXT,
  from_date  TEXT,
  to_date    TEXT,
  did        TEXT,
  result     TEXT,
  -- 기술 · 도구 (TODO 239) — 쉼표 + 공백으로 이어 적는다
  skills     TEXT,
  -- 팀장의 인정 한 줄과 적은 날 (TODO 242) — 그 사람과 팀장만 본다(API 가 빼고 준다)
  praise     TEXT,
  praise_at  TEXT,
  -- 중간 성과 (TODO 243) — JSON `[{date, text}]`
  milestones TEXT,
  derived    INTEGER NOT NULL DEFAULT 0,
  current    INTEGER NOT NULL DEFAULT 1,
  position   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(project_id, name)
);
CREATE INDEX IF NOT EXISTS idx_contribution_name ON project_contribution(name);

-- 유관부서와 그 담당자 (TODO 92).
--
-- **팀과 사람을 한 칸에 묶어 적지 않는다.** "설비기술팀: 김철수, 박민수" 처럼 한 문자열로
-- 두면 집계도 검색도 그 문자열을 다시 쪼개야 하고, 쪼개는 규칙이 어긋나는 순간
-- 없는 사람이 생긴다 (TODO 74 에서 겪은 것). 그래서 (팀, 사람) 한 쌍이 한 줄이다.
--
-- 담당자를 아직 모르면 person 이 빈 문자열인 줄 하나로 팀만 남는다 —
-- 팀은 정해졌는데 사람은 나중에 정해지는 일이 흔하다.
CREATE TABLE IF NOT EXISTS project_partner (
  project_id TEXT REFERENCES project(id) ON DELETE CASCADE,
  team       TEXT NOT NULL,
  person     TEXT NOT NULL DEFAULT '',
  position   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(project_id, team, person)
);

CREATE INDEX IF NOT EXISTS idx_partner_team ON project_partner(team);
CREATE INDEX IF NOT EXISTS idx_partner_person ON project_partner(person);

CREATE TABLE IF NOT EXISTS tag (
  id   INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS project_tag (
  project_id TEXT REFERENCES project(id) ON DELETE CASCADE,
  tag_id     INTEGER REFERENCES tag(id) ON DELETE CASCADE,
  PRIMARY KEY(project_id, tag_id)
);

CREATE TABLE IF NOT EXISTS entry_tag (
  entry_id INTEGER REFERENCES entry(id) ON DELETE CASCADE,
  tag_id   INTEGER REFERENCES tag(id) ON DELETE CASCADE,
  PRIMARY KEY(entry_id, tag_id)
);

-- 팀원 역량 이력 (TODO 72). 과제와 이어지지 않는 별개의 기록이다.
-- 기록 단위는 **사람**이라, 한 행사에 여러 명이 가면 사람 수만큼 줄이 생긴다.
CREATE TABLE IF NOT EXISTS activity (
  id         INTEGER PRIMARY KEY,
  person     TEXT NOT NULL,
  rel_path   TEXT NOT NULL UNIQUE,   -- people/<이름>/activities/<파일>.md
  date       TEXT NOT NULL,          -- 시작일. 연도 집계도 이 날짜를 본다
  -- 2~3일에 걸친 교육을 위한 종료일. 하루짜리면 비어 있다 (옵션)
  end_date   TEXT,
  kind       TEXT NOT NULL,
  title      TEXT NOT NULL,
  host       TEXT,                   -- 주최
  place      TEXT,
  -- 시간·비용은 **옵션**이다 (2026-09-06 사용자). 비워 두는 것이 정상이다.
  hours      REAL,
  cost       REAL,
  -- 면담에서 실제로 읽게 되는 한 줄. 이 칸 때문에 이 화면을 만든다.
  takeaway   TEXT,
  link       TEXT,                   -- 수료증·자료가 있는 사내 공유 폴더 주소 등
  body       TEXT,
  author     TEXT,
  created_at TEXT,
  updated_at TEXT,
  -- 지난 예정을 홈에서 [다녀옴] 으로 확인한 날 (TODO 231). 비어 있으면 아직 확인하지 않았다
  plan_checked TEXT,
  file_mtime REAL
);

CREATE INDEX IF NOT EXISTS idx_activity_person_date ON activity(person, date DESC);

-- 팀원 면담 (TODO 182). 역량 이력과 **다른 표**다 — 섞으면 "역량 이력 N건" · "면담에서 먼저 볼 사람" 이 거짓이 된다.
-- 원본은 people/<이름>/meetings/<날짜>-<구분>.md. 통합 검색 · AI 요약 · 내보내기에 넣지 않는다(민감한 기록).
CREATE TABLE IF NOT EXISTS meeting (
  id             INTEGER PRIMARY KEY,
  person         TEXT NOT NULL,
  rel_path       TEXT NOT NULL UNIQUE,
  date           TEXT NOT NULL,
  kind           TEXT,
  summary        TEXT,
  -- 하기로 한 것 — [{"text": …, "done": "2026-10-03" | null}] 를 JSON 으로. 열린 수는 따로 센다.
  followups      TEXT,
  open_followups INTEGER NOT NULL DEFAULT 0,
  next_date      TEXT,
  body           TEXT,
  author         TEXT,
  created_at     TEXT,
  updated_at     TEXT,
  file_mtime     REAL
);
CREATE INDEX IF NOT EXISTS idx_meeting_person_date ON meeting(person, date DESC);
CREATE INDEX IF NOT EXISTS idx_activity_date ON activity(date DESC);

CREATE INDEX IF NOT EXISTS idx_entry_project_date ON entry(project_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_report_project_date ON report(project_id, report_date DESC);
CREATE INDEX IF NOT EXISTS idx_attachment_entry ON attachment(entry_id);
