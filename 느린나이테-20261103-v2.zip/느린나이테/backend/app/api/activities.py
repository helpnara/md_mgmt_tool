"""팀원 역량 이력 (TODO 72). 과제와 이어지지 않는 별개의 기록이다."""
from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel

from ..deps import get_db, RowId
from ..services import activities as svc
from ..vault.paths import FileInUseError, InvalidDateError

router = APIRouter(prefix="/api/activities", tags=["activities"])


class ActivityIn(BaseModel):
    # 추가할 때는 "권경락, 김현우" 처럼 여러 명을 받는다. 서버가 사람 수만큼 나눠 만든다.
    person: str | None = None
    date: str | None = None
    # 여러 날에 걸친 교육의 종료일. 하루짜리면 비운다.
    end_date: str | None = None
    kind: str | None = None
    title: str | None = None
    host: str | None = None
    place: str | None = None
    # 시간·비용은 옵션이다. 비워 두는 것이 정상이므로 None 과 "" 를 모두 받는다.
    hours: float | str | None = None
    cost: float | str | None = None
    takeaway: str | None = None
    link: str | None = None
    tags: list[str] | None = None
    body: str | None = None

    def changes(self) -> dict:
        return self.model_dump(exclude_unset=True)


@router.get("")
def list_activities(
    conn: sqlite3.Connection = Depends(get_db),
    person: str | None = None,
    kind: str | None = None,
    year: str | None = Query(None, pattern=r"^(\d{4})?$"),
    q: str | None = None,
    # 예정만 · 지난 것만 (TODO 221). 비우면 모두
    when: str | None = Query(None, pattern=r"^(planned|past)?$"),
) -> list[dict]:
    return svc.listing(conn, person=person or None, kind=kind or None,
                       year=year or None, q=(q or "").strip() or None, when=when or None)


@router.get("/summary")
def summary(
    request: Request,
    conn: sqlite3.Connection = Depends(get_db),
    year: str | None = Query(None, pattern=r"^(\d{4})?$"),
) -> dict:
    data = svc.summary(conn, year=year or None)
    if getattr(request.state, "readonly", False):
        # 읽기 전용 공유 (TODO 191) — 면담은 팀장만 본다(182). 사람 줄의 면담 칸을 비운다
        for item in data["people"]:
            item.update({"meetings": 0, "last_meeting": None, "meeting_days_since": None, "open_followups": 0,
                         "next_meeting": None, "meeting_due": False})
    return data


@router.post("", status_code=201)
def create_activity(payload: ActivityIn, conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """여러 명을 한 번에 받는다 — **사람 수만큼 기록이 생긴다** (TODO 74)."""
    try:
        ids = svc.create(conn, payload.model_dump())
    except InvalidDateError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    # id 하나만 보던 예전 화면이 있어도 깨지지 않게 첫 건을 함께 준다.
    # warnings — 명부에 없는 이름 (TODO 214 D6, 막지 않는다 — 명부에 넣는 것은 화면이 물어본 뒤 POST /api/people)
    return {"ids": ids, "count": len(ids), "id": ids[0],
            "warnings": svc.warnings(svc.split_people(payload.person))}


@router.patch("/{activity_id}")
def update_activity(
    activity_id: RowId, payload: ActivityIn, conn: sqlite3.Connection = Depends(get_db)
) -> dict:
    changes = payload.changes()
    try:
        svc.update(conn, activity_id, changes)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="기록을 찾을 수 없습니다.") from exc
    except InvalidDateError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileInUseError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    # 사람을 바꾼 때만 — 명부에 없는 이름 (TODO 214 D6)
    return {"ok": True, "warnings": svc.warnings(svc.split_people(changes["person"])) if changes.get("person") else []}


@router.delete("/{activity_id}", status_code=204)
def delete_activity(activity_id: RowId, conn: sqlite3.Connection = Depends(get_db)) -> None:
    try:
        svc.delete(conn, activity_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="기록을 찾을 수 없습니다.") from exc
    except FileInUseError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/{activity_id}/plan-check")
def check_plan(activity_id: RowId, conn: sqlite3.Connection = Depends(get_db)) -> dict:
    """홈 "지난 예정 확인" 의 [다녀옴] — 확인한 날만 적는다 (TODO 231)."""
    try:
        return {"plan_checked": svc.check_plan(conn, activity_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="기록을 찾을 수 없습니다.") from exc
    except FileInUseError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
