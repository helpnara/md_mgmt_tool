import { useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { api } from "../api";
import { attempt } from "../notify";
import type { ActivityBrief, BackupStatus, EditItem, Home as HomeData, HomeSlice, Meta, StatusInfo } from "../types";
import { listLink, projectLink, screenLink, useAddressBar } from "../nav";
import { cellEffect, DASH, effectNumber, sumBy, useLatest } from "../util";
import LoadError from "./LoadError";
import CopyTableButton from "./CopyTableButton";
import TotalRow from "./TotalRow";
import { dropDraft, useDrafts } from "../unsaved";
import ProblemsBanner from "./ProblemsBanner";
import { isLeader } from "../people";
import ViewTabs from "./ViewTabs";
import Explain from "./Explain";

/** 기준 연도 옆의 기간 (TODO 110). 서버 home.py 의 PERIODS 와 같은 열쇠다. */
const PERIODS: [string, string][] = [
  ["", "연도 전체"],
  ["H1", "상반기"],
  ["H2", "하반기"],
  ["Q1", "1분기"],
  ["Q2", "2분기"],
  ["Q3", "3분기"],
  ["Q4", "4분기"],
];

/** 상태별 칸을 표 복사용 숫자 줄로 (TODO 108). 화면의 열 순서와 같아야 한다. */
function statusCells(meta: Meta, counts: Record<string, number>): number[] {
  return meta.statuses.map((status) => counts?.[status.key] ?? 0);
}

/**
 * 홈(첫 화면) — TODO 56 · ROADMAP R1.
 *
 * 대시보드가 "지금 무엇을 봐야 하는가"라면 홈은 **"우리 팀이 올해 무엇을 했는가"**다.
 *
 * 지키는 것 셋.
 *  1. **모든 수는 눌러서 그 조건의 목록으로 이어진다** (DESIGN 5.8). 이어지지 않는 수는 넣지 않는다.
 *  2. **기대효과와 실증효과를 절대 합치지 않는다.** 합쳐 놓으면 "그거 확정된 숫자입니까"에 답할 수 없다.
 *  3. **담당 중복을 숨기지 않는다.** 사람별로 더하면 팀 합계를 넘는다. 그 사실을 글자로 적는다.
 */

const ALL_YEARS = "all";
/**
 * 억원/년 — **표 밖**(팀 현황 카드). 목록·과제 상세와 같은 규칙으로 적는다 (util.ts effectNumber, TODO 156).
 * 표 안은 `cellEffect` 다 — 0 이 `-` 로 선다 (TODO 158).
 */
function money(value: number): string {
  return value ? effectNumber(value) : "—";
}

/**
 * 상태 여섯 칸 (예정·검토중·진행중·보류·완료·중단).
 *
 * **순서는 `meta.statuses` 를 그대로 따른다.** 화면에 순서를 다시 적으면 나중에 상태를
 * 하나 더할 때 두 곳이 어긋난다. 팀원별·속성별 두 표가 이 부품을 나눠 쓰므로,
 * 한 화면에서 같은 것을 다르게 세는 일이 생기지 않는다 (TODO 75).
 */
function StatusHead({ statuses }: { statuses: StatusInfo[] }) {
  return (
    <>
      {statuses.map((status) => (
        <th key={status.key}>{status.label}</th>
      ))}
    </>
  );
}

function StatusCells({
  statuses,
  counts,
  link,
}: {
  /** 이 표에 세운 상태 열 — 모든 줄이 빈 상태는 빠져 있다 (TODO 232 ③) */
  statuses: StatusInfo[];
  counts: Record<string, number>;
  /** 그 칸이 가리킬 목록 주소. 0 인 칸은 갈 곳이 없으므로 링크를 걸지 않는다. */
  link: (statusKey: string) => string;
}) {
  return (
    <>
      {statuses.map((status) => {
        const count = counts?.[status.key] ?? 0;
        return (
          // 0 은 흐린 `-` (TODO 158). 칸은 지우지 않는다 — 어디가 비었는지가 이 표의 요점이다 (TODO 75).
          <td key={status.key} className={count ? undefined : "zero"}>
            {count ? <a href={link(status.key)}>{count}</a> : DASH}
          </td>
        );
      })}
    </>
  );
}

/** 상태 여섯 칸의 합계 (TODO 157). 줄마다 더한 값을 `meta.statuses` 순서로. */
function statusTotals(statuses: StatusInfo[], rows: { by_status: Record<string, number> }[]): string[] {
  return statuses.map((status) => {
    const total = sumBy(rows, (row) => row.by_status?.[status.key] ?? 0);
    return total ? String(total) : DASH;
  });
}

/**
 * 빈 열 숨기기 (TODO 232 ③). **모든 줄이 빈** 상태 열만 화면에서 뺀다 — 한 줄이라도 있으면 남는다.
 * 줄 안의 빈 칸은 그대로 `-` 다(TODO 75 · 158 — 어디가 비었는지가 표의 요점). 통째로 빈 열은 그 팀이 안 쓰는
 * 상태라 칸만 늘린다(가상 데이터에서 홈 표 칸의 43% 가 `-`). 뺀 열은 표 아래 한 줄로 밝히고, [표 복사]는 전체 열 그대로다.
 */
function usedStatuses(meta: Meta, rows: { by_status: Record<string, number> }[]): StatusInfo[] {
  return meta.statuses.filter((status) => rows.some((row) => (row.by_status?.[status.key] ?? 0) > 0));
}

function HiddenColumns({ names }: { names: string[] }) {
  if (names.length === 0) return null;
  return (
    <p className="hint hidden-cols">
      숨긴 열: {names.join(" · ")} — 이 표에서 모두 비어 있습니다. [표 복사]에는 들어갑니다.
    </p>
  );
}

/** 제목과 [표 복사] — 단추를 제목 **밖**에 둔다(화면 낭독기가 제목을 "속성별 표 복사" 로 읽었다, TODO 232 H) */
function CardTitle({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="card-title-row">
      <h2>{children}</h2>
      {actions}
    </div>
  );
}

/** 1년을 넘긴 경과일은 "D+1368" 보다 "3년 넘음" 이 읽힌다 (TODO 232 H). 정확한 날수는 마우스를 올리면 */
function sinceText(days: number | null): string {
  if (days === null) return "D+?";
  return days >= 365 ? `${Math.floor(days / 365)}년 넘음` : `D+${days}`;
}

/** 그룹 표는 자유 입력이라 길어질 수 있다. 이만큼만 세우고 나머지는 접는다. */
const SLICE_LIMIT = 8;

/**
 * 속성별·그룹별 표 (TODO 90).
 *
 * 두 표가 **같은 부품**을 쓴다. 따로 짜면 언젠가 한쪽만 고치게 되고,
 * 같은 화면의 두 표가 다르게 세기 시작한다 (팀원별·속성별에서 배운 것, TODO 75).
 */
function SliceTable({
  meta,
  title,
  column,
  rows,
  param,
  yearParam,
  note,
  more,
}: {
  meta: Meta;
  title: string;
  /** 첫 열의 이름 — "속성" 또는 "그룹" */
  column: string;
  rows: (HomeSlice & { filter?: Record<string, string> })[];
  /** 목록을 거를 때 쓸 질의 이름 */
  param: "type" | "group" | "nature" | "category";
  yearParam: string;
  /** 표 아래 설명의 첫 문장 — 늘 보인다 */
  note: ReactNode;
  /** 나머지 설명 — [설명 ▾] 로 접힌다 (TODO 232 ④) */
  more?: ReactNode;
}) {
  const [all, setAll] = useState(false);
  if (rows.length === 0) return null;
  const statuses = usedStatuses(meta, rows);
  const showExpected = rows.some((item) => item.effect_expected);
  const showVerified = rows.some((item) => item.effect_verified);
  const hidden = [
    ...meta.statuses.filter((status) => !statuses.includes(status)).map((status) => status.label),
    ...(showExpected ? [] : ["기대효과"]),
    ...(showVerified ? [] : ["실증효과"]),
  ];
  const shown = all ? rows : rows.slice(0, SLICE_LIMIT);
  // 서버가 거르기 조건을 함께 주면 그것을 쓴다 (성격별·분류별의 *미지정* 줄은 조건이 둘이다 — TODO 136).
  // 세는 곳과 거르는 곳이 같아야 한다 (DESIGN 5.8).
  const link = (item: HomeSlice & { filter?: Record<string, string> }, status?: string) =>
    listLink({ ...(item.filter ?? { [param]: item.key }), ...(status ? { status } : {}), year: yearParam });

  return (
    // 속성별과 그룹별을 이름으로 가려낼 수 있어야 한다 — 시험이 둘을 헷갈리면
    // 어느 표를 보고 있는지 모른 채 통과할 수 있다.
    <div className={`card home-types home-slice-${param}`}>
      <CardTitle
        actions={
        <CopyTableButton
          headers={[column, "과제", ...meta.statuses.map((status) => status.label), "기대효과(억원/년)", "실증효과(억원/년)"]}
          rows={() =>
            rows.map((item) => [
              item.label,
              item.count,
              ...statusCells(meta, item.by_status),
              item.effect_expected,
              item.effect_verified,
            ])
          }
        />
        }
      >
        {title}
      </CardTitle>
      <div className="table-scroll">
        <table className="grid home-member-table">
          <thead>
            <tr>
              <th>{column}</th>
              <th>과제</th>
              <StatusHead statuses={statuses} />
              {showExpected && (
                <th>
                  기대효과<span className="th-unit">억원/년</span>
                </th>
              )}
              {showVerified && (
                <th>
                  실증효과<span className="th-unit">억원/년</span>
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {shown.map((item) => (
              <tr key={item.key}>
                <td>
                  <a href={link(item)}>{item.label}</a>
                </td>
                <td>{item.count || DASH}</td>
                <StatusCells
                  statuses={statuses}
                  counts={item.by_status}
                  link={(status) => link(item, status)}
                />
                {showExpected && <td>{cellEffect(item.effect_expected)}</td>}
                {showVerified && <td>{cellEffect(item.effect_verified)}</td>}
              </tr>
            ))}
          </tbody>
          {/* 접어 둔 줄까지 **표 전체**를 더한다 — 접기는 보기 편하려는 것이지 거르기가 아니다 (TODO 157) */}
          <TotalRow
            label="합계"
            cells={[
              String(sumBy(rows, (item) => item.count) || DASH),
              ...statusTotals(statuses, rows),
              ...(showExpected ? [cellEffect(sumBy(rows, (item) => item.effect_expected))] : []),
              ...(showVerified ? [cellEffect(sumBy(rows, (item) => item.effect_verified))] : []),
            ]}
          />
        </table>
      </div>
      {rows.length > SLICE_LIMIT && (
        <button type="button" className="ghost small" onClick={() => setAll((on) => !on)}>
          {all ? "접기" : `나머지 ${rows.length - SLICE_LIMIT}개 더 보기`}
        </button>
      )}
      <HiddenColumns names={hidden} />
      <Explain id={`home-slice-${param}`} lead={note}>
        {more}
      </Explain>
    </div>
  );
}

/**
 * 자동 백업에 문제가 있을 때만 돌려주는 한 줄 (TODO 106-A). 정상이면 null — 홈에 늘
 * "백업 정상" 이 떠 있으면 곧 안 보게 된다.
 *
 * 문제로 보는 것 셋: 폴더에 닿지 않는다 · 마지막 시도가 실패했다 · 마지막 성공이
 * 주기의 두 배를 넘겼다(프로그램을 안 켜 둔 날이 이어졌다는 뜻이라 알려 줄 일이다).
 */
function backupWarning(status: BackupStatus | null): string | null {
  if (!status || !status.enabled) return null;
  if (!status.reachable) return "폴더에 닿지 않습니다 — 네트워크 드라이브가 끊겼거나 폴더가 사라졌을 수 있습니다.";
  if (status.last && !status.last.ok) return `마지막 시도가 실패했습니다 (${status.last.at.slice(0, 16)}).`;
  if (status.last && status.last.ok) {
    const hours = (Date.now() - new Date(status.last.at).getTime()) / 36e5;
    if (hours > status.every_hours * 2) {
      const days = Math.floor(hours / 24);
      return `마지막 백업이 ${days >= 1 ? `${days}일` : `${Math.floor(hours)}시간`} 전입니다 (주기 ${status.every_hours}시간).`;
    }
  }
  return null;
}

/** 팀원이 늘면 표가 계속 길어진다. 속성별·그룹별과 같은 규칙으로 접는다 (TODO 123). */
const MEMBER_LIMIT = 10;

export default function Home({ meta, onMetaChange, query = "" }: { meta: Meta; onMetaChange?: () => void; query?: string }) {
  const thisYear = String(new Date().getFullYear());
  // 기준 연도 · 기간은 주소에 (TODO 210 ④) — 지난해를 보다 숫자를 눌러 목록에 갔다 "← 홈" 하면 올해로 돌아왔다
  const [year, setYear] = useState(() => new URLSearchParams(query).get("year") || thisYear);
  // 반기·분기 (TODO 110). 연도 전체를 볼 때는 뜻이 없으므로 그때는 보내지 않는다.
  const [period, setPeriod] = useState(() => new URLSearchParams(query).get("period") ?? "");
  // 화면 안 탭 (TODO 232 ①) — "" = [할 일] · "status" = [팀 현황]. 주소에 남아 "← 홈" 이 보던 탭으로 돌아온다
  const [tab, setTab] = useState(() => (new URLSearchParams(query).get("tab") === "status" ? "status" : ""));
  useAddressBar(
    "",
    Object.fromEntries(
      Object.entries({ tab, year: year === thisYear ? "" : year, period: year === ALL_YEARS ? "" : period }).filter(([, value]) => value),
    ) as Record<string, string>,
    (params) => {
      setTab(params.get("tab") === "status" ? "status" : "");
      setYear(params.get("year") || thisYear);
      setPeriod(params.get("period") ?? "");
    },
  );
  // 탭을 바꾸면 주소는 그린 **뒤에** 고쳐진다(useAddressBar) — 그 탭에서 그린 링크의 "← 홈" 이 옛 주소(탭 없음)를 물고 있었다.
  // 주소가 바뀐 뒤 한 번 더 그려 링크가 새 주소를 물게 한다 (TODO 232)
  const [, redraw] = useState(0);
  useEffect(() => redraw((n) => n + 1), [tab]);
  const [allMembers, setAllMembers] = useState(false);
  const [data, setData] = useState<HomeData | null>(null);
  // 연도별 추이가 넘치면 올해가 보이게 (TODO 228)
  const trendRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const row = trendRef.current;
    const current = row?.querySelector<HTMLElement>(".when-current");
    if (row && current && row.scrollWidth > row.clientWidth) row.scrollLeft = Math.max(0, current.offsetLeft - row.clientWidth / 2);
  }, [data]);
  const [error, setError] = useState<string | null>(null);
  // 자동 백업이 죽어 있어도 홈은 몰랐다 (TODO 106-A). 문제가 있을 때만 한 줄 띄운다.
  const [backup, setBackup] = useState<BackupStatus | null>(null);
  // 작성 중이던 글 (TODO 170) — 창으로 돌아올 때마다 다시 읽는다
  const drafts = useDrafts();
  // 팀원이 고친 것 — 최근 7일 (TODO 233 ⑥). 팀장만 본다(바깥에는 막혀 있다)
  const [teamEdits, setTeamEdits] = useState<EditItem[]>([]);
  useEffect(() => {
    // 읽기 전용 공유(191)에는 설정이 닫혀 있다 — 백업 상태는 주인만 본다
    if (document.body.classList.contains("readonly")) return;
    api.backupStatus().then(setBackup).catch(() => setBackup(null));
    api.recentEdits().then((data) => setTeamEdits(data.items)).catch(() => setTeamEdits([]));
  }, []);

  // 연도를 빨리 두 번 바꾸면 앞 요청이 늦게 와 다른 해 숫자가 남을 수 있다 — 마지막 것만 받는다 (TODO 210 ①).
  // 새 값이 올 때까지는 옛 숫자를 흐리게 둔다(aria-busy) — 바뀐 줄 알고 읽지 않게 (TODO 210 ②)
  const latest = useLatest();
  const [reloading, setReloading] = useState(false);
  const load = useCallback(() => {
    const mine = latest();
    setReloading(true);
    api
      .home(year === ALL_YEARS ? "" : year, year === ALL_YEARS ? "" : period)
      .then((next) => {
        if (!mine()) return;
        setData(next);
        setError(null);
      })
      .catch((err: Error) => mine() && setError(err.message))
      .finally(() => mine() && setReloading(false));
  }, [year, period, latest]);

  useEffect(load, [load]);

  if (error) return <LoadError message={error} onRetry={load} />;
  if (!data) return <p className="hint">불러오는 중…</p>;

  const yearParam = year === ALL_YEARS ? "" : year;
  const { team, this_week: week } = data;
  // 스마트과제 수 · 다른 속성인데 성격 · 분류가 적힌 과제 (TODO 229)
  const smartCount = data.types.find((row) => row.key === meta.classified_type)?.count ?? 0;
  const outside = data.classified_outside ?? { nature: 0, category: 0 };
  const outsideNote = outside.nature || outside.category ? (
    <> 다른 속성인데 성격이 적힌 과제 {outside.nature}건 · 분류가 적힌 과제 {outside.category}건도 그 줄에 셉니다.</>
  ) : null;
  // 팀원 일정 한 줄 (TODO 221) — 여러 날이면 기간, 같은 해면 뒤쪽은 월 · 일만
  const activityKind = (key: string) => meta.activity_kinds.find((item) => item.key === key)?.label ?? key;
  const leftChipText = (item: ActivityBrief) =>
    item.ongoing ? "진행 중" : item.days_left === 0 ? "오늘" : `D-${item.days_left ?? "?"}`;
  const leftChipClass = (item: ActivityBrief) =>
    `left-chip ${item.ongoing || item.days_left === 0 ? "left-now" : (item.days_left ?? 99) <= 7 ? "left-soon" : "left-later"}`;
  const briefPeriod = (item: ActivityBrief) =>
    item.end_date ? `${item.date} ~ ${item.end_date.slice(0, 4) === item.date.slice(0, 4) ? item.end_date.slice(5) : item.end_date}` : item.date;

  // ── 아직 아무것도 없을 때 ──────────────────────────────────────────
  // 0 이 여덟 개 늘어선 대시보드는 처음 켠 사람에게 아무것도 알려 주지 않는다.
  // 이 도구는 다른 팀장에게 배포해 쓰는 것이 목표라, **첫 5분이 곧 채택 여부**다.
  // 과제가 하나도 없는 동안에는 지표 대신 **다음에 할 일**을 세운다 (TODO 84).
  if (data.years.length === 0 && team.total === 0) {
    return (
      <section className="home">
        <div className="card home-start">
          <h1>느린 나이테를 시작합니다</h1>
          <p className="hint">
            과제 하나가 폴더 하나입니다. 진행일지와 첨부가 그 안에 함께 쌓이고,
            모두 <b>보통의 마크다운 파일</b>이라 이 도구 없이도 탐색기에서 그대로 읽힙니다.
          </p>
          <ol className="home-steps">
            <li>
              <b>작성자와 담당자 명부를 정합니다</b>
              <span className="hint">
                진행일지·보고에 누가 썼는지 남고, 담당자 칸에서 이름을 눌러 넣게 됩니다.
              </span>
              <a className="home-step-go" href={screenLink("settings")}>
                설정 열기 →
              </a>
            </li>
            <li>
              <b>첫 과제를 만듭니다</b>
              <span className="hint">
                제목만 있으면 됩니다. 상태·담당자·마감은 나중에 채워도 됩니다.
              </span>
              <a className="home-step-go primary" href={listLink({ new: "1" })}>
                과제 만들기 →
              </a>
            </li>
            <li>
              <b>진행일지를 씁니다</b>
              <span className="hint">
                과제 상세에서 [기록 추가]. 그림은 Ctrl+V, 엑셀 표는 붙여넣으면 표로 바뀝니다.
                기록이 쌓이면 보고 초안이 자동으로 만들어집니다.
              </span>
            </li>
          </ol>
          <p className="hint">
            과제가 하나라도 생기면 이 자리에 <b>그 해 팀 현황과 팀원별 성과</b>가 들어섭니다.
          </p>
        </div>
      </section>
    );
  }

  const memberSum = data.members.reduce((sum, item) => sum + item.total, 0);
  const maxCompare = Math.max(1, ...data.compare.map((item) => item.total));
  // 팀원별 표의 빈 열 (TODO 232 ③) — 모든 사람이 빈 열만 뺀다
  const memberStatuses = usedStatuses(meta, data.members);
  const memberCols = {
    expected: data.members.some((member) => member.effect_expected),
    verified: data.members.some((member) => member.effect_verified),
    reports: data.members.some((member) => member.reports),
    activities: data.members.some((member) => member.activities),
    last: data.members.some((member) => member.last_reported_at),
  };
  const memberHidden = [
    ...meta.statuses.filter((status) => !memberStatuses.includes(status)).map((status) => status.label),
    ...(memberCols.expected ? [] : ["기대효과"]),
    ...(memberCols.verified ? [] : ["실증효과"]),
    ...(memberCols.reports ? [] : ["보고 횟수"]),
    ...(memberCols.activities ? [] : ["역량 이력"]),
    ...(memberCols.last ? [] : ["마지막 보고"]),
  ];
  // 0 인 숫자 칸은 흐리게 — 자리는 그대로 둔다(위치로 기억하므로, TODO 232 B)
  const statClass = (count: number, alert = "") => ["home-stat go", count ? alert : "zero-stat"].filter(Boolean).join(" ");

  // ── [할 일] 탭 — 매일 여는 이유 (TODO 232 ①) ─────────────────────────────
  const scheduleSide = (week.team_upcoming?.items.length ?? 0) > 0 || (week.team_missed?.length ?? 0) > 0 || teamEdits.length > 0;
  const reportSide = drafts.length > 0 || week.drafts > 0 || week.stale.length > 0 || week.owner_gaps_total > 0 || week.plans.length > 0;
  const todo = (
    <div className="card home-week">
      <h2>
        이번 주 할 일
        <span className="hint"> · 보고 예정일 {week.report_date}</span>
      </h2>
      <div className="home-week-row">
        {/* 접수 풀 (TODO 136) — 과제 수와 섞지 않고 따로 선다. 풀이 비어 있으면 세우지 않는다. */}
        {data.intakes.pool > 0 && (
          <a className="home-stat go intake-stat" href={screenLink("intakes")}>
            <span className="home-stat-label">접수 풀</span>
            <strong>{data.intakes.pool}건</strong>
            {data.intakes.stale > 0 && (
              <span className="home-stat-note warn-text">묵힘 {data.intakes.stale}건</span>
            )}
          </a>
        )}
        <a className={statClass(week.candidates)} href={screenLink("reports")}>
          <span className="home-stat-label">보고 대상</span>
          <strong>{week.candidates}건</strong>
        </a>
        <a className={statClass(week.overdue, "danger")} href={listLink({ due: "overdue", year: yearParam })}>
          <span className="home-stat-label">기한 초과</span>
          <strong>{week.overdue}건</strong>
        </a>
        <a className={statClass(week.due_soon, "warn")} href={listLink({ due: "7", year: yearParam })}>
          <span className="home-stat-label">마감 임박 (7일)</span>
          <strong>{week.due_soon}건</strong>
        </a>
        {/* 쓰다 만 보고 (TODO 101). 배너는 보고하는 날에만 뜨므로, 지난주에 쓰다 만
            것은 다음 보고일까지 아무 데도 보이지 않았다. 여기서 계속 들고 있는다. */}
        <a
          className={statClass(week.drafts, week.drafts_overdue ? "danger" : "")}
          href={screenLink("reports")}
          title="보고 대상 화면 맨 위의 [확정을 기다리는 초안] 으로 갑니다"
        >
          <span className="home-stat-label">작성 중인 보고</span>
          <strong>{week.drafts}건</strong>
        </a>
      </div>

      {/* 넓으면 두 단 — 왼쪽은 팀원 일정, 오른쪽은 보고 · 과제 (232 뒤 사용자: "가득 차 보이게"). 한쪽이 비면 한 단 */}
      <div className={scheduleSide && reportSide ? "home-week-cols two" : "home-week-cols"}>
      {scheduleSide && <div className="home-week-col">
      {/* 다가오는 팀원 일정 · 지난 예정 확인 (TODO 221) — 팀원 역량에 예정으로 적은 교육 · 행사. 30일 안 모두(232 ⑦ 그대로) */}
      {(week.team_upcoming?.items.length ?? 0) > 0 && (
        <>
          <p className="hint">
            <b>다가오는 팀원 일정</b> — 앞으로 {week.team_upcoming!.days}일 안에 예정한 교육 · 행사, 그리고 지금 진행 중인 것입니다.
          </p>
          <ul className="home-stale home-upcoming">
            {week.team_upcoming!.items.map((item) => (
              <li key={item.id}>
                {/* 남은 날 띠지 (TODO 226) — 오늘이면 "오늘", 진행 중이면 "진행 중", 아니면 D-N. 일주일 안은 진하게 */}
                <span className={leftChipClass(item)}>{leftChipText(item)}</span>
                <span className="due">{briefPeriod(item)}</span>
                {/* 진행 중인 것은 이미 시작해 '예정' 이 아니다 — 예정만으로 거르면 빈 목록이 된다 */}
                <a href={screenLink("skills", { tab: "records", person: item.person, year: item.date.slice(0, 4), when: item.ongoing ? undefined : "planned" })}>
                  {item.title}
                </a>
                <span className="muted">
                  {item.person} · {activityKind(item.kind)}
                  {item.place ? ` · ${item.place}` : ""}
                </span>
              </li>
            ))}
          </ul>
          {week.team_upcoming!.later > 0 && (
            <p className="hint">
              <a href={screenLink("skills", { tab: "records", when: "planned", year: "all" })}>
                그 뒤 예정 {week.team_upcoming!.later}건도 팀원역량에서 보기 →
              </a>
            </p>
          )}
        </>
      )}
      {(week.team_missed?.length ?? 0) > 0 && (
        <>
          <Explain
            id="home-missed"
            lead={<><b>지난 예정 확인</b> — 예정으로 적었던 일정이 지났습니다. <b>[다녀옴]</b> 이면 이 줄에서 내려가고 팀원역량에 이력으로 남습니다.</>}
          >
            안 갔으면 <b>[안 감 — 지우기]</b>(삭제 보관함으로). 얻은 것 · 시간은 팀원역량에서 채웁니다. (누르지 않아도 2주가 지나면 내려갑니다)
          </Explain>
          <ul className="home-stale home-missed">
            {week.team_missed!.map((item) => (
              <li key={item.id}>
                <span className="due">{briefPeriod(item)}</span>
                <a href={screenLink("skills", { tab: "records", person: item.person, year: item.date.slice(0, 4) })}>{item.title}</a>
                <span className="muted">{item.person} · {activityKind(item.kind)}</span>
                {/* 확인하고 내린다 (TODO 231) — 다녀옴은 확인한 날만 적고, 안 감은 지금의 삭제(보관함으로) */}
                <span className="grow" />
                <button data-write className="ghost small" onClick={async () => {
                  if (await attempt(() => api.checkActivityPlan(item.id))) load();
                }}>
                  다녀옴
                </button>
                <button className="ghost small danger" onClick={async () => {
                  if (!window.confirm(`${item.person} 님의 '${item.title}' — 가지 않은 일정이면 삭제 보관함으로 옮길까요?`)) return;
                  if (await attempt(() => api.deleteActivity(item.id))) load();
                }}>
                  안 감 — 지우기
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      {/* 팀원이 고친 것 — 최근 7일 (TODO 233 ⑥). 등록한 IP 의 팀원이 담당 과제에서 고친 것 — 같은 날 같은 일은 한 줄로 */}
      {teamEdits.length > 0 && (
        <>
          <p className="hint">
            <b>팀원이 고친 것</b> — 최근 7일, 명부에 IP 를 적은 PC 에서 담당 과제의 진행일지 · 첨부 · 개요를 고친 기록입니다.
          </p>
          <ul className="home-stale home-edits">
            {teamEdits.slice(0, 8).map((item, index) => (
              <li key={`${item.at}-${index}`}>
                <span className="due">{item.at.slice(5, 16).replace("T", " ")}</span>
                <b>{item.name}</b>
                {item.leader && <span className="tag leader-tag" title="명부의 팀장 — 서버 PC 가 아닌 곳(팀장 줄에 적은 IP)에서 고친 것">팀장</span>}
                {item.project_id ? (
                  <a href={projectLink(item.project_id, item.entry_id && item.action !== "진행일지 삭제" ? { entry: item.entry_id } : {})}>
                    {item.project_title ?? item.project_id}
                  </a>
                ) : null}
                <span className="edit-action">
                  {item.action}
                  {item.count > 1 ? ` ${item.count}번` : ""}
                </span>
              </li>
            ))}
          </ul>
          {teamEdits.length > 8 && <p className="hint">그 앞 {teamEdits.length - 8}줄은 접어 두었습니다.</p>}
        </>
      )}
      </div>}
      {reportSide && <div className="home-week-col">
      {/* 쓰다 만 글 (TODO 170) — 어느 과제에서 쓰다 말았는지 기억하지 않아도 되게, 누르면 그 편집기로 */}
      {drafts.length > 0 && (
        <>
          <p className="hint">
            <b>작성 중이던 글 {drafts.length}건</b> — 저장하지 않고 남은 글입니다. 누르면 그 편집기가 열리고 글이 되살아납니다.
          </p>
          <ul className="home-drafts home-unsaved">
            {drafts.map((item) => (
              <li key={item.key}>
                {item.link && !item.missing ? (
                  <a href={item.link}>{item.where || item.label}</a>
                ) : (
                  <span className="muted">{item.where || item.label} (찾을 수 없음)</span>
                )}
                <span className="due">{item.label}</span>
                {item.updated_at && <span className="muted">{item.updated_at.slice(5, 16).replace("T", " ")}</span>}
                <button
                  className="ghost small"
                  title="남은 글을 지웁니다 — 되돌릴 수 없습니다"
                  onClick={() => {
                    if (window.confirm(`"${item.where || item.label}" 의 ${item.label} — 작성 중이던 글을 버릴까요?`))
                      dropDraft(item.key);
                  }}
                >
                  버리기
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      {week.drafts > 0 && (
        <>
          <p className="hint">
            <b>아직 확정하지 않은 보고</b> — 확정해야 보고 이력에 남고, 그 진행일지가
            미보고에서 빠집니다.
            {week.drafts_overdue > 0 && (
              <>
                {" "}그중 <b className="warn-text">{week.drafts_overdue}건</b>은 보고일이
                이미 지났습니다.
              </>
            )}
          </p>
          <ul className="home-drafts">
            {week.draft_items.map((item) => (
              <li key={item.id}>
                {/* 이름을 적어 놓고 목록으로 보내면 그 한 건을 다시 찾아야 한다 (TODO 91) */}
                <a href={projectLink(item.project_id, { report: item.id })}>
                  {item.project_title}
                </a>
                <span className={item.overdue_days > 0 ? "due due-danger" : "due"}>
                  {item.report_date}
                  {item.overdue_days > 0 && ` · D+${item.overdue_days}`}
                </span>
                {item.audience && <span className="muted">{item.audience}</span>}
              </li>
            ))}
          </ul>
          {week.drafts > week.draft_items.length && (
            <p className="hint">
              <a href={screenLink("reports")}>
                나머지 {week.drafts - week.draft_items.length}건도 보고 대상 화면에서 보기 →
              </a>
            </p>
          )}
        </>
      )}
      {week.stale.length > 0 && (
        <>
          <p className="hint">
            <b>오래 보고되지 않은 과제</b> — 이번 주에 할 일이라기보다, 이미 새어 나간 것입니다.
          </p>
          <ul className="home-stale">
            {week.stale.map((item) => (
              <li key={item.id}>
                <a href={projectLink(item.id)}>{item.title}</a>
                <span className="due due-danger" title={`D+${item.days_since_report}`}>
                  {sinceText(item.days_since_report)}
                </span>
                <span className="muted">
                  {item.never_reported ? "보고 이력 없음" : `마지막 보고 ${item.last_reported_at}`}
                </span>
              </li>
            ))}
          </ul>
          {/* 세 건만 세우고 잘렸다고 말하지 않으면 세 건만 있는 줄 안다 (TODO 103-B) */}
          {week.stale_total > week.stale.length && (
            <p className="hint">
              <a href={screenLink("reports")}>
                나머지 {week.stale_total - week.stale.length}건도 보고 대상 화면에서 보기 →
              </a>
            </p>
          )}
        </>
      )}
      {/* 떠난 담당자가 그대로 남아 있는 끝나지 않은 과제 (TODO 122).
          "지금 사람이 없는 일" 이라 보고보다 먼저 정해야 한다. */}
      {week.owner_gaps_total > 0 && (
        <>
          <p className="hint">
            <b>대체 담당자 지정 필요</b> —{" "}
            <a href={listLink({ owner_left: "1" })}>
              {week.owner_gaps_total}건 보기 →
            </a>
          </p>
          <ul className="home-owner-gaps" data-testid="owner-gaps">
            {week.owner_gaps.map((item) => (
              <li key={`${item.id}-${item.owner}`}>
                <a href={projectLink(item.id)}>{item.title}</a>
                <span className="tag left-tag">
                  {item.owner} {item.left_reason || "떠남"}
                </span>
                <span className="muted">{item.left_on}</span>
              </li>
            ))}
          </ul>
          {week.owner_gaps_total > week.owner_gaps.length && (
            <p className="hint">
              <a href={listLink({ owner_left: "1" })}>
                나머지 {week.owner_gaps_total - week.owner_gaps.length}건도 목록에서 보기 →
              </a>
            </p>
          )}
        </>
      )}
      {/* 과제별 다음 할 일 — 최근 진행일지의 계획 칸 (TODO 112). 이미 적어 둔 것을 올릴 뿐이다. */}
      {week.plans.length > 0 && (
        <>
          <p className="hint">
            <b>다음 할 일</b> — 진행일지의 <code>## 계획</code>에 적어 둔 것입니다.
          </p>
          <ul className="home-plans" data-testid="home-plans">
            {week.plans.map((item) => (
              <li key={item.entry_id}>
                <a href={projectLink(item.project_id, { entry: item.entry_id })}>{item.project_title}</a>
                <span className="plan-text">{item.text}</span>
                <span className="muted">{item.date}</span>
              </li>
            ))}
          </ul>
          {week.plans_total > week.plans.length && (
            <p className="hint">나머지 {week.plans_total - week.plans.length}건은 각 과제 위쪽에 있습니다.</p>
          )}
        </>
      )}
      </div>}
      </div>
    </div>
  );

  // ── [팀 현황] 탭 — 보고 때 보는 표들 (TODO 232 ①) ────────────────────────
  const status = (
    <>
      {/* 팀 현황 · 연도별 추이를 나란히 (TODO 123) — 좁은 화면에서는 한 줄씩 선다 */}
      <div className="home-top home-status-top">
        <div className="card home-team">
          <h2>{year === ALL_YEARS ? "전체" : `${year}년`} 팀 현황</h2>
          <div className="home-stats">
            {/* 과제 = 그 해에 수행한 과제(수행기간이 그 해와 겹침) — 다년도 과제는 해마다 하나씩 (TODO 181) */}
            <a
              className="home-stat"
              href={listLink({ year: yearParam })}
              title={yearParam ? "그 해에 수행한 과제 — 여러 해에 걸친 과제는 해마다 셉니다" : undefined}
            >
              <span className="home-stat-label">과제</span>
              <strong>{team.total}건</strong>
            </a>
            {yearParam && (
              <a className="home-stat" href={listLink({ year: yearParam, new: "1" })} title="그 해에 새로 착수한 과제(과제 번호의 연도)">
                <span className="home-stat-label">신규 착수</span>
                <strong>{team.new ?? 0}건</strong>
              </a>
            )}
            <a className="home-stat" href={listLink({ status: "in_progress", year: yearParam })}>
              <span className="home-stat-label">진행중</span>
              <strong>{team.in_progress}건</strong>
            </a>
            {/* 완료 = **그 해에 끝낸 과제** 하나 (TODO 181). 반기 · 분기를 고르면 그 기간에 끝낸 것만(완료일). */}
            {data.period ? (
              <a className="home-stat" href={listLink({ done_year: yearParam, year: "all" })} title="이 기간에 완료일이 든 과제">
                <span className="home-stat-label">완료</span>
                <strong>{team.done_in_year ?? 0}건</strong>
              </a>
            ) : (
              <a
                className="home-stat"
                href={listLink({ status: "done", year: yearParam })}
                title={yearParam ? "그 해에 끝낸 과제 — 시작한 해와 무관하게" : undefined}
              >
                <span className="home-stat-label">완료</span>
                <strong>{team.done}건</strong>
              </a>
            )}
            <a
              className="home-stat"
              href={
                yearParam
                  ? screenLink("history", { from: `${yearParam}-01-01`, to: `${yearParam}-12-31` })
                  : screenLink("history")
              }
            >
              <span className="home-stat-label">보고 횟수</span>
              <strong>{team.reports}회</strong>
            </a>
            {/* 화살표만 놓으면 "42.9 중 10.5 달성 = 24%" 로 읽힌다. 실증은 끝난 과제에서만
                나오므로 그 비율은 성립하지 않는다. **몇 건에서 나온 값인지**를 함께 적어
                분모를 드러낸다 (TODO 86). */}
            <div className="home-stat effect">
              <span className="home-stat-label" title={yearParam ? "기대 · 실증 모두 과제가 끝나는 해(완료년도, 아니면 마감년도)에 셉니다" : undefined}>
                효과 금액 (억원/년){yearParam ? " · 끝나는 해 기준" : ""}
              </span>
              <strong>
                기대 {money(team.effect_expected)}
                <span className="home-arrow"> → </span>
                실증 {money(team.effect_verified)}
              </strong>
              {/* 분모도 **눌린다** (TODO 124). 홈의 다른 모든 수가 그렇듯, 여기만 글자였다. */}
              <span className="home-stat-note">
                <a href={listLink({ effect: "expected", year: yearParam })}>
                  기대 {team.effect_expected_projects ?? 0}건
                </a>{" "}
                ·{" "}
                <a href={listLink({ effect: "verified", year: yearParam })}>
                  실증 {team.effect_verified_projects ?? 0}건
                </a>
                에 입력됨{" "}
                {/* 실증 합계에 진행중 과제의 중간 결산이 섞여 있으면 얼마인지 밝힌다 (TODO 217) */}
                {(team.effect_verified_interim_projects ?? 0) > 0 && (
                  <span className="interim-note" title="분기 · 반기 결산으로 진행중 과제에 적은 실증효과 — 과제가 끝나면 최종 값으로 바뀝니다">
                    (실증 중 진행중 과제의 중간 결산 {money(team.effect_verified_interim ?? 0)} · {team.effect_verified_interim_projects}건){" "}
                  </span>
                )}
                {/* 비대상이 있으면 분모를 "전체" 라고 적을 수 없다 (TODO 125) */}
                {(team.effect_managed ?? team.total) < team.total ? (
                  <>
                    (관리 대상 {team.effect_managed}건 ·{" "}
                    <a href={listLink({ no_effect: "none", year: yearParam })}>
                      비대상 {team.total - (team.effect_managed ?? 0)}건
                    </a>
                    {" "}제외)
                  </>
                ) : (
                  <>(전체 {team.total}건)</>
                )}
              </span>
              {/* 기대효과를 비용구분으로 나눠 본다 (TODO 136) — 적힌 과제만 센다 */}
              {data.effect_by_cost.length > 0 && (
                <span className="home-stat-note cost-split">
                  {data.effect_by_cost.map((item, index) => (
                    <span key={item.key}>
                      {index > 0 && " · "}
                      <a href={listLink({ cost_kind: item.key, year: yearParam })}>
                        {item.key} {money(item.effect_expected)}
                      </a>
                    </span>
                  ))}
                </span>
              )}
              {/* 완료했는데 실증효과가 빈 과제 (TODO 106-C). 연말에 빈칸을 만나기 전에 여기서 본다. */}
              {(team.done_unverified ?? 0) > 0 && (
                <a
                  className="home-stat-note warn-text"
                  href={listLink({ verified: "none", year: yearParam || "all" })}
                >
                  완료했는데 실증효과 미입력 {team.done_unverified}건 →
                </a>
              )}
            </div>
          </div>
          {/* 잘못 읽으면 숫자가 틀리게 보고되는 한 문장은 늘 보이게, 세는 규칙은 접는다 (TODO 232 ④) */}
          <Explain id="home-team" lead={<b>실증효과는 끝난 과제에서만 나오므로 기대 대비 달성률이 아닙니다.</b>}>
            과제 수는 <b>그 해에 수행한 과제</b>(여러 해에 걸친 과제는 해마다), 완료는 <b>그 해에 끝낸 과제</b>, 신규는{" "}
            <b>그 해에 착수한 과제</b>, 효과 금액은 <b>끝나는 해</b>(기대 · 실증을 같은 해에), 보고 횟수는 <b>보고한 날의 연도</b>로 셉니다.
            {" "}보고 횟수는 <b>확정된 보고</b>만 셉니다 — 초안은 아직 보고한 것이 아닙니다.
          </Explain>
        </div>
        {/* ── 연도 비교 — 한 해만 보면 늘고 있는지 줄고 있는지 알 수 없다 ── */}
        {data.compare.length > 1 && (
          <div className="card home-compare">
            <CardTitle
              actions={
                <CopyTableButton
                  headers={["연도", "과제", "완료", "보고 횟수", "기대효과(억원/년)", "실증효과(억원/년)"]}
                  rows={() =>
                    data.compare.map((item) => [
                      item.year,
                      item.total,
                      item.done,
                      item.reports,
                      item.effect_expected,
                      item.effect_verified,
                    ])
                  }
                />
              }
            >
              연도별 추이
            </CardTitle>
            {/* 과제가 있는 모든 해 (TODO 228) — 지난해 회색 · 올해 파랑 · 내년 이후 초록. 넘치면 가로로 넘기고, 올해가 보이게 둔다 */}
            <div className="bar-row trend" ref={trendRef}>
              {data.compare.map((item) => (
                <a
                  key={item.year}
                  className={["bar-col", `when-${item.when ?? "past"}`, item.year === year ? "on" : ""].filter(Boolean).join(" ")}
                  href={listLink({ year: item.year })}
                  title={`${item.year}년 과제 ${item.total}건 · 완료 ${item.done}건 · 보고 ${item.reports}회`}
                >
                  <span className="bar-value">{item.total}</span>
                  <span className="bar" style={{ height: `${(item.total / maxCompare) * 100}%` }}>
                    <span
                      className="bar-done"
                      style={{ height: `${item.total ? (item.done / item.total) * 100 : 0}%` }}
                    />
                  </span>
                  <span className="bar-label">{item.year}</span>
                </a>
              ))}
            </div>
            <Explain
              id="home-trend"
              lead={
                <>
                  막대는 과제 수, 진한 부분이 <b>완료</b>입니다. <span className="trend-key past">지난해</span> <span className="trend-key current">올해</span>{" "}
                  <span className="trend-key future">내년 이후</span>
                </>
              }
            >
              — 내년 이후는 <b>그 해에 수행기간이 걸친 과제</b>(이어지는 다년도 과제 · 그 해에 시작할 과제)입니다.
              누르면 그 해 과제 목록으로 갑니다.
            </Explain>
          </div>
        )}
      </div>

      {/* ── 팀원별 성과 (ROADMAP R1 의 실체) ───────────────────────── */}
      <div className="card home-members wide">
        <CardTitle
          actions={
            data.members.length > 0 && (
              <CopyTableButton
                headers={["담당자", "담당 과제", ...meta.statuses.map((item) => item.label), "기대효과(억원/년)", "실증효과(억원/년)", "보고 횟수", "역량 이력", "마지막 보고"]}
                rows={() =>
                  data.members.map((member) => [
                    member.name,
                    member.total,
                    ...statusCells(meta, member.by_status),
                    member.effect_expected,
                    member.effect_verified,
                    member.reports,
                    member.activities,
                    member.last_reported_at ?? "",
                  ])
                }
              />
            )
          }
        >
          팀원별 성과
        </CardTitle>
        {data.members.length === 0 ? (
          <p className="hint">담당자가 지정된 과제가 없습니다.</p>
        ) : (
          <>
            <div className="table-scroll">
              <table className="grid home-member-table">
                <thead>
                  <tr>
                    <th>담당자</th>
                    <th>담당 과제</th>
                    <StatusHead statuses={memberStatuses} />
                    {memberCols.expected && (
                      <th>
                        기대효과
                        <span className="th-unit">억원/년</span>
                      </th>
                    )}
                    {memberCols.verified && (
                      <th>
                        실증효과
                        <span className="th-unit">억원/년</span>
                      </th>
                    )}
                    {memberCols.reports && <th>보고 횟수</th>}
                    {/* 과제가 아니라 사람에게 쌓인 것. 면담 준비를 한 화면에서 끝내기 위해 여기 세운다 (TODO 89). */}
                    {memberCols.activities && <th>역량 이력</th>}
                    {memberCols.last && <th>마지막 보고</th>}
                  </tr>
                </thead>
                <tbody>
                  {(allMembers ? data.members : data.members.slice(0, MEMBER_LIMIT)).map((member) => (
                    <tr key={member.name}>
                      <td>
                        <a href={listLink({ owner: member.name, year: yearParam })}>{member.name}</a>
                        {isLeader(meta, member.name) && <span className="tag leader-tag">팀장</span>}
                      </td>
                      <td>{member.total || DASH}</td>
                      <StatusCells
                        statuses={memberStatuses}
                        counts={member.by_status}
                        link={(statusKey) => listLink({ owner: member.name, status: statusKey, year: yearParam })}
                      />
                      {memberCols.expected && <td>{cellEffect(member.effect_expected)}</td>}
                      {memberCols.verified && <td>{cellEffect(member.effect_verified)}</td>}
                      {memberCols.reports && <td>{member.reports || DASH}</td>}
                      {memberCols.activities && (
                        <td className={member.activities ? undefined : "zero"}>
                          {member.activities ? (
                            <a href={screenLink("skills", { person: member.name, year: yearParam, tab: "records" })}>
                              {member.activities}
                            </a>
                          ) : (
                            DASH
                          )}
                        </td>
                      )}
                      {memberCols.last && <td className="muted">{member.last_reported_at ?? DASH}</td>}
                    </tr>
                  ))}
                </tbody>
                {/* 사람별로 더하므로 **담당 중복이 들어 있다** — 이름표에 밝힌다. 팀 합계는 위의 팀 현황이다 (TODO 157) */}
                <TotalRow
                  label={
                    <span title="한 과제에 담당자가 여럿이면 양쪽에 잡힙니다. 팀 합계는 위의 팀 현황을 쓰십시오.">
                      합계 <span className="total-note">중복 포함</span>
                    </span>
                  }
                  cells={[
                    String(memberSum || DASH),
                    ...statusTotals(memberStatuses, data.members),
                    ...(memberCols.expected ? [cellEffect(sumBy(data.members, (member) => member.effect_expected))] : []),
                    ...(memberCols.verified ? [cellEffect(sumBy(data.members, (member) => member.effect_verified))] : []),
                    ...(memberCols.reports ? [String(sumBy(data.members, (member) => member.reports) || DASH)] : []),
                    ...(memberCols.activities ? [String(sumBy(data.members, (member) => member.activities) || DASH)] : []),
                    ...(memberCols.last ? [null] : []),
                  ]}
                />
              </table>
            </div>
            {data.members.length > MEMBER_LIMIT && (
              <button type="button" className="ghost small" onClick={() => setAllMembers((on) => !on)}>
                {allMembers ? "접기" : `나머지 ${data.members.length - MEMBER_LIMIT}명 더 보기`}
              </button>
            )}
            <HiddenColumns names={memberHidden} />
            {/* 이 문구는 수가 어긋날 때만 띄우면 안 된다. 담당자 없는 과제가 중복분을
                상쇄해 **우연히 합이 맞는 순간**이 가장 위험하기 때문이다 — 그래서 늘 밝힌다(첫 문장은 접히지 않는다). */}
            <Explain
              id="home-members"
              lead={
                <>
                  <b>담당 중복 포함</b> — 한 과제에 담당자가 여럿이면 양쪽에 잡힙니다.
                  {memberSum !== team.total && (
                    <>
                      {" "}그래서 이 표의 합({memberSum}건)은 팀 과제 수({team.total}건)와 다릅니다.
                    </>
                  )}
                </>
              }
            >
              <b>효과 금액도 마찬가지로 중복 합산</b>되므로, 팀 합계는 위의 &ldquo;팀 현황&rdquo;에 있는
              과제 기준 숫자를 쓰십시오. <b>역량 이력</b>은 과제와 무관한 그 해 교육·세미나
              참여 건수입니다 — 눌러서 그 사람의 이력을 봅니다.
            </Explain>
          </>
        )}
      </div>

      {/* ── 속성별 · 그룹별 ─────────────────────────────────────────
          속성은 과제의 *성격*(R&D·투자…), 그룹은 실제로 *지시사항 · 지시자 · 회의체*를 적는 칸이다(TODO 230).
          표 모양은 하나로 맞춘다 — 같은 화면에서 같은 것을 다르게 세지 않기 위해서다. 줄이 짧아 나란히 놓는다 (TODO 123) */}
      <div className="home-slices">
        <SliceTable
          meta={meta}
          title="속성별"
          column="속성"
          rows={data.types}
          param="type"
          yearParam={yearParam}
          note={<>과제마다 속성은 하나뿐이라 이 표의 합은 <b>팀 과제 수와 정확히 맞습니다.</b></>}
          more={<>(담당 중복이 있는 위쪽 팀원별 표와 다른 점입니다)</>}
        />
        <SliceTable
          meta={meta}
          title="그룹별"
          column="그룹"
          rows={data.groups}
          param="group"
          yearParam={yearParam}
          note={
            <>
              {/* 그룹은 실제로 지시사항 · 지시자를 적는 칸이다 (TODO 230) — 과제 폼의 예시와 같은 말 */}
              <span className="slice-example">예: 대표이사 지시 · 본부장 지시 · 주간 회의체</span>
              과제마다 그룹은 하나뿐이므로 이 표의 합도 <b>팀 과제 수와 맞습니다.</b>
            </>
          }
          more={<>그룹은 <b>자유 입력</b>이라 표기가 흔들리면 줄이 갈라집니다(같은 지시자를 다르게 적으면 두 줄).</>}
        />
      </div>

      {/* ── 성격별 · 분류별 (TODO 136) — 스마트과제 안의 두 축. 따로 묶어 밝힌다 (TODO 229) ── */}
      {(data.natures.length > 0 || data.categories.length > 0) && (
        <div className="home-smart">
          <h2>
            스마트과제 · 성격 · 분류
            <span className="hint"> · 스마트과제 {smartCount}건 기준</span>
          </h2>
          <p className="hint">
            성격과 분류는 <b>스마트과제만</b> 가지는 칸이라, 이 두 표의 합은 위의 <b>팀 과제 수와 다릅니다.</b>
            {outsideNote}
          </p>
          <div className="home-slices">
            <SliceTable
              meta={meta}
              title="성격별"
              column="성격"
              rows={data.natures}
              param="nature"
              yearParam={yearParam}
              note={<>미지정은 스마트과제인데 비어 있는 것입니다.</>}
              more={<>연구과제/PoC → 현장적용 → 확대전개로 이어지는 흐름을 봅니다.</>}
            />
            <SliceTable
              meta={meta}
              title="분류별"
              column="분류"
              rows={data.categories}
              param="category"
              yearParam={yearParam}
              note={<>기술 영역별로 어디에 과제가 몰려 있는지 봅니다. 목록은 설정에서 고칩니다.</>}
            />
          </div>
        </div>
      )}
    </>
  );

  return (
    <section className={reloading ? "home busy" : "home"} aria-busy={reloading || undefined}>
      {/* 읽지 못한 파일 · 값 — 백업 경고처럼 문제가 있을 때만 선다 (TODO 164) */}
      <ProblemsBanner
        problems={meta.problems ?? []}
        onReindexed={() => {
          load();
          onMetaChange?.();
        }}
      />
      {backupWarning(backup) && (
        <div className="home-backup-warn">
          <b>자동 백업</b> {backupWarning(backup)}
          <a href={screenLink("settings")}>설정에서 보기 →</a>
        </div>
      )}
      <div className="home-head">
        {/* 제목은 **탭 이름 그대로**, 무엇을 보는 화면인지는 설명 줄에 (TODO 153) */}
        <div>
          <h1>홈</h1>
          <p className="hint page-desc">과제 수행 현황 — 그 해 우리 팀이 무엇을 했는지 봅니다. 숫자를 누르면 그 조건의 목록으로 갑니다.</p>
        </div>
        <label className="home-year">
          기준 연도
          <select value={year} onChange={(event) => setYear(event.target.value)}>
            {!data.years.includes(thisYear) && <option value={thisYear}>{thisYear}년</option>}
            {data.years.map((item) => (
              <option key={item} value={item}>
                {item}년
              </option>
            ))}
            <option value={ALL_YEARS}>전체</option>
          </select>
        </label>
        {/* 반기 · 분기는 [팀 현황] 의 숫자만 따른다 — [할 일] 에서는 뜻이 없어 세우지 않는다 */}
        {year !== ALL_YEARS && tab === "status" && (
          <label className="home-period">
            기간
            <select value={period} onChange={(event) => setPeriod(event.target.value)} title="보고 횟수·완료·역량 이력처럼 날짜가 있는 숫자만 이 기간을 따릅니다. 과제 수는 연도 기준 그대로입니다.">
              {PERIODS.map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </label>
        )}
        {reloading && <span className="hint home-reloading" role="status">불러오는 중…</span>}
      </div>

      {/* 화면 안 탭 (TODO 232 ①) — 매일 보는 것과 보고 때 보는 것을 가른다 */}
      <ViewTabs
        label="홈 보기"
        className="home-tabs"
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "", label: "할 일", title: "이번 주 할 일 · 다가오는 팀원 일정 · 오래 보고되지 않은 과제" },
          { key: "status", label: "팀 현황", title: "팀 현황 · 연도별 추이 · 팀원별 · 속성별 · 그룹별 · 스마트과제 표" },
        ]}
      />
      {tab === "status" && data.period && (
        <p className="hint home-period-note">
          <b>{PERIODS.find(([key]) => key === data.period)?.[1]}</b> — 보고 횟수·완료·역량 이력처럼{" "}
          <b>날짜가 있는 숫자만</b> 이 기간을 따릅니다. 과제 수·상태별 수는 연도 기준 그대로입니다.
        </p>
      )}
      <div role="tabpanel" className={tab === "status" ? "home-panel home-panel-status" : "home-panel home-panel-todo"}>
        {tab === "status" ? status : todo}
      </div>
    </section>
  );
}
