import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../api";
import { attempt } from "../notify";
import { dropDraft, loadDraft, useDraftKeeper, useUnsaved } from "../unsaved";
import { filesBase, renderMarkdown } from "../markdown";
import VersionPanel from "./VersionPanel";
import type { Entry } from "../types";
import type { Attachment } from "../upload";
import { formatBytes, formatRate, uploadAttachment } from "../upload";
import PasteOfferBar from "./PasteOffer";
import { type PasteOffer, handleEditorPaste } from "../table";
import { scrollEditorIntoView, todayIso } from "../util";
import AttachmentList from "./AttachmentList";
import PreviewToggle, { usePreview } from "./PreviewToggle";
import TagSuggestions from "./TagSuggestions";

const AUTOSAVE_DELAY_MS = 10_000;
const AUTOSAVE_PREF_KEY = "md-mgmt:autosave";

interface UploadState {
  key: string;
  name: string;
  loaded: number;
  total: number;
  startedAt: number;
  abort: () => void;
  error?: string;
}

interface Props {
  projectId: string;
  /** 이미 쓰고 있는 태그 — 눌러서 덧붙일 수 있게 보여 준다 */
  knownTags?: string[];
  dirName?: string;
  initial?: Partial<Entry>;
  onSaved: (entry: Entry, options: { close: boolean }) => void;
  onCancel: () => void;
  /** 이 문서의 vault 기준 경로. 있으면 [이전 버전]을 열 수 있다 (TODO 37-1). */
  docPath?: string;
  /** 되돌린 뒤 화면을 다시 읽는다. */
  onRestored?: () => void;
}

/** 임시 보관 열쇠 (TODO 170) — 새 기록은 과제로, 고치는 기록은 그 번호로. 데이터 폴더의 `.drafts/` 에 남는다. */
function draftKey(projectId: string, entryId: number | null): string {
  return `entry:${entryId ?? `new-${projectId}`}`;
}

interface EntryDraft {
  date: string;
  title: string;
  body: string;
  tags: string;
}

export default function EntryEditor({ projectId, knownTags = [], dirName, initial, onSaved, onCancel, docPath, onRestored }: Props) {
  const [showVersions, setShowVersions] = useState(false);
  const [entryId, setEntryId] = useState<number | null>(initial?.id ?? null);
  const [date, setDate] = useState(initial?.date ?? todayIso());
  const [title, setTitle] = useState(initial?.title ?? "");
  const [body, setBody] = useState(initial?.body ?? "");
  const [tags, setTags] = useState((initial?.tags ?? []).join(", "));
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploads, setUploads] = useState<UploadState[]>([]);
  const [autosave, setAutosave] = useState(
    () => localStorage.getItem(AUTOSAVE_PREF_KEY) === "on",
  );
  const [dirty, setDirty] = useState(false);
  // 떠날 때 묻는다 (TODO 162) — 임시 보관은 이 편집기가 처음부터 해 왔다
  useUnsaved(`entry:${initial?.id ?? `new-${projectId}`}`, dirty);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [restored, setRestored] = useState(false);
  const [preview, togglePreview] = usePreview();

  const rootRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  // 엑셀 표를 넣은 직후의 [그림으로 바꾸기] (TODO 149)
  const [pasteOffer, setPasteOffer] = useState<PasteOffer | null>(null);
  const closeOffer = useCallback(() => setPasteOffer(null), []);

  // 열리자마자 그 자리로 데려간다 (1단으로 바뀌며 위치가 달라지기 때문).
  useEffect(() => scrollEditorIntoView(rootRef.current), []);

  const fileInputRef = useRef<HTMLInputElement>(null);
  // 자동 저장 타이머가 항상 최신 값을 보게 한다.
  const stateRef = useRef({ entryId, date, title, body, tags });
  stateRef.current = { entryId, date, title, body, tags };

  // 진행일지는 logs/ 안에 있으므로 첨부 링크(../assets/…)의 기준도 logs/ 다.
  const base = filesBase(dirName, "logs");

  const refreshAttachments = useCallback((id: number) => {
    api.listEntryAttachments(id).then(setAttachments).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (entryId) refreshAttachments(entryId);
  }, [entryId, refreshAttachments]);

  // 저장 전에 창을 닫아도 작성 중이던 내용을 잃지 않도록 **데이터 폴더에** 초안을 남긴다 (TODO 170).
  // 전에는 브라우저 안에 남겨, 창 하나만 닫고 다른 창에서 열면 "작성 중이던 기록 있음" 이 안 뜨기도 했다(v7 B-6).
  useEffect(() => {
    let alive = true;
    const original = { body: initial?.body ?? "", title: initial?.title ?? "" };
    void loadDraft<EntryDraft>(
      draftKey(projectId, initial?.id ?? null),
      (draft) => draft?.body === original.body && draft?.title === original.title,
    ).then((draft) => {
      if (!alive || !draft || typeof draft !== "object") return;
      setDate(draft.date ?? todayIso());
      setTitle(draft.title ?? "");
      setBody(draft.body ?? "");
      setTags(draft.tags ?? "");
      setRestored(true);
      setDirty(true);
    });
    return () => {
      alive = false;
    };
    // 최초 1회만 복구한다.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 자동 저장으로 새 기록이 생긴 뒤에는 그 번호로 남긴다 — 다시 열 때 새 기록으로 한 번 더 생기지 않게
  useDraftKeeper(draftKey(projectId, entryId), { date, title, body, tags }, !dirty);

  const save = useCallback(
    async (options: { close: boolean }): Promise<Entry> => {
      const current = stateRef.current;
      const payload = {
        date: current.date,
        title: current.title.trim() || "진행 기록",
        body: current.body,
        tags: current.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean),
      };
      const entry = current.entryId
        ? await api.updateEntry(current.entryId, payload)
        : await api.createEntry(projectId, payload);
      setEntryId(entry.id);
      setDirty(false);
      setRestored(false);
      setSavedAt(new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" }));
      dropDraft(draftKey(projectId, initial?.id ?? null));
      dropDraft(draftKey(projectId, entry.id));
      onSaved(entry, options);
      return entry;
    },
    [projectId, initial?.id, onSaved],
  );

  // 자동 저장: 입력이 멈추고 10초 뒤에 저장한다.
  useEffect(() => {
    if (!autosave || !dirty) return;
    const timer = window.setTimeout(() => {
      save({ close: false }).catch((err: Error) => setError(err.message));
    }, AUTOSAVE_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [autosave, dirty, date, title, body, tags, save]);

  function markDirty() {
    setDirty(true);
    setError(null);
  }

  /** 첨부 링크가 앞뒤 문장과 붙지 않도록 줄바꿈을 보충해 삽입한다. */
  function insertAtCursor(snippet: string) {
    const textarea = textareaRef.current;
    const start = textarea ? textarea.selectionStart : body.length;
    const end = textarea ? textarea.selectionEnd : body.length;

    let inserted = snippet;
    setBody((prev) => {
      const before = prev.slice(0, start);
      const after = prev.slice(end);
      const lead = before.length > 0 && !before.endsWith("\n") ? "\n\n" : "";
      const trail = after.startsWith("\n") || after.length === 0 ? "\n" : "\n\n";
      inserted = `${lead}${snippet}${trail}`;
      return `${before}${inserted}${after}`;
    });

    if (textarea) {
      window.requestAnimationFrame(() => {
        textarea.focus();
        const caret = start + inserted.length;
        textarea.setSelectionRange(caret, caret);
      });
    }
    markDirty();
  }

  /** 첨부는 진행일지에 붙으므로, 아직 저장 전이면 먼저 기록을 만든다. */
  async function ensureEntryId(): Promise<number> {
    if (stateRef.current.entryId) return stateRef.current.entryId;
    const entry = await save({ close: false });
    return entry.id;
  }

  async function handleFiles(files: File[]) {
    if (files.length === 0) return;
    let targetId: number;
    try {
      targetId = await ensureEntryId();
    } catch (err) {
      setError((err as Error).message);
      return;
    }

    // 자리표시자는 한 번에 넣는다. 파일마다 커서 위치를 다시 읽으면, 앞 파일이
    // 업로드되는 동안 본문이 길어져 두 번째 첨부가 첫 번째 링크 한가운데 끼어든다.
    const placeholders = files.map((file, index) =>
      files.length > 1 ? `⏳ 업로드 중: ${file.name} (${index + 1})` : `⏳ 업로드 중: ${file.name}`,
    );
    insertAtCursor(placeholders.join("\n"));

    for (const [index, file] of files.entries()) {
      const key = `${file.name}-${Date.now()}-${index}`;
      const placeholder = placeholders[index];

      const handle = uploadAttachment(`/api/entries/${targetId}/attachments`, file, (loaded, total) => {
        setUploads((prev) =>
          prev.map((item) => (item.key === key ? { ...item, loaded, total } : item)),
        );
      });
      setUploads((prev) => [
        ...prev,
        {
          key,
          name: file.name,
          loaded: 0,
          total: file.size,
          startedAt: Date.now(),
          abort: handle.abort,
        },
      ]);

      try {
        const saved = await handle.promise;
        setBody((prev) => prev.replace(placeholder, saved.markdown));
        setUploads((prev) => prev.filter((item) => item.key !== key));
        refreshAttachments(targetId);
        markDirty();
      } catch (err) {
        setBody((prev) => prev.replace(`${placeholder}\n`, "").replace(placeholder, ""));
        setUploads((prev) =>
          prev.map((item) =>
            item.key === key ? { ...item, error: (err as Error).message } : item,
          ),
        );
      }
    }
  }

  return (
    <div
      ref={rootRef}
      className="entry-editor card"
      onKeyDown={(event) => {
        // 문서 편집기 습관대로 Ctrl+S 로 저장한다 (브라우저 저장 창은 막는다).
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
          event.preventDefault();
          void save({ close: false }).catch((err: Error) => setError(err.message));
        }
      }}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        void handleFiles(Array.from(event.dataTransfer.files));
      }}
    >
      <div className="form-row">
        <label>
          날짜
          <input
            type="date"
            value={date}
            onChange={(event) => {
              setDate(event.target.value);
              markDirty();
            }}
          />
        </label>
        <label className="grow">
          제목
          <input
            value={title}
            onChange={(event) => {
              setTitle(event.target.value);
              markDirty();
            }}
            placeholder="예: 1차 측정 결과"
          />
        </label>
        <label>
          태그
          <input
            value={tags}
            onChange={(event) => {
              setTags(event.target.value);
              markDirty();
            }}
            placeholder="측정, 분석"
          />
          <TagSuggestions
            known={knownTags}
            value={tags}
            onPick={(next) => {
              setTags(next);
              markDirty();
            }}
          />
        </label>
      </div>

      <PreviewToggle on={preview} onToggle={togglePreview} />

      <div className={preview ? "split" : "split solo"}>
        <textarea
          ref={textareaRef}
          value={body}
          onChange={(event) => {
            setBody(event.target.value);
            markDirty();
          }}
          onPaste={(event) =>
            // 엑셀 표는 표로, 캡처는 첨부로 — 판단은 한 곳(table.ts)에서 (TODO 137)
            handleEditorPaste(event, {
              onInsert: (text) => {
                insertAtCursor(text);
                markDirty();
              },
              onFiles: (files) => void handleFiles(files),
              onOffer: setPasteOffer,
            })
          }
          placeholder="진행 내용을 마크다운으로 작성합니다. 이미지는 Ctrl+V로 바로 붙여넣을 수 있습니다."
          spellCheck={false}
        />
        {preview && (
          <div
            className="preview markdown"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(body, base) }}
          />
        )}
      </div>

      <PasteOfferBar
        offer={pasteOffer}
        area={textareaRef.current}
        setValue={(next) => {
          setBody(next);
          markDirty();
        }}
        onFiles={(files) => void handleFiles(files)}
        onClose={closeOffer}
      />

      {uploads.length > 0 && (
        <ul className="uploads">
          {uploads.map((upload) => {
            const percent = upload.total ? Math.round((upload.loaded / upload.total) * 100) : 0;
            const elapsed = (Date.now() - upload.startedAt) / 1000;
            const rate = elapsed > 0 ? upload.loaded / elapsed : 0;
            return (
              <li key={upload.key} className={upload.error ? "upload-error" : undefined}>
                <div className="upload-head">
                  <span className="upload-name">{upload.name}</span>
                  <span className="muted">
                    {upload.error
                      ? upload.error
                      : `${formatBytes(upload.loaded)} / ${formatBytes(upload.total)} · ${formatRate(rate)}`}
                  </span>
                  {upload.error ? (
                    <button
                      className="ghost small"
                      onClick={() => setUploads((prev) => prev.filter((item) => item.key !== upload.key))}
                    >
                      닫기
                    </button>
                  ) : (
                    <button className="ghost small" onClick={upload.abort}>
                      취소
                    </button>
                  )}
                </div>
                <div className="progress">
                  <div className="progress-bar" style={{ width: `${percent}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <div className="attachment-panel">
        <div className="card-head">
          <h3>첨부 ({attachments.length})</h3>
          <div className="attach-actions">
            <span className="hint">이미지는 Ctrl+V, 파일은 끌어다 놓아도 됩니다.</span>
            <button className="attach-button" onClick={() => fileInputRef.current?.click()}>
              📎 파일 첨부
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              hidden
              onChange={(event) => {
                void handleFiles(Array.from(event.target.files ?? []));
                event.target.value = "";  // 같은 파일을 다시 골라도 반응하도록 비운다
              }}
            />
          </div>
        </div>
        <AttachmentList
          attachments={attachments}
          onInsert={(attachment) => insertAtCursor(`\n${attachment.markdown}\n`)}
          onDelete={async (attachment) => {
            if (!window.confirm(`${attachment.orig_name} 을(를) 삭제 보관함으로 옮길까요?`)) return;
            if (!(await attempt(() => api.deleteAttachment(attachment.id)))) return;
            if (entryId) refreshAttachments(entryId);
          }}
        />
      </div>

      {restored && <p className="hint restored">저장하지 않은 작성 중 내용을 복구했습니다.</p>}
      {error && (
        <p className="form-error">
          {error}
          {error.includes("다시 읽기") && (
            <button
              className="ghost small"
              onClick={async () => {
                if (await attempt(() => api.reindex())) window.location.reload();
              }}
            >
              지금 다시 읽기
            </button>
          )}
        </p>
      )}

      <div className="editor-footer">
        <label className="toggle">
          <input
            type="checkbox"
            checked={autosave}
            onChange={(event) => {
              setAutosave(event.target.checked);
              localStorage.setItem(AUTOSAVE_PREF_KEY, event.target.checked ? "on" : "off");
            }}
          />
          자동 저장 (입력이 멈추면 10초 뒤)
        </label>
        <span className="muted save-state">
          {dirty ? "저장 안 됨" : savedAt ? `${savedAt} 저장됨` : ""}
        </span>
        <div className="form-actions">
          {docPath && (
            <button
              type="button"
              className={showVersions ? "ghost on" : "ghost"}
              onClick={() => setShowVersions((prev) => !prev)}
              title="이 진행일지의 이전 내용으로 되돌립니다."
            >
              이전 버전
            </button>
          )}
          <button
            type="button"
            className="ghost"
            onClick={() => {
              // 쓴 것이 있으면 버릴지 묻는다 — 다른 편집기와 같게 (TODO 170)
              if (dirty && !window.confirm("저장하지 않은 기록을 버릴까요?")) return;
              dropDraft(draftKey(projectId, entryId));
              onCancel();
            }}
          >
            닫기
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await save({ close: true });
              } catch (err) {
                setError((err as Error).message);
              } finally {
                setBusy(false);
              }
            }}
          >
            {busy ? "저장 중…" : "저장"}
          </button>
        </div>
      </div>

      {docPath && showVersions && (
        <VersionPanel path={docPath} onRestored={() => onRestored?.()} />
      )}
    </div>
  );
}
