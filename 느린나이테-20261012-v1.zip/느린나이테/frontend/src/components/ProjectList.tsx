import { Fragment, useCallback, useEffect, useState } from "react";
import { api } from "../api";
import { notifyError } from "../notify";
import type { Meta, Project } from "../types";
import { cellCount, cellEffect, DASH, dueLabel, EFFECT_UNIT, sumBy } from "../util";
import TotalRow from "./TotalRow";
import ProblemsBanner from "./ProblemsBanner";
import { backTarget, projectLink, useAddressBar } from "../nav";
import SortHeader, { type SortState } from "./SortHeader";
import LoadError from "./LoadError";
import Dashboard from "./Dashboard";
import ProjectBoard from "./ProjectBoard";
import ProjectForm from "./ProjectForm";
import CopyTableButton from "./CopyTableButton";
import { leftLabel } from "../people";
import { TypeBadge, YearStatusBadge, shownStatus } from "./StatusBadge";
import StageBand from "./StageBand";

interface Props {
  meta: Meta;
  onMetaChange: () => void;
  /** 주소에 실려 온 거른 조건. 과제를 보고 돌아왔을 때 그대로 살아난다. */
  query: string;
}

/** 해가 바뀌면 지난해 과제가 계속 섞인다. 첫 화면은 **올해**만 보여 준다 (TODO 67). */
const THIS_YEAR = String(new Date().getFullYear());

const DEFAULT_FILTERS = {
  status: "", type: "", group: "", tag: "", owner: "", partner: "", due: "",
  year: THIS_YEAR, sort: "updated", order: "",
  // 홈에서만 거는 조건 — 상자는 없고 주소로만 온다. 완료일의 연도(TODO 104)와
  // "완료했는데 실증효과를 안 적은 것"(TODO 106-C).
  done_year: "", verified: "",
  // 그 해에 새로 착수한 과제만 — 번호의 연도 (TODO 181). 홈의 "신규 착수" 가 이리로 온다.
  new: "",
  // 떠난 담당자가 남아 있는 끝나지 않은 과제 (TODO 122). 홈이 이리로 데려온다.
  owner_left: "",
  // 효과 금액이 적힌 과제 (TODO 124) · 효과성 관리 비대상 (TODO 125)
  effect: "", no_effect: "",
  // 과제 분류 넷 (TODO 136) · 접수에서 승격된 과제만/직접 만든 과제만
  nature: "", category: "", delivery: "", cost_kind: "", from_intake: "",
  // 어디서 왔는지 (TODO 127). 거르는 조건이 아니라 **돌아갈 곳**이다 — 서버로 보내지 않고,
  // 조건을 바꿔도 주소에 남아 있어야 한다(그래야 거르다가도 홈으로 돌아간다).
  back: "",
};

/**
 * 고를 수 있는 연도 (TODO 96).
 *
 * 예전에는 *올해부터 5년 전까지* 를 그냥 세웠다. 그래서 **과제가 한 건도 없는 해**가
 * 목록에 서고, 골라 보면 0건이었다 — 홈과 팀원 역량은 이미 "과제가 있는 해" 만 세우고
 * 있었으니 화면마다 말이 달랐다.
 *
 * 세우는 것은 셋을 합친 것이다.
 * - 과제가 실제로 있는 해 (`meta.years` — 과제의 수행기간이 걸친 해 전부, TODO 181)
 * - **올해** — 아직 올해 과제가 없어도 "올해만 보기" 는 뜻이 통해야 하고, 그것이 기본값이다
 * - 지금 주소가 가리키는 해 — 즐겨찾기해 둔 `?year=2019` 가 빈칸으로 보이면 안 된다
 */
function yearOptions(available: string[] | undefined, selected: string): string[] {
  const years = new Set([...(available ?? []), THIS_YEAR]);
  if (selected && selected !== ALL_YEARS) years.add(selected);
  return [...years].sort((a, b) => Number(b) - Number(a));
}

/**
 * [전체]를 나타내는 값.
 *
 * 빈 문자열로 두면 주소에서 사라져 **기본값(올해)과 구분되지 않는다.**
 * 그러면 "전체"로 놓고 즐겨찾기해도 다시 열 때 올해로 돌아온다.
 * 주소가 뜻하는 바가 흔들리지 않게 [전체]에는 이름을 준다.
 */
const ALL_YEARS = "all";

/** 서버에는 연도만 넘긴다 — [전체]는 조건이 없는 것이다. */
function toQuery(filters: typeof DEFAULT_FILTERS): Record<string, string> {
  // back 은 화면의 것이지 조건이 아니다 — 서버에 보내지 않는다 (TODO 127).
  const { back: _back, ...rest } = filters;
  return { ...rest, year: filters.year === ALL_YEARS ? "" : filters.year };
}

/** 열 머리글 → 서버가 아는 정렬 이름. 여기 없는 열은 눌러도 아무 일이 없다. */
const COLUMN_SORTS: Record<string, { key: string; first?: "asc" | "desc" }> = {
  과제: { key: "title" },
  상태: { key: "status" },
  속성: { key: "type" },
  성격: { key: "nature" },
  그룹: { key: "group" },
  담당자: { key: "owner" },
  태그: { key: "tag" },
  마감: { key: "due" },
  효과: { key: "effect", first: "desc" },
  기록: { key: "entries", first: "desc" },
  "최근 업데이트": { key: "updated", first: "desc" },
};

/** 효과 칸의 합계 — 줄과 같은 `기대 → 실증` 모양. 둘 다 0 이면 `-` 하나 (TODO 157 · 158) */
function effectTotal(expected: number, verified: number): string {
  const [left, right] = [cellEffect(expected), cellEffect(verified)];
  return left === DASH && right === DASH ? DASH : `${left} → ${right}`;
}

function readFilters(params: URLSearchParams): typeof DEFAULT_FILTERS {
  const values = { ...DEFAULT_FILTERS };
  for (const key of Object.keys(values) as (keyof typeof values)[]) {
    values[key] = params.get(key) ?? DEFAULT_FILTERS[key];
  }
  return values;
}

export default function ProjectList({ meta, onMetaChange, query }: Props) {
  const [projects, setProjects] = useState<Project[]>([]);
  // 조건은 주소에서 시작한다. 처음 열 때든, 과제를 보고 돌아왔을 때든 같은 길이다.
  const [filters, setFilters] = useState(() => readFilters(new URLSearchParams(query)));
  const showClasses =
    filters.type === meta.classified_type || meta.classifications.some((info) => Boolean(filters[info.key]));
  const [view, setView] = useState<"table" | "board">(
    () => (localStorage.getItem("md-mgmt:view") === "board" ? "board" : "table"),
  );
  // 홈의 [첫 과제 만들기]가 `#/projects?new=1` 로 보낸다 (TODO 84).
  // 조건이 아니라 한 번 쓰고 마는 신호라 filters 에 넣지 않는다 — 주소에도 남기지 않는다.
  const [creating, setCreating] = useState(() => new URLSearchParams(query).get("new") === "1");
  const [error, setError] = useState<string | null>(null);
  const [reindexing, setReindexing] = useState(false);
  // 과제가 늘거나 다시 읽었을 때 대시보드도 같이 갱신한다.
  const [refreshKey, setRefreshKey] = useState(0);

  const load = useCallback(() => {
    api
      .listProjects(toQuery(filters))
      .then((rows) => {
        setProjects(rows);
        // 성공하면 지난 오류는 지운다. 안 그러면 한 번의 실패가 화면에 계속 남는다.
        setError(null);
      })
      .catch((err: Error) => setError(err.message));
  }, [filters]);

  useEffect(load, [load]);

  // 고른 조건과 주소를 맞춘다. 기본값은 적지 않아 주소가 짧게 유지된다.
  useAddressBar(
    "projects",
    Object.fromEntries(
      Object.entries(filters).filter(
        ([key, value]) => value !== DEFAULT_FILTERS[key as keyof typeof DEFAULT_FILTERS],
      ),
    ) as Record<string, string>,
    (params) => setFilters(readFilters(params)),
  );

  const setFilter = (key: string, value: string) =>
    setFilters((prev) => ({ ...prev, [key]: value }));

  // 정렬 선택 상자와 열 머리글이 같은 값을 본다 — 둘이 따로 놀면 무엇이 이기는지 헷갈린다.
  const sortState: SortState | null = filters.order
    ? { key: filters.sort, order: filters.order as "asc" | "desc" }
    : null;
  const onSort = (next: SortState) =>
    setFilters((prev) => ({ ...prev, sort: next.key, order: next.order }));
  // 한 줄 칸은 `nowrap`, 과제·담당자·태그는 좁혀 두 줄까지 접힌다 (TODO 160). 칸 모양은 이름표로 준다.
  const header = (label: string, className?: string) => {
    const column = COLUMN_SORTS[label];
    return { sortKey: column?.key, first: column?.first, current: sortState, onSort, className };
  };

  // 합계 줄이 더하는 효과 — 연도를 골랐으면 **그 해에 세는 것만**(끝나는 해가 그 해). 홈의 금액과 같다 (TODO 181)
  const effectRows =
    filters.year === ALL_YEARS ? projects : projects.filter((p) => !p.effect_year || p.effect_year === filters.year);

  return (
    <section className="project-list">
      {/* 홈에서 숫자를 눌러 들어오면 돌아갈 길을 그린다 (TODO 127).
          메뉴로 들어온 경우에는 온 곳이 없으므로 그리지 않는다 — 없는 길을 만들지 않는다. */}
      {filters.back && (
        <a className="back" href={backTarget(filters.back).href}>
          ← {backTarget(filters.back).label}
        </a>
      )}
      {/* 메뉴마다 같은 머리 — 제목 한 줄 + 설명 한 줄 (TODO 147) */}
      <div className="page-head">
        <h1>과제목록</h1>
        <p className="hint page-desc">과제를 상태·속성·그룹·담당자·연도로 거르고 정렬합니다. 줄을 누르면 과제 상세로 갑니다.</p>
      </div>
      <Dashboard
        refreshKey={refreshKey}
        filters={filters}
        onFilter={(key, value) => setFilter(key, value)}
      />

      <div className="toolbar">
        <div className="filters">
          <select value={filters.status} onChange={(event) => setFilter("status", event.target.value)}>
            <option value="">상태 전체</option>
            {meta.statuses.map((status) => (
              <option key={status.key} value={status.key}>
                {status.label}
              </option>
            ))}
          </select>
          <select value={filters.type} onChange={(event) => setFilter("type", event.target.value)}>
            <option value="">속성 전체</option>
            <option value="none">미지정</option>
            {meta.types.map((type) => (
              <option key={type.key} value={type.key}>
                {type.label}
              </option>
            ))}
          </select>
          <select value={filters.group} onChange={(event) => setFilter("group", event.target.value)}>
            <option value="">그룹 전체</option>
            {/* 홈의 그룹별 표가 [미지정] 줄을 세우고 이리로 이어 준다 — 상자도 그 말을
                할 수 있어야 한다. 안 적은 과제가 하나도 없으면 세우지 않는다 (TODO 96). */}
            {meta.groups_none && <option value="none">미지정</option>}
            {meta.groups.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </select>
          <select value={filters.tag} onChange={(event) => setFilter("tag", event.target.value)}>
            <option value="">태그 전체</option>
            {/* 진행일지에만 붙은 태그로 과제를 거르면 늘 0건이다 (TODO 96) */}
            {(meta.project_tags ?? meta.tags).map((tag) => (
              <option key={tag} value={tag}>
                {tag}
              </option>
            ))}
          </select>
          <select value={filters.owner} onChange={(event) => setFilter("owner", event.target.value)}>
            <option value="">담당자 전체</option>
            <option value="none">미지정</option>
            {meta.owners.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
          {/* 유관부서 (TODO 92). **아직 아무 데도 안 적었으면 세우지 않는다** —
              쓰지 않는 팀에게까지 고를 것 없는 선택 상자를 늘릴 이유가 없다.
              팀과 그쪽 담당자를 한 상자에 담는다. 어느 쪽을 기억하든 찾힌다. */}
          {(meta.partner_teams?.length || meta.partner_people?.length) > 0 && (
            <select value={filters.partner} onChange={(event) => setFilter("partner", event.target.value)}>
              <option value="">유관부서 전체</option>
              {meta.partner_teams?.length > 0 && (
                <optgroup label="부서">
                  {meta.partner_teams.map((team) => (
                    <option key={team} value={team}>
                      {team}
                    </option>
                  ))}
                </optgroup>
              )}
              {meta.partner_people?.length > 0 && (
                <optgroup label="담당자">
                  {meta.partner_people.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </optgroup>
              )}
            </select>
          )}
          {/* 과제 분류 넷 (TODO 136). 목록은 설정에서 온다. 넷은 스마트과제의 칸이라
              **속성에서 스마트과제를 골랐거나 분류 조건이 이미 걸려 있을 때만** 세운다 —
              늘 세우면 거르기 줄이 두 줄로 넘어가고, 다른 속성을 볼 때는 쓸 일이 없다. */}
          {showClasses && meta.classifications.map((info) => (
            <select
              key={info.key}
              value={filters[info.key]}
              onChange={(event) => setFilter(info.key, event.target.value)}
              aria-label={info.label}
            >
              <option value="">{info.label} 전체</option>
              {info.items.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
              {/* 목록에서 빠진 예전 값으로 걸려 왔으면 그 값도 보여 준다 — 빈칸으로 보이면 안 된다 */}
              {filters[info.key] && filters[info.key] !== "none" && !info.items.includes(filters[info.key]) && (
                <option value={filters[info.key]}>{filters[info.key]}</option>
              )}
              <option value="none">미지정</option>
            </select>
          ))}
          <select
            value={filters.from_intake}
            onChange={(event) => setFilter("from_intake", event.target.value)}
            aria-label="등록 경로"
          >
            <option value="">등록 경로 전체</option>
            <option value="yes">접수에서 승격</option>
            <option value="no">직접 등록</option>
          </select>
          {/* 첫 화면이 늘 전체면 해가 갈수록 쓸모가 떨어진다. 기본은 올해다.
              세우는 해는 **과제가 실제로 있는 해**뿐이다 (TODO 96). */}
          <select value={filters.year} onChange={(event) => setFilter("year", event.target.value)} aria-label="연도">
            <option value={ALL_YEARS}>연도 전체</option>
            {yearOptions(meta.years, filters.year).map((year) => (
              <option key={year} value={year}>
                {year}년
              </option>
            ))}
          </select>
          {/* 연도는 그 해에 수행한 과제 전부(다년도 과제는 해마다). 그중 그 해에 시작한 것만 (TODO 181) */}
          {filters.year !== ALL_YEARS && (
            <label className="roadmap-check list-new-check" title="과제 번호의 연도가 이 해인 과제 — 그 해에 새로 착수한 과제">
              <input
                type="checkbox"
                checked={filters.new === "1"}
                onChange={(event) => setFilter("new", event.target.checked ? "1" : "")}
              />
              신규 착수만
            </label>
          )}
          <select value={filters.due} onChange={(event) => setFilter("due", event.target.value)}>
            <option value="">마감 전체</option>
            <option value="overdue">기한 초과</option>
            <option value="7">7일 이내</option>
            <option value="14">14일 이내</option>
            <option value="30">30일 이내</option>
          </select>
          {/* 선택 상자와 열 머리글은 같은 값을 쓴다. 상자에서 고르면 그 정렬이 원래 갖는
              방향을 따르고(order 를 비운다), 머리글을 누르면 방향까지 정한다. */}
          <select
            value={filters.sort}
            onChange={(event) =>
              setFilters((prev) => ({ ...prev, sort: event.target.value, order: "" }))
            }
          >
            <option value="updated">최근 업데이트순</option>
            <option value="due">마감일순</option>
            <option value="reported">보고 경과일순</option>
            <option value="effect">효과 큰 순</option>
            <option value="created">생성순</option>
            <option value="title">이름순</option>
          </select>
        </div>
        <div className="toolbar-actions">
          <div className="view-switch">
            {(["table", "board"] as const).map((option) => (
              <button
                key={option}
                className={view === option ? "active" : "ghost"}
                onClick={() => {
                  setView(option);
                  localStorage.setItem("md-mgmt:view", option);
                }}
              >
                {option === "table" ? "표" : "보드"}
              </button>
            ))}
          </div>
          {/* 지금 걸러진 줄 그대로 엑셀로 (TODO 108). 화면의 표와 열이 같다. */}
          <CopyTableButton
            headers={["번호", "과제", "상태", "속성", "성격", "그룹", "담당자", "유관부서", "태그", "시작", "마감", `기대효과(${EFFECT_UNIT})`, `실증효과(${EFFECT_UNIT})`, "기록", "미보고"]}
            rows={() =>
              projects.map((project) => [
                project.id,
                project.title,
                meta.statuses.find((status) => status.key === shownStatus(project))?.label ?? shownStatus(project),
                meta.types.find((type) => type.key === project.type)?.label ?? project.type ?? "",
                project.nature ?? "",
                project.group ?? "",
                project.owners.join(", "),
                project.partners.map((partner) => partner.team).join(", "),
                project.tags.join(", "),
                project.start_date ?? "",
                project.due_date ?? "",
                project.effect_expected ?? "",
                project.effect_verified ?? "",
                project.entry_count,
                project.unreported_entries ?? "",
              ])
            }
          />
          <button
            className="ghost"
            disabled={reindexing}
            onClick={async () => {
              setReindexing(true);
              const result = await api.reindex().catch((err: Error) => {
                notifyError(err.message);
                return null;
              });
              setReindexing(false);
              if (!result) return;
              load();
              onMetaChange();
              setRefreshKey((value) => value + 1);
            }}
            title="폴더를 직접 수정했을 때 다시 읽어들입니다"
          >
            {reindexing ? "읽는 중…" : "다시 읽기"}
          </button>
          <button onClick={() => setCreating(true)}>과제 추가</button>
        </div>
      </div>

      {creating && (
        <div className="card">
          <h2>새 과제</h2>
          <ProjectForm
            meta={meta}
            onMetaChange={onMetaChange}
            submitLabel="만들기"
            onCancel={() => setCreating(false)}
            onSubmit={async (payload) => {
              const created = await api.createProject(payload);
              setCreating(false);
              onMetaChange();
              setRefreshKey((value) => value + 1);
              // 만들면 대개 곧바로 개요나 첫 기록을 쓴다. 상세로 데려간다.
              window.location.hash = projectLink(created.id);
            }}
          />
        </div>
      )}

      {error && <LoadError message={error} onRetry={load} />}

      {/* 읽지 못한 파일 · 값 — [다시 읽기] 를 누르기 전에도 늘 보인다 (TODO 164) */}
      <ProblemsBanner problems={meta.problems ?? []} onReindexed={() => { load(); onMetaChange(); }} />

      {view === "board" && <ProjectBoard meta={meta} projects={projects} year={filters.year === ALL_YEARS ? undefined : filters.year} />}

      {view === "table" && (
      /* 좁은 화면에서는 표만 가로로 민다 — 한 줄 칸을 다시 꺾지 않는다 (TODO 160) */
      <div className="table-scroll">
      <table className="grid project-table">
        <thead>
          <tr>
            <SortHeader {...header("과제", "col-title")}>과제</SortHeader>
            <SortHeader {...header("상태", "one-line")}>상태</SortHeader>
            <SortHeader {...header("속성", "one-line")}>속성</SortHeader>
            {/* 스마트과제는 성격이 중요하다 — 속성 바로 옆 (TODO 159) */}
            <SortHeader {...header("성격", "one-line")}>성격</SortHeader>
            <SortHeader {...header("그룹", "one-line")}>그룹</SortHeader>
            <SortHeader {...header("담당자", "col-owners")}>담당자</SortHeader>
            <SortHeader {...header("태그", "col-tags")}>태그</SortHeader>
            <SortHeader {...header("마감", "one-line")}>마감</SortHeader>
            <SortHeader {...header("효과", "one-line num")}>
              <span title={`기대효과 → 실증효과 (${EFFECT_UNIT})`}>
                효과<span className="th-unit">{EFFECT_UNIT}</span>
              </span>
            </SortHeader>
            <SortHeader {...header("기록", "one-line num")}>기록</SortHeader>
            <SortHeader {...header("최근 업데이트", "one-line")}>최근 업데이트</SortHeader>
          </tr>
        </thead>
        <tbody>
          {projects.map((project) => {
            const due = dueLabel(project.due_date, project.status);
            return (
              <tr key={project.id} onClick={() => (window.location.hash = projectLink(project.id))}>
                <td className="col-title">
                  <span className="project-id">{project.id}</span>
                  <span className="project-title">{project.title}</span>
                  <StageBand stage={project.stage} />
                </td>
                <td className="one-line">
                  {/* 연도를 고르면 그 해의 상태 — 숫자 · 거르기와 같은 기준 (TODO 184) */}
                  <YearStatusBadge project={project} meta={meta} year={filters.year === ALL_YEARS ? undefined : filters.year} />
                </td>
                <td className="one-line">
                  {/* 속성이 없으면 표의 빈 값 `-` (158) — 딱지 부품의 `—` 는 표 밖의 규칙이다 (TODO 169) */}
                  {project.type ? <TypeBadge type={project.type} meta={meta} /> : <span className="muted">{DASH}</span>}
                  {/* 금액으로 재지 않는 과제 (TODO 125) */}
                  {project.no_effect && (
                    <span className="tag" title="효과성 관리 비대상 과제">
                      효과 비대상
                    </span>
                  )}
                </td>
                {/* 성격 — 스마트과제가 아니면 대개 비어 있다 (TODO 159) */}
                <td className={project.nature ? "one-line" : "one-line muted"}>{project.nature || DASH}</td>
                {/* 그룹은 말줄임 없이 끝까지 — 중요한 정보라 바로 보여야 한다 (TODO 160 결정) */}
                <td className="one-line">{project.group || DASH}</td>
                <td className="owners col-owners">
                  {project.owners.length > 0
                    ? project.owners.map((name, i) => (
                        // 쉼표 **뒤의 빈칸은 이름 밖에** — 줄은 이름 사이에서만 바뀐다 (TODO 160)
                        <Fragment key={name}>
                          {i > 0 && ", "}
                          <span className="owner-name">
                          {name}
                          {/* 떠난 사람은 이름 옆에 딱지. 이름 자체는 지우지 않는다 (TODO 122) */}
                          {leftLabel(meta, name) && (
                            <span className="tag left-tag">{leftLabel(meta, name)}</span>
                          )}
                          </span>
                        </Fragment>
                      ))
                    : DASH}
                </td>
                <td className="tags col-tags">
                  {project.tags.length > 0
                    ? project.tags.map((tag) => (
                        <span key={tag} className="tag">
                          {tag}
                        </span>
                      ))
                    : <span className="muted">{DASH}</span>}
                </td>
                <td className="one-line">
                  {/* 끝난 과제는 남은 날짜 없이 마감일만 보여 준다. 남은 날과 날짜는 한 줄에 나란히 (TODO 160) */}
                  {due && <span className={`due due-${due.tone}`}>{due.text}</span>}
                  <span className="due-date">{project.due_date ? project.due_date.slice(0, 10) : DASH}</span>
                </td>
                <td className="effect-col one-line num">
                  {(() => {
                    // 기대 → 실증. 표 안이라 0·빈 값은 `-` (TODO 156 · 158)
                    const expected = project.effect_expected;
                    const verified = project.effect_verified;
                    if (expected == null && verified == null) return <span className="muted">{DASH}</span>;
                    // 연도를 골랐는데 효과를 다른 해(끝나는 해)에 세는 과제 — 흐리게, 합계에서 뺀다 (TODO 181)
                    const elsewhere =
                      filters.year !== ALL_YEARS && project.effect_year && project.effect_year !== filters.year;
                    const text =
                      expected != null && verified != null
                        ? `${cellEffect(expected)} → ${cellEffect(verified)}`
                        : cellEffect(verified ?? expected);
                    return (
                      <span
                        className={`effect${verified != null ? " verified" : ""}${elsewhere ? " elsewhere" : ""}`}
                        title={
                          elsewhere
                            ? `효과는 끝나는 해(${project.effect_year}년)에 셉니다 — 이 해의 합계에는 들지 않습니다`
                            : verified != null
                              ? `실증효과 확인됨 (${EFFECT_UNIT})`
                              : `기대효과 — 아직 실증 전 (${EFFECT_UNIT})`
                        }
                      >
                        {text}
                      </span>
                    );
                  })()}
                </td>
                <td className="one-line num">{cellCount(project.entry_count, "건")}</td>
                <td className="one-line">{project.updated_at ? project.updated_at.slice(0, 10) : DASH}</td>
              </tr>
            );
          })}
          {projects.length === 0 && (
            <tr>
              <td colSpan={11} className="empty">
                과제가 없습니다. [과제 추가]로 시작하세요.
              </td>
            </tr>
          )}
        </tbody>
        {/* 지금 걸러진 과제만 더한다 (TODO 157). 효과는 기대·실증을 **따로** 더한다 — 합치지 않는다 */}
        {projects.length > 0 && (
          <TotalRow
            label={`합계 (${projects.length}건)`}
            cells={[
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              {
                // 연도를 골랐으면 그 해에 세는 효과만 — 홈의 금액과 같게 (TODO 181)
                text: effectTotal(
                  sumBy(effectRows, (p) => p.effect_expected),
                  sumBy(effectRows, (p) => p.effect_verified),
                ),
                className: "num",
                title: `기대효과 합계 → 실증효과 합계 (${EFFECT_UNIT})`,
              },
              { text: cellCount(sumBy(projects, (p) => p.entry_count), "건"), className: "num" },
              null,
            ]}
          />
        )}
      </table>
      </div>
      )}
    </section>
  );
}
