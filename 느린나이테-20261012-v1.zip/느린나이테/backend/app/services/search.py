"""통합 검색.

FTS5 trigram은 3글자 이상에서만 매칭되므로, 짧은 질의는 LIKE로 처리한다.
한국어는 형태소 분석 없이도 부분 문자열 검색이면 대부분 충분하다.

**두 길이 같은 곳을 봐야 한다.** FTS 색인에는 담당자·태그·유관부서가 본문 뒤에
덧붙어 있으므로, LIKE 쪽도 그 자리를 함께 훑는다. 그러지 않으면 "이준" 같은 두 글자
이름이 짧다는 이유만으로 안 찾힌다.
"""
from __future__ import annotations

import sqlite3

from .projects import overview_is_blank, stage_map

SNIPPET_RADIUS = 70
MIN_FTS_LENGTH = 3

# 종류마다 따로 상한을 둔다.
#
# 예전에는 셋을 합쳐 60개였다. 그래서 흔한 낱말로 찾으면 진행일지가 자리를 다 먹고
# **제목이 딱 맞는 과제가 밀려날 수** 있었다. 종류를 나누면 그런 일이 없다.
KIND_LIMITS = {"project": 30, "entry": 40, "report": 30}
ATTACHMENT_LIMIT = 20
# 접수 (TODO 144). 건수가 과제보다 훨씬 적어 LIKE 로 충분하다 — FTS 색인에 넣지 않는다.
INTAKE_LIMIT = 20


def _fts_query(text: str) -> str:
    """FTS5 문법 문자를 그대로 검색어로 다루기 위해 통째로 인용한다."""
    return '"' + text.replace('"', '""') + '"'


def make_snippet(body: str, query: str) -> str:
    """검색어 둘레의 한 줄. **서식 기호는 뺀다** (TODO 103-C) — 보고 이력의 발췌와 같은 눈으로."""
    from .reports import readable_text

    body = readable_text(body)
    if not body:
        return ""
    position = body.lower().find(query.lower())
    if position < 0:
        return body[: SNIPPET_RADIUS * 2] + ("…" if len(body) > SNIPPET_RADIUS * 2 else "")
    start = max(0, position - SNIPPET_RADIUS)
    end = min(len(body), position + len(query) + SNIPPET_RADIUS)
    return ("…" if start > 0 else "") + body[start:end] + ("…" if end < len(body) else "")


def _refs_for(
    conn: sqlite3.Connection, query: str, kind: str, limit: int
) -> tuple[list[str], bool]:
    """한 종류의 ref_id 목록과 **잘렸는지 여부**.

    상한보다 하나 더 읽어 본다. 하나가 더 있으면 잘린 것이다 — 그래야 화면이
    "N건" 이 아니라 "N건 이상" 이라고 말할 수 있다.
    """
    if len(query) >= MIN_FTS_LENGTH:
        try:
            rows = conn.execute(
                "SELECT ref_id FROM search_fts WHERE search_fts MATCH ? AND kind = ? LIMIT ?",
                (_fts_query(query), kind, limit + 1),
            ).fetchall()
            return [row["ref_id"] for row in rows[:limit]], len(rows) > limit
        except sqlite3.OperationalError:
            pass  # trigram 미지원 등 — LIKE로 물러난다

    pattern = f"%{query}%"
    # 두 글자 이하로 찾을 때 오는 길이다. FTS 색인에는 담당자·태그·유관부서가 본문 뒤에
    # 덧붙어 있는데, 여기서 제목·본문만 훑으면 **짧은 이름은 영영 안 찾힌다** —
    # "이준" 같은 두 글자 이름이나 "구매" 같은 부서가 그렇다 (TODO 92).
    # FTS 가 보는 것과 같은 자리를 보게 맞춘다.
    sql = {
        "project": (
            "SELECT id AS ref_id FROM project p"
            " WHERE p.title LIKE ? OR p.body LIKE ?"
            "    OR EXISTS (SELECT 1 FROM project_owner po"
            "                WHERE po.project_id = p.id AND po.name LIKE ?)"
            "    OR EXISTS (SELECT 1 FROM project_tag pt JOIN tag t ON t.id = pt.tag_id"
            "                WHERE pt.project_id = p.id AND t.name LIKE ?)"
            "    OR EXISTS (SELECT 1 FROM project_partner pp"
            "                WHERE pp.project_id = p.id"
            "                  AND (pp.team LIKE ? OR pp.person LIKE ?))"
        ),
        "entry": "SELECT CAST(id AS TEXT) AS ref_id FROM entry WHERE title LIKE ? OR body LIKE ?",
        "report": (
            "SELECT CAST(id AS TEXT) AS ref_id FROM report"
            " WHERE title LIKE ? OR body LIKE ? OR audience LIKE ?"
        ),
    }[kind]
    params = [pattern] * {"project": 6, "entry": 2, "report": 3}[kind]
    rows = conn.execute(f"{sql} LIMIT ?", (*params, limit + 1)).fetchall()
    return [row["ref_id"] for row in rows[:limit]], len(rows) > limit


def search(conn: sqlite3.Connection, query: str, limit: int | None = None) -> dict:
    """통합 검색. 종류마다 상한이 따로 있고, **잘렸으면 잘렸다고 알린다.**

    `limit` 은 목록 거르기(`project_ids_matching`)처럼 더 많이 필요할 때만 준다.
    """
    query = (query or "").strip()
    if not query:
        return {
            "query": "", "projects": [], "entries": [], "reports": [], "attachments": [],
            "intakes": [], "total": 0, "truncated": {},
        }

    # 상한을 통째로 올려 받는 경우(목록 거르기)를 위해 값으로 넘긴다.
    # 모듈 전역을 고치면 그 뒤의 모든 검색이 함께 바뀐다.
    caps = {kind: (limit or KIND_LIMITS[kind]) for kind in KIND_LIMITS}
    attachment_cap = limit or ATTACHMENT_LIMIT

    project_ids, projects_cut = _refs_for(conn, query, "project", caps["project"])
    entry_refs, entries_cut = _refs_for(conn, query, "entry", caps["entry"])
    report_refs, reports_cut = _refs_for(conn, query, "report", caps["report"])
    entry_ids = [int(ref) for ref in entry_refs]
    report_ids = [int(ref) for ref in report_refs]

    projects = []
    stages = stage_map(conn) if project_ids else {}  # 과제명 뒤 단계 띠 (TODO 175)
    if project_ids:
        placeholders = ",".join("?" * len(project_ids))
        for row in conn.execute(
            f"SELECT id, title, status, grp, body, updated_at FROM project WHERE id IN ({placeholders})",
            project_ids,
        ):
            projects.append(
                {
                    "id": row["id"],
                    "title": row["title"],
                    "stage": stages.get(row["id"]),
                    "status": row["status"],
                    "group": row["grp"],
                    "updated_at": row["updated_at"],
                    # 서식 그대로인 개요는 발췌하지 않는다 — 안내 문장이 본문인 양 실린다 (TODO 106-B).
                    "snippet": "" if overview_is_blank(row["body"]) else make_snippet(row["body"], query),
                }
            )

    entries = []
    if entry_ids:
        placeholders = ",".join("?" * len(entry_ids))
        for row in conn.execute(
            f"""
            SELECT e.id, e.project_id, e.date, e.title, e.body, p.title AS project_title
              FROM entry e JOIN project p ON p.id = e.project_id
             WHERE e.id IN ({placeholders})
             ORDER BY e.date DESC
            """,
            entry_ids,
        ):
            entries.append(
                {
                    "id": row["id"],
                    "project_id": row["project_id"],
                    "project_title": row["project_title"],
                    "date": row["date"],
                    "title": row["title"],
                    "snippet": make_snippet(row["body"], query),
                }
            )

    # 보고 문서. "그 회의체에 뭘 보고했더라" 를 상단 검색 하나로 답한다 (TODO 53).
    reports = []
    if report_ids:
        placeholders = ",".join("?" * len(report_ids))
        for row in conn.execute(
            f"""
            SELECT r.id, r.project_id, r.report_date, r.title, r.audience, r.body, r.frozen_at,
                   p.title AS project_title
              FROM report r JOIN project p ON p.id = r.project_id
             WHERE r.id IN ({placeholders})
             ORDER BY r.report_date DESC, r.id DESC
            """,
            report_ids,
        ):
            reports.append(
                {
                    "id": row["id"],
                    "project_id": row["project_id"],
                    "project_title": row["project_title"],
                    "report_date": row["report_date"],
                    "title": row["title"],
                    "audience": row["audience"],
                    "frozen": bool(row["frozen_at"]),
                    "snippet": make_snippet(row["body"], query),
                }
            )

    # 첨부는 본문이 없으므로 파일명으로만 찾는다.
    attachments = [
        {
            "id": row["id"],
            "project_id": row["project_id"],
            "project_title": row["project_title"],
            "orig_name": row["orig_name"],
            "rel_path": row["rel_path"],
            "size_bytes": row["size_bytes"],
        }
        for row in conn.execute(
            """
            SELECT a.id, a.project_id, a.orig_name, a.rel_path, a.size_bytes, p.title AS project_title
              FROM attachment a JOIN project p ON p.id = a.project_id
             WHERE a.orig_name LIKE ?
             ORDER BY a.rel_path LIMIT ?
            """,
            (f"%{query}%", attachment_cap + 1),
        )
    ]
    attachments_cut = len(attachments) > attachment_cap
    attachments = attachments[:attachment_cap]

    intakes, intakes_cut = _intakes(conn, query, limit or INTAKE_LIMIT)

    return {
        "query": query,
        "projects": projects,
        "entries": entries,
        "reports": reports,
        "attachments": attachments,
        "intakes": intakes,
        "total": len(projects) + len(entries) + len(reports) + len(attachments) + len(intakes),
        # 어느 갈래가 잘렸는지. 화면이 "N건" 대신 "N건 이상" 이라고 말하는 근거다.
        "truncated": {
            "projects": projects_cut,
            "entries": entries_cut,
            "reports": reports_cut,
            "attachments": attachments_cut,
            "intakes": intakes_cut,
        },
    }


def _intakes(conn: sqlite3.Connection, query: str, cap: int) -> tuple[list[dict], bool]:
    """접수 건 — 번호·제목·요청 본문·과제리더·소속·태그를 훑는다 (TODO 144).

    반년 뒤 "그 요청 어떻게 됐더라" 를 찾는 길이다. 반려·이관된 것도 찾아져야 한다 —
    그래서 풀(판정 전)만이 아니라 전부를 본다.
    """
    from ..config import INTAKE_STATUS_LABELS

    like = f"%{query}%"
    rows = conn.execute(
        """
        SELECT id, title, status, leader, leader_team, received_on, project_id, merged_into, body
          FROM intake
         WHERE id LIKE ? OR title LIKE ? OR body LIKE ? OR leader LIKE ? OR leader_team LIKE ?
               OR tags LIKE ?
         ORDER BY received_on DESC, id DESC LIMIT ?
        """,
        (like, like, like, like, like, like, cap + 1),
    ).fetchall()
    items = [
        {
            "id": row["id"],
            "title": row["title"],
            "status": row["status"],
            "status_label": INTAKE_STATUS_LABELS.get(row["status"], row["status"]),
            "leader": row["leader"],
            "leader_team": row["leader_team"],
            "received_on": row["received_on"],
            "project_id": row["project_id"] or row["merged_into"],
            "snippet": make_snippet(row["body"] or "", query),
        }
        for row in rows[:cap]
    ]
    return items, len(rows) > cap


def project_ids_matching(conn: sqlite3.Connection, query: str) -> list[str]:
    """검색어에 걸리는 과제 id 목록 (본문·진행일지·보고·첨부 파일명 모두 대상)."""
    result = search(conn, query, limit=500)
    ids = {item["id"] for item in result["projects"]}
    ids.update(item["project_id"] for item in result["entries"])
    ids.update(item["project_id"] for item in result["reports"])
    ids.update(item["project_id"] for item in result["attachments"])
    return sorted(ids)
