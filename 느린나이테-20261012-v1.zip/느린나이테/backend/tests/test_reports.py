from __future__ import annotations

from datetime import date, timedelta


def make_project(client, title="리튬전지 수명평가", **kwargs):
    payload = {"title": title, "status": "in_progress"}
    payload.update(kwargs)
    return client.post("/api/projects", json=payload).json()


def add_entry(client, project_id, date_str, title, body="내용"):
    return client.post(
        f"/api/projects/{project_id}/entries",
        json={"date": date_str, "title": title, "body": body},
    ).json()


def test_draft_collects_unreported_entries(client, vault_dir):
    project = make_project(client)
    add_entry(client, project["id"], "2026-08-25", "셀 조립", "3종 조립 완료")
    add_entry(client, project["id"], "2026-09-03", "1차 측정", "유지율 98.2%")

    report = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()

    assert report["report_date"] == "2026-09-08"
    assert report["frozen"] is False
    assert report["covers_from"] == "2026-08-25"
    assert report["covers_to"] == "2026-09-03"
    # 초안에는 미보고 진행일지의 제목과 본문이 함께 담긴다.
    assert "셀 조립" in report["body"] and "유지율 98.2%" in report["body"]

    path = vault_dir / "projects" / f"{project['id']}-리튬전지-수명평가" / "reports" / "2026-09-08" / "report.md"
    assert path.exists()


def test_freeze_makes_report_readonly_and_resets_backlog(client):
    project = make_project(client)
    add_entry(client, project["id"], "2026-08-25", "셀 조립")
    report = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()

    client.patch(f"/api/reports/{report['id']}", json={"body": "정리한 보고 내용"})
    frozen = client.post(f"/api/reports/{report['id']}/freeze").json()
    assert frozen["frozen"] is True
    assert frozen["entry_count"] == 1

    # 확정 뒤에는 수정이 막힌다.
    blocked = client.patch(f"/api/reports/{report['id']}", json={"body": "몰래 수정"})
    assert blocked.status_code == 409
    assert client.get(f"/api/reports/{report['id']}").json()["body"] == "정리한 보고 내용"

    # 확정된 보고에 담긴 진행일지는 미보고 분량에서 빠진다.
    candidate = next(
        item for item in client.get("/api/report-candidates").json()["items"]
        if item["id"] == project["id"]
    )
    assert candidate["unreported_entries"] == 0
    assert candidate["last_reported_at"] == "2026-09-08"


def test_frozen_report_keeps_its_snapshot_when_entries_change(client):
    """보고 뒤 진행일지를 고쳐도 보고 문서는 그대로여야 한다."""
    project = make_project(client)
    entry = add_entry(client, project["id"], "2026-08-25", "셀 조립", "초기 결과")
    report = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.post(f"/api/reports/{report['id']}/freeze")

    client.patch(f"/api/entries/{entry['id']}", json={"body": "나중에 수정한 결과"})
    assert "초기 결과" in client.get(f"/api/reports/{report['id']}").json()["body"]


def test_second_draft_only_covers_entries_after_the_last_report(client):
    project = make_project(client)
    add_entry(client, project["id"], "2026-08-25", "셀 조립")
    first = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.post(f"/api/reports/{first['id']}/freeze")

    add_entry(client, project["id"], "2026-09-10", "2차 측정", "새 결과")
    second = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-15"}
    ).json()

    assert "2차 측정" in second["body"]
    assert "셀 조립" not in second["body"]
    assert second["covers_from"] == "2026-09-10"


def test_unfreeze_allows_correction_and_records_it(client, vault_dir):
    project = make_project(client)
    add_entry(client, project["id"], "2026-08-25", "셀 조립")
    report = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.post(f"/api/reports/{report['id']}/freeze")

    assert client.post(f"/api/reports/{report['id']}/unfreeze").json()["frozen"] is False
    assert client.patch(f"/api/reports/{report['id']}", json={"body": "고친 내용"}).status_code == 200

    path = vault_dir / "projects" / f"{project['id']}-리튬전지-수명평가" / "reports" / "2026-09-08" / "report.md"
    assert "unfrozen_at:" in path.read_text(encoding="utf-8")


def test_several_reports_can_share_one_date(client, vault_dir):
    """중간 보고와 완료 보고를 같은 날 각각 남길 수 있어야 한다."""
    project = make_project(client)
    add_entry(client, project["id"], "2026-09-01", "기록")

    first = client.post(
        f"/api/projects/{project['id']}/reports/draft",
        json={"report_date": "2026-09-08", "audience": "팀장"},
    )
    second = client.post(
        f"/api/projects/{project['id']}/reports/draft",
        json={"report_date": "2026-09-08", "audience": "연구소장"},
    )
    assert first.status_code == 201 and second.status_code == 201

    assert first.json()["rel_path"] == "reports/2026-09-08/report.md"
    assert second.json()["rel_path"] == "reports/2026-09-08-2/report.md"
    assert second.json()["report_date"] == "2026-09-08"  # 날짜는 그대로다
    listed = client.get(f"/api/projects/{project['id']}/reports").json()
    assert sorted(item["audience"] for item in listed) == ["연구소장", "팀장"]

    folders = sorted(
        path.name for path in (vault_dir / "projects" / f"{project['id']}-리튬전지-수명평가" / "reports").iterdir()
    )
    assert folders == ["2026-09-08", "2026-09-08-2"]


def test_audience_can_be_fixed_after_freezing_but_body_cannot(client):
    """피보고자를 잘못 적었다고 확정을 풀 이유는 없다. 본문은 그대로 잠근다."""
    project = make_project(client)
    add_entry(client, project["id"], "2026-09-01", "기록")
    report = client.post(
        f"/api/projects/{project['id']}/reports/draft",
        json={"report_date": "2026-09-08", "audience": "팀정"},
    ).json()
    client.post(f"/api/reports/{report['id']}/freeze")

    fixed = client.patch(f"/api/reports/{report['id']}", json={"audience": "팀장"})
    assert fixed.status_code == 200
    assert fixed.json()["audience"] == "팀장"

    blocked = client.patch(f"/api/reports/{report['id']}", json={"body": "내용 수정"})
    assert blocked.status_code == 409


def test_audience_list_is_offered_for_autocomplete(client):
    project = make_project(client)
    for date, audience in (("2026-09-08", "팀장"), ("2026-09-15", "주간회의체")):
        client.post(
            f"/api/projects/{project['id']}/reports/draft",
            json={"report_date": date, "audience": audience},
        )
    assert client.get("/api/meta").json()["audiences"] == ["주간회의체", "팀장"]


def test_candidates_rank_by_elapsed_time_and_backlog(client):
    stale = make_project(client, title="오래된 과제", start_date="2026-01-01")
    for day in ("2026-08-01", "2026-08-10", "2026-08-20"):
        add_entry(client, stale["id"], day, f"{day} 기록")

    fresh = make_project(client, title="최근 보고한 과제", start_date="2026-08-25")
    add_entry(client, fresh["id"], "2026-08-26", "기록")
    report = client.post(
        f"/api/projects/{fresh['id']}/reports/draft", json={"report_date": date.today().isoformat()}
    ).json()
    client.post(f"/api/reports/{report['id']}/freeze")

    items = client.get("/api/report-candidates").json()["items"]
    assert items[0]["id"] == stale["id"]
    assert items[0]["unreported_entries"] == 3
    # 보고한 적 없는 과제가 앞, 방금 보고한 과제가 뒤.
    assert items[0]["never_reported"] is True
    assert items[-1]["id"] == fresh["id"]


def test_candidates_exclude_finished_projects(client):
    make_project(client, title="완료된 과제", status="done")
    make_project(client, title="진행중 과제")
    titles = [item["title"] for item in client.get("/api/report-candidates").json()["items"]]
    assert titles == ["진행중 과제"]

    with_all = client.get("/api/report-candidates", params={"include_inactive": True}).json()
    assert len(with_all["items"]) == 2


def test_report_attachment_link_is_relative_to_the_report_folder(client, vault_dir):
    project = make_project(client)
    report = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    saved = client.post(
        f"/api/reports/{report['id']}/attachments",
        files={"file": ("주간보고.xlsx", b"PK\x03\x04", "application/octet-stream")},
    ).json()

    assert saved["rel_path"] == "reports/2026-09-08/assets/001-주간보고.xlsx"
    assert saved["markdown"] == "[주간보고.xlsx](assets/001-주간보고.xlsx)"
    assert (vault_dir / "projects" / f"{project['id']}-리튬전지-수명평가" / saved["rel_path"]).exists()

    # 보고 문서만 봐도 어떤 자료로 보고했는지 알 수 있어야 한다.
    report_md = (
        vault_dir / "projects" / f"{project['id']}-리튬전지-수명평가"
        / "reports" / "2026-09-08" / "report.md"
    ).read_text(encoding="utf-8")
    assert "- reports/2026-09-08/assets/001-주간보고.xlsx" in report_md


def test_default_report_date_is_a_tuesday():
    from app.services.reports import default_report_date

    for day in range(1, 29):
        result = date.fromisoformat(default_report_date(date(2026, 9, day)))
        assert result.weekday() == 1  # 화요일
        assert result >= date(2026, 9, day)


def test_a_long_neglected_project_is_not_pushed_down_by_having_no_backlog(client):
    """예전에는 '진행이 없으면' 계수 0.25 를 먹어 오래 방치된 과제가 아래로 갔다.

    사용자가 정한 규칙은 "오래된 것이 먼저"이고, 거기에 예외는 없다 (TODO 52).
    """
    ancient = make_project(client, title="아주 오래됐지만 진행 없는 과제", start_date="2015-01-01")
    active = make_project(client, title="최근 진행이 쌓인 과제", start_date="2026-08-25")
    for day in ("2026-08-26", "2026-08-27", "2026-08-28", "2026-08-31"):
        add_entry(client, active["id"], day, f"{day} 기록")

    items = client.get("/api/report-candidates").json()["items"]
    assert [item["id"] for item in items] == [ancient["id"], active["id"]]


def test_elapsed_time_is_no_longer_capped(client):
    """10년 방치와 1년 방치가 같은 값이 되던 상한(주기×8=56일)을 없앴다.

    이 상한 때문에 D+100 과 D+150 의 순서가 뒤집히던 것이 TODO 52 의 발단이다.
    """
    old_one = make_project(client, title="1년 전 과제", start_date="2025-09-01")
    older = make_project(client, title="10년 전 과제", start_date="2015-09-01")
    for project in (old_one, older):
        add_entry(client, project["id"], "2026-08-30", "기록")

    items = client.get("/api/report-candidates").json()["items"]
    assert [item["id"] for item in items] == [older["id"], old_one["id"]]


def test_a_project_that_has_not_started_says_so_instead_of_a_negative_day_count(client):
    """착수일이 미래면 경과일이 음수가 되어 화면에 `D+-27` 로 찍히던 문제 (TODO 70).

    숫자를 고치는 대신 **아직 시작 안 했다**는 사실을 따로 알려 준다.
    화면은 그 자리에 "착수 전" 이라고 적는다.
    """
    later = (date.today() + timedelta(days=30)).isoformat()
    coming = make_project(client, title="아직 시작 안 한 과제", status="planned", start_date=later)

    items = client.get("/api/report-candidates").json()["items"]
    row = next(item for item in items if item["id"] == coming["id"])
    assert row["not_started"] is True
    assert row["days_since_report"] < 0  # 원래 값은 그대로 둔다 — 화면이 말로 바꾼다


def test_a_project_that_has_not_started_goes_to_the_bottom(client):
    """시작도 안 한 과제가 '가장 오래 방치된 과제' 자리를 차지하면 목록의 뜻이 흐려진다.

    둘 다 보고 이력이 없지만, 착수 전 과제는 이미 진행 중인 과제보다 뒤에 서야 한다.
    """
    later = (date.today() + timedelta(days=30)).isoformat()
    coming = make_project(client, title="다음 달 착수", status="planned", start_date=later)
    running = make_project(client, title="진행 중", start_date="2026-01-02")

    items = client.get("/api/report-candidates").json()["items"]
    order = [item["id"] for item in items]
    assert order.index(running["id"]) < order.index(coming["id"])


# ── 보고일 바꾸기 ─────────────────────────────────────

def _project(client, title="보고일 과제"):
    return client.post("/api/projects", json={"title": title}).json()


def test_draft_uses_the_given_date_not_only_the_default(client):
    """초안을 만들 때 날짜를 직접 정할 수 있어야 한다.

    기본값(다음 화요일)만 쓸 수 있으면 지난 보고를 뒤늦게 기록할 수 없다.
    """
    project = _project(client)
    draft = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-08-11"}
    ).json()
    assert draft["report_date"] == "2026-08-11"


def test_changing_the_date_moves_the_folder(client, vault_dir):
    """보고 문서는 reports/<보고일>/ 에 있다. 날짜만 고치면 폴더와 내용이 어긋난다."""
    project = _project(client, "폴더 이동")
    draft = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    directory = vault_dir / "projects" / f"{project['id']}-폴더-이동" / "reports"
    assert (directory / "2026-09-08" / "report.md").exists()

    updated = client.patch(f"/api/reports/{draft['id']}", json={"report_date": "2026-09-15"}).json()
    assert updated["report_date"] == "2026-09-15"
    assert (directory / "2026-09-15" / "report.md").exists()
    assert not (directory / "2026-09-08").exists()
    # 기본 제목이었다면 날짜를 따라간다.
    assert updated["title"] == "2026-09-15 보고"


def test_changing_the_date_carries_attachments_along(client, vault_dir):
    project = _project(client, "첨부 이동")
    draft = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.post(
        f"/api/reports/{draft['id']}/attachments",
        files={"file": ("보고자료.xlsx", b"x", "application/vnd.ms-excel")},
    )
    client.patch(f"/api/reports/{draft['id']}", json={"report_date": "2026-09-15"})

    directory = vault_dir / "projects" / f"{project['id']}-첨부-이동" / "reports"
    assert (directory / "2026-09-15" / "assets" / "001-보고자료.xlsx").exists()
    names = [a["orig_name"] for a in client.get(f"/api/reports/{draft['id']}/attachments").json()]
    assert names == ["보고자료.xlsx"]


def test_a_title_the_user_wrote_is_left_alone(client):
    project = _project(client, "제목 유지")
    draft = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.patch(f"/api/reports/{draft['id']}", json={"title": "전사 주요업무 보고"})
    updated = client.patch(f"/api/reports/{draft['id']}", json={"report_date": "2026-09-15"}).json()
    assert updated["title"] == "전사 주요업무 보고"


def test_frozen_report_keeps_its_date(client):
    """확정된 보고의 날짜는 '언제 보고했는가'라는 사실이다. 풀어야 고칠 수 있다."""
    project = _project(client, "확정 날짜")
    draft = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()
    client.post(f"/api/reports/{draft['id']}/freeze")

    response = client.patch(f"/api/reports/{draft['id']}", json={"report_date": "2026-09-15"})
    assert response.status_code == 409

    client.post(f"/api/reports/{draft['id']}/unfreeze")
    assert (
        client.patch(f"/api/reports/{draft['id']}", json={"report_date": "2026-09-15"}).json()[
            "report_date"
        ]
        == "2026-09-15"
    )


def test_invalid_date_is_rejected(client):
    project = _project(client, "잘못된 날짜")
    draft = client.post(f"/api/projects/{project['id']}/reports/draft", json={}).json()
    for bad in ("2026-13-45", "../../탈출", "그냥글자"):
        assert client.patch(f"/api/reports/{draft['id']}", json={"report_date": bad}).status_code == 400


def test_moving_onto_an_existing_date_does_not_overwrite(client, vault_dir):
    """같은 날짜에 이미 보고가 있으면 덮어쓰지 않고 옆에 놓는다."""
    project = _project(client, "같은 날 이동")
    first = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-15"}
    ).json()
    second = client.post(
        f"/api/projects/{project['id']}/reports/draft", json={"report_date": "2026-09-08"}
    ).json()

    client.patch(f"/api/reports/{second['id']}", json={"report_date": "2026-09-15"})
    reports = client.get(f"/api/projects/{project['id']}/reports").json()
    assert len(reports) == 2
    assert all(r["report_date"] == "2026-09-15" for r in reports)
    directory = vault_dir / "projects" / f"{project['id']}-같은-날-이동" / "reports"
    assert (directory / "2026-09-15").exists() and (directory / "2026-09-15-2").exists()
    assert client.get(f"/api/reports/{first['id']}").status_code == 200
