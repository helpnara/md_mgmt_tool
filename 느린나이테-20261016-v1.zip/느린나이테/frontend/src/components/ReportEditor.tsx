import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../api";
import { attempt } from "../notify";
import { clockNow, discardQuestion, dropDraft, loadDraft, useDraftKeeper, useEditLedger, useUnsaved } from "../unsaved";
import { filesBase, renderMarkdown } from "../markdown";
import { copyAsExcelCell, copyAsPlainText, toPlainText } from "../plaintext";
import { COPY_FAILED } from "../clipboard";
import { isReadonly } from "../readonly";
import type { Report } from "../types";
import type { Attachment } from "../upload";
import { formatBytes, formatRate, uploadAttachment } from "../upload";
import PasteOfferBar from "./PasteOffer";
import { type PasteOffer, handleEditorPaste, spliceAtCaret } from "../table";
import { scrollEditorIntoView } from "../util";
import AttachmentList from "./AttachmentList";
import XlsxPreview from "./XlsxPreview";
import PreviewToggle, { usePreview } from "./PreviewToggle";
import AiPromptPanel from "./AiPromptPanel";
import ReportDiff from "./ReportDiff";
import VersionPanel from "./VersionPanel";

interface UploadState {
  key: string;
  name: string;
  loaded: number;
  total: number;
  startedAt: number;
  abort: () => void;
  error?: string;
}

interface Props {
  report: Report;
  dirName?: string;
  /** 피보고자 자동완성 목록 */
  audiences: string[];
  onChanged: () => void;
  onClose: () => void;
  /** 지워졌을 때. onChanged 와 나눠 둔 이유는 아래 [삭제] 주석 참고. */
  onDeleted: () => void;
  /** 이 문서의 vault 기준 경로. 있으면 [이전 버전]을 열 수 있다 (TODO 37-1). */
  docPath?: string;
  /**
   * 바깥(과제 상세의 보고 목록)이 이 편집기를 닫기 전에 물어볼 길 (TODO 211 ④ · 213 ⑥) — 다른 보고를 누르거나
   * 새 초안을 만들 때. 받은 함수는 [닫기] 와 같이 묻고(버리면 이번에 올린 첨부를 지우고) 닫아도 되는지 돌려준다.
   */
  registerCloseGuard?: (guard: (() => Promise<boolean>) | null) => void;
}

export default function ReportEditor({ report, dirName, audiences, onChanged, onClose, onDeleted, docPath, registerCloseGuard }: Props) {
  const [showVersions, setShowVersions] = useState(false);
  const [body, setBody] = useState(report.body ?? "");
  const [audience, setAudience] = useState(report.audience ?? "");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploads, setUploads] = useState<UploadState[]>([]);
  const [previewing, setPreviewing] = useState<Attachment | null>(null);
  // 보고일. 초안일 때만 고칠 수 있다 — 확정된 보고의 날짜는 "언제 보고했는가"라는 사실이다.
  const [reportDate, setReportDate] = useState(report.report_date);
  // 보고 자리에서 받은 지시 (TODO 107). 확정된 보고에만 적고, 본문과 따로 저장한다.
  const [feedback, setFeedback] = useState(report.feedback ?? "");
  const [feedbackDirty, setFeedbackDirty] = useState(false);
  const [preview, togglePreview] = usePreview();
  // "지난주와 뭐가 달라졌나" — 보고 자리에서 가장 많이 받는 질문이다.
  const [showDiff, setShowDiff] = useState(false);
  // AI 에게 넘길 글. 곧바로 복사하지 않고 **먼저 보여 준다** (TODO 71).
  const [showPrompt, setShowPrompt] = useState(false);
  const [dirty, setDirty] = useState(false);
  // 편집 한 번의 장부 (TODO 213 ⑥) — 이번에 올린 보고 자료 · 지우기로 한 보고 자료(첨부 번호)
  const ledger = useEditLedger<number>();
  // 이 편집에서 마지막으로 저장한 때 — 버릴 때 "마지막 저장 이후" 로 묻는다
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [pasteOffer, setPasteOffer] = useState<PasteOffer | null>(null);
  const closeOffer = useCallback(() => setPasteOffer(null), []);

  // 보고 문서를 열면 좌측 칸이 맨 위로 올라온다. 문서가 있는 자리로 데려간다.
  useEffect(() => scrollEditorIntoView(rootRef.current), []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const base = filesBase(dirName, report.doc_dir);
  const frozen = report.frozen;
  // 읽기 전용 공유 (TODO 208) — 초안이라도 확정본처럼 **스냅숏**으로 보인다. 고치는 칸 · 저장 · 확정 해제 · 지시사항이 없고
  // Ctrl+S 도 아무 일도 하지 않는다. 복사 단추는 남는다 — 공유의 쓸모가 그것이다.
  const readonly = isReadonly();
  const editable = !frozen && !readonly;

  const refresh = useCallback(() => {
    api.listReportAttachments(report.id).then(setAttachments).catch(() => undefined);
  }, [report.id]);

  useEffect(refresh, [refresh]);
  // 서버 본문으로 맞추기 (TODO 211 ⑤) — 전에는 저장 뒤 다시 읽은 본문이 오면 무조건 덮어써,
  // Ctrl+S 직후 계속 친 글자가 왕복 사이에 조용히 사라졌다. 이제는 **다른 보고로 바뀌었거나, 고친 것이 없을 때**만 맞춘다.
  // [이전 버전] 으로 되돌린 때는 되돌린 글이 보여야 하므로 forceSync 로 덮어쓴다.
  const dirtyRef = useRef(dirty);
  dirtyRef.current = dirty;
  const bodyRef = useRef(body);
  bodyRef.current = body;
  const forceSync = useRef(false);
  const shownId = useRef(report.id);
  useEffect(() => {
    const switched = shownId.current !== report.id;
    shownId.current = report.id;
    if (switched || forceSync.current || !dirtyRef.current) {
      forceSync.current = false;
      setBody(report.body ?? "");
      if (switched) setDirty(false);
    }
  }, [report.id, report.body]);
  // 쓰던 보고 — 떠날 때 묻고, 임시 보관한다 (TODO 162). 확정된 보고는 본문을 고칠 수 없으니 빼고.
  const draftKey = `report:${report.id}`;
  const [restored, setRestored] = useState(false);
  // 지시사항 칸은 **확정된 보고에만** 있다 — 떠남 경고를 `!frozen` 에 묶어 두니 절대 안 떴다 (TODO 207).
  // 읽기 전용 공유에서는 고칠 칸이 없으니 묻지 않는다 (208).
  // 올린 · 지우기로 한 보고 자료가 있어도 묻는다 — 떠날 때는 지우지 않는다(임시 보관이 그 첨부를 가리킨다, TODO 213)
  useUnsaved(draftKey, !readonly && (frozen ? feedbackDirty : dirty || !ledger.empty));
  useDraftKeeper(editable ? draftKey : null, body, body === (report.body ?? ""));
  useEffect(() => {
    if (!editable) return;
    let alive = true;
    const original = report.body ?? "";
    void loadDraft<string>(draftKey, (content) => content === original).then((kept) => {
      if (!alive || typeof kept !== "string") return;
      setBody(kept);
      setDirty(true);
      setRestored(true);
    });
    return () => {
      alive = false;
    };
    // 문서를 바꿔 열 때만 — 저장해서 본문이 바뀐 것은 되살릴 일이 아니다
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [report.id]);
  // 지시사항도 임시 보관한다 (TODO 207) — 회의 직후 받은 지시를 적다 다른 보고를 눌러도 남는다.
  // 서버가 받는 열쇠 모양은 `report:<번호>` 뿐이고, 확정된 보고에서는 본문 보관이 꺼져 있어 그 열쇠가 비어 있다.
  // 본문(글 하나)과 섞이지 않게 `{ feedback }` 묶음으로 둔다 — 확정을 풀어 본문 보관이 되살아나도 글이 아니면 무시한다.
  const [feedbackRestored, setFeedbackRestored] = useState(false);
  const feedbackOriginal = report.feedback ?? "";
  useDraftKeeper(frozen && !readonly ? draftKey : null, { feedback }, feedback === feedbackOriginal);
  useEffect(() => {
    if (!frozen || readonly) return;
    let alive = true;
    const original = report.feedback ?? "";
    void loadDraft<{ feedback?: unknown }>(
      draftKey,
      (content) => typeof content !== "object" || content === null || content.feedback === original,
    ).then((kept) => {
      if (!alive || !kept || typeof kept.feedback !== "string") return;
      setFeedback(kept.feedback);
      setFeedbackDirty(true);
      setFeedbackRestored(true);
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [report.id]);
  useEffect(() => setAudience(report.audience ?? ""), [report.id, report.audience]);
  useEffect(() => setReportDate(report.report_date), [report.id, report.report_date]);
  useEffect(() => {
    setFeedback(report.feedback ?? "");
    setFeedbackDirty(false);
  }, [report.id, report.feedback]);

  async function save(): Promise<void> {
    // 보낸 글을 잡아 둔다 — 왕복 사이에 더 쳤으면 "저장 안 됨" 이 그대로 남아야 한다 (TODO 211 ⑤)
    const sent = bodyRef.current;
    // 보고일은 초안일 때만 보낸다. 바뀌면 서버가 문서 폴더도 함께 옮긴다.
    await api.updateReport(report.id, {
      body: sent,
      audience,
      ...(frozen ? {} : { report_date: reportDate }),
    });
    if (bodyRef.current === sent) setDirty(false);
    // 지우기로 한 보고 자료는 저장할 때 지운다. 이번에 올린 것은 이제 저장된 것이다 (TODO 213 ③)
    await ledger.commit((id) => api.deleteAttachment(id));
    setLastSavedAt(clockNow());
    refresh();
    onChanged();
  }

  // [저장] 이 요청 중이면 다시 누르지 못한다 — 두 번 누르면 PATCH 두 번 (TODO 209 ④)
  const saving = useRef(false);
  async function runSave(): Promise<void> {
    if (saving.current) return;
    saving.current = true;
    setBusy(true);
    try {
      await save();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      saving.current = false;
      setBusy(false);
    }
  }

  /**
   * 닫아도 되나 — [닫기] · 다른 보고 열기 · 새 초안 (TODO 211 ④ · 213 ⑥). 진행일지 편집기와 같은 규칙:
   * 고친 것이나 이 편집에서 먼저 서버에 쓴 것(첨부)이 있으면 사실대로 묻고, 버리면 이번에 올린 첨부를 지운다.
   * 지우기로 한 첨부는 그대로 둔다. 메뉴 이동으로 떠날 때는 묻기만 하고 지우지 않는다(임시 보관이 남는다).
   */
  async function confirmClose(): Promise<boolean> {
    if (readonly) return true;
    if (frozen) {
      if (feedbackDirty && !window.confirm(discardQuestion({ what: "지시사항을" }))) return false;
      if (feedbackDirty) dropDraft(draftKey);
      return true;
    }
    if (!dirty && ledger.empty) return true;
    if (
      !window.confirm(
        discardQuestion({
          what: "보고를",
          savedAt: lastSavedAt,
          uploaded: ledger.uploaded.length,
          doomed: ledger.doomedExisting.length,
        }),
      )
    )
      return false;
    for (const upload of uploads) if (!upload.error) upload.abort();
    await ledger.rollback((id) => api.deleteAttachment(id));
    dropDraft(draftKey);
    return true;
  }
  const confirmCloseRef = useRef(confirmClose);
  confirmCloseRef.current = confirmClose;
  useEffect(() => {
    if (!registerCloseGuard) return;
    registerCloseGuard(() => confirmCloseRef.current());
    return () => registerCloseGuard(null);
  }, [registerCloseGuard]);

  /** 초안에 딸려 온 "진행 내용"만 지우고 보고서 뼈대는 남긴다. */
  function clearProgressSection() {
    if (!window.confirm("초안에 붙어 온 '진행 내용'을 지울까요? 요약·특이사항·다음 계획은 남습니다.")) {
      return;
    }
    setBody((prev) => {
      const start = prev.indexOf("## 진행 내용");
      if (start < 0) return prev;
      const rest = prev.slice(start + 1);
      const nextHeading = rest.indexOf("\n## ");
      return nextHeading < 0 ? prev.slice(0, start).trimEnd() + "\n" : prev.slice(0, start) + rest.slice(nextHeading + 1);
    });
    setDirty(true);
  }

  function insertAtCursor(snippet: string) {
    const textarea = textareaRef.current;
    const start = textarea ? textarea.selectionStart : body.length;
    setBody((prev) => `${prev.slice(0, start)}\n${snippet}\n${prev.slice(start)}`);
    setDirty(true);
  }

  async function handleFiles(files: File[]) {
    for (const file of files) {
      const key = `${file.name}-${Date.now()}`;
      const handle = uploadAttachment(`/api/reports/${report.id}/attachments`, file, (loaded, total) =>
        setUploads((prev) => prev.map((item) => (item.key === key ? { ...item, loaded, total } : item))),
      );
      setUploads((prev) => [
        ...prev,
        { key, name: file.name, loaded: 0, total: file.size, startedAt: Date.now(), abort: handle.abort },
      ]);
      try {
        const saved = await handle.promise;
        // 이번 편집에서 올린 것 — 버리면 지운다(같은 파일을 돌려받은 것은 남의 것이라 빼고) (TODO 213 ⑥)
        if (!saved.deduplicated) ledger.addUploaded(saved.id);
        setUploads((prev) => prev.filter((item) => item.key !== key));
        refresh();
      } catch (err) {
        setUploads((prev) =>
          prev.map((item) => (item.key === key ? { ...item, error: (err as Error).message } : item)),
        );
      }
    }
  }

  async function copy(kind: "excel" | "plain") {
    const text = toPlainText(body);
    // 공유 주소(비보안 컨텍스트)에서는 clipboard API 가 없다 — 폴백으로 넣고, 안 되면 한국어로 안내 (TODO 208)
    const ok = kind === "excel" ? await copyAsExcelCell(text) : await copyAsPlainText(text);
    if (!ok) {
      setError(COPY_FAILED);
      return;
    }
    setError(null);
    setNotice(kind === "excel" ? "엑셀 한 칸에 붙여넣을 수 있게 복사했습니다." : "평문으로 복사했습니다.");
    window.setTimeout(() => setNotice(null), 4000);
  }

  return (
    <div
      ref={rootRef}
      className={`report-editor card${frozen ? " frozen" : ""}${readonly ? " readonly-snapshot" : ""}`}
      onKeyDown={(event) => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
          event.preventDefault();
          if (editable) void runSave(); // 읽기 전용이면 아무 일도 (208)
        }
      }}
      onDragOver={editable ? (event) => event.preventDefault() : undefined}
      onDrop={
        !editable
          ? undefined
          : (event) => {
              event.preventDefault();
              void handleFiles(Array.from(event.dataTransfer.files));
            }
      }
    >
      <div className="card-head">
        <h2>
          {report.report_date} 보고
          {frozen ? (
            <span className="frozen-tag">확정됨 · 읽기 전용</span>
          ) : (
            <span className="draft-tag">작성 중</span>
          )}
          {readonly && !frozen && <span className="frozen-tag">읽기 전용 공유 — 서버 PC 에서 고칩니다</span>}
        </h2>
        <div className="form-actions" style={{ margin: 0 }}>
          {editable && body.includes("## 진행 내용") && (
            <button data-write className="ghost" onClick={clearProgressSection}>
              진행 내용 지우기
            </button>
          )}
          <button
            className={showDiff ? "ghost on" : "ghost"}
            onClick={() => setShowDiff((prev) => !prev)}
            title="직전에 확정한 보고와 비교합니다."
          >
            지난 보고 대비
          </button>
          {/* 프롬프트는 **저장된 본문**으로 만든다(서버가 만든다). 고치던 중이면 먼저 저장해
              화면에 보이는 글과 복사되는 글이 어긋나지 않게 한다. [지난 보고 대비]와 같은 방식이다. */}
          <button
            className={showPrompt ? "ghost on" : "ghost"}
            title="AI 에게 넘길 글을 만들어 보여 줍니다. 이 도구가 AI 를 부르지는 않습니다."
            onClick={async () => {
              if (showPrompt) {
                setShowPrompt(false);
                return;
              }
              if (dirty && editable) {
                try {
                  await save();
                } catch (err) {
                  setError((err as Error).message);
                  return;
                }
              }
              setShowPrompt(true);
            }}
          >
            AI 요약 프롬프트
          </button>
          <button className="ghost" onClick={() => copy("excel")}>
            엑셀 셀로 복사
          </button>
          <button className="ghost" onClick={() => copy("plain")}>
            평문 복사
          </button>
          {docPath && (
            <button data-write
              className={showVersions ? "ghost on" : "ghost"}
              onClick={() => setShowVersions((prev) => !prev)}
              title="이 보고 문서의 이전 내용으로 되돌립니다."
            >
              이전 버전
            </button>
          )}
          <button
            className="ghost"
            onClick={async () => {
              // 고친 것이 있으면 묻는다 — 진행일지와 같은 규칙 (TODO 211 ④ · 213 ⑥)
              if (await confirmClose()) onClose();
            }}
          >
            닫기
          </button>
        </div>
      </div>

      <div className="report-meta">
        <label className="report-date-field">
          보고일
          <input
            type="date"
            value={reportDate}
            disabled={!editable}
            title={frozen ? "확정된 보고의 날짜는 바꿀 수 없습니다. 확정을 풀면 고칠 수 있습니다." : undefined}
            onChange={(event) => {
              setReportDate(event.target.value);
              setDirty(true);
            }}
          />
        </label>
        <label>
          피보고자 · 회의체
          {readonly ? (
            // 읽기 전용 공유 — 고칠 수 없는 칸은 글자로 (TODO 208)
            <span className="audience-text">{audience || "—"}</span>
          ) : (
            <>
              <input
                list="audience-options"
                value={audience}
                onChange={(event) => {
                  setAudience(event.target.value);
                  setDirty(true);
                }}
                placeholder="예: 팀장, 주간회의체"
              />
              <datalist id="audience-options">
                {audiences.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            </>
          )}
        </label>
        {frozen && !readonly && (
          <button
            className="ghost small"
            disabled={audience === (report.audience ?? "")}
            onClick={async () => {
              if (!(await attempt(() => api.updateReport(report.id, { audience })))) return;
              setDirty(false);
              onChanged();
            }}
          >
            피보고자만 저장
          </button>
        )}
        {/* 자동완성 목록은 칸을 눌러야 뜨고 브라우저마다 모양이 달라, 있는 줄 모르고
            매번 손으로 치게 된다. 쓰던 것을 눌러서 넣게 한다 (진행일지 태그와 같은 방식). */}
        {editable && audiences.length > 0 && (
          <div className="tag-suggest audience-suggest">
            <span className="muted">쓰던 피보고자</span>
            {audiences
              .filter((name) => name !== audience)
              .slice(0, 8)
              .map((name) => (
                <button
                  key={name}
                  type="button"
                  className="tag-pick"
                  onClick={() => {
                    setAudience(name);
                    setDirty(true);
                  }}
                >
                  {name}
                </button>
              ))}
          </div>
        )}

        <span className="hint">
          {report.covers_from
            ? `포함 기간 ${report.covers_from} ~ ${report.covers_to} · 진행일지 ${report.entry_count}건`
            : "포함된 진행일지가 없습니다."}
          {report.author && ` · 작성 ${report.author}`}
        </span>
      </div>

      {docPath && showVersions && (
        <VersionPanel
          path={docPath}
          onRestored={() => {
            // 되돌린 글이 보여야 한다 — 고치던 중이어도 덮어쓴다 (211 ⑤ 의 예외)
            forceSync.current = true;
            onChanged();
          }}
        />
      )}

      {showDiff && <ReportDiff reportId={report.id} />}

      {showPrompt && <AiPromptPanel reportId={report.id} />}

      {frozen || readonly ? (
        <>
          <div className="markdown snapshot" dangerouslySetInnerHTML={{ __html: renderMarkdown(body, base) }} />
          {/* 보고 결과 · 지시사항 (TODO 107). 본문은 굳었지만 "그 자리에서 무슨 말을 들었는가"는
              보고가 끝난 뒤에야 적을 수 있다. 다음 초안이 이 칸을 맨 위에 물고 나온다.
              읽기 전용 공유에서는 적힌 것만 보인다 — 칸도 단추도 없다 (TODO 208). */}
          {frozen && readonly && (
            <section className="feedback-box" data-testid="report-feedback">
              <div className="feedback-head">
                <b>보고 결과 · 지시사항</b>
                {report.feedback?.trim() ? (
                  report.feedback_done ? (
                    <span className="feedback-state done">답변함 · {report.feedback_done}</span>
                  ) : (
                    <span className="feedback-state open">답하지 않음</span>
                  )
                ) : (
                  <span className="hint">적힌 지시사항이 없습니다.</span>
                )}
              </div>
              {report.feedback?.trim() && <p className="feedback-text snapshot-text">{report.feedback}</p>}
            </section>
          )}
          {frozen && !readonly && (
          <section className="feedback-box" data-testid="report-feedback">
            <div className="feedback-head">
              <b>보고 결과 · 지시사항</b>
              {report.feedback?.trim() ? (
                report.feedback_done ? (
                  <span className="feedback-state done">답변함 · {report.feedback_done}</span>
                ) : (
                  <span className="feedback-state open">답하지 않음 — 다음 초안 맨 위에 딸려 갑니다</span>
                )
              ) : (
                <span className="hint">비워 두면 아무 데도 나타나지 않습니다.</span>
              )}
            </div>
            <textarea
              className="feedback-text"
              rows={3}
              value={feedback}
              placeholder="보고 자리에서 받은 지시·질문·결정 사항"
              onChange={(event) => {
                setFeedback(event.target.value);
                setFeedbackDirty(true);
              }}
              onPaste={(event) => {
                // 지시가 엑셀 표로 오기도 한다 — 표만 받는다(첨부는 보고 자료 칸의 일) (TODO 137)
                const area = event.currentTarget;
                handleEditorPaste(event, {
                  onInsert: (text) => {
                    setFeedback((prev) => spliceAtCaret(area, prev, text));
                    setFeedbackDirty(true);
                  },
                });
              }}
            />
            <div className="form-actions feedback-actions">
              <button
                className="small"
                disabled={!feedbackDirty || busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    await api.updateReport(report.id, { feedback });
                    setFeedbackDirty(false);
                    dropDraft(draftKey); // 저장했으니 임시 보관은 지운다 (207)
                    setFeedbackRestored(false);
                    onChanged();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                지시사항 저장
              </button>
              {report.feedback?.trim() && (
                <button
                  className="ghost small"
                  disabled={busy || feedbackDirty}
                  title={feedbackDirty ? "먼저 지시사항을 저장하세요." : undefined}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await api.feedbackDone(report.id, !report.feedback_done);
                      onChanged();
                    } catch (err) {
                      setError((err as Error).message);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  {report.feedback_done ? "아직 답하지 않음으로" : "답변함"}
                </button>
              )}
            </div>
            {feedbackRestored && feedbackDirty && (
              <p className="hint restored">
                저장하지 않은 지시사항을 복구했습니다.{" "}
                <button
                  className="ghost small"
                  onClick={() => {
                    dropDraft(draftKey);
                    setFeedback(report.feedback ?? "");
                    setFeedbackDirty(false);
                    setFeedbackRestored(false);
                  }}
                >
                  복구한 내용 버리기
                </button>
              </p>
            )}
          </section>
          )}
        </>
      ) : (
        <>
        <PreviewToggle on={preview} onToggle={togglePreview} />
        <div className={preview ? "split" : "split solo"}>
          <textarea
            ref={textareaRef}
            value={body}
            onChange={(event) => {
              setBody(event.target.value);
              setDirty(true);
            }}
            onPaste={(event) =>
              // 보고 문서야말로 엑셀 표를 그대로 옮겨 오는 일이 잦다 — 표가 그림보다 먼저다 (TODO 137)
              handleEditorPaste(event, {
                onInsert: (text) => {
                  insertAtCursor(text);
                  setDirty(true);
                },
                onFiles: (files) => void handleFiles(files),
                onOffer: setPasteOffer,
              })
            }
            spellCheck={false}
          />
          {preview && (
            <div className="preview markdown" dangerouslySetInnerHTML={{ __html: renderMarkdown(body, base) }} />
          )}
        </div>
        </>
      )}

      <PasteOfferBar
        offer={pasteOffer}
        area={textareaRef.current}
        setValue={(next) => {
          setBody(next);
          setDirty(true);
        }}
        onFiles={(files) => void handleFiles(files)}
        onClose={closeOffer}
      />

      {uploads.length > 0 && (
        <ul className="uploads">
          {uploads.map((upload) => {
            const percent = upload.total ? Math.round((upload.loaded / upload.total) * 100) : 0;
            const elapsed = (Date.now() - upload.startedAt) / 1000;
            return (
              <li key={upload.key} className={upload.error ? "upload-error" : undefined}>
                <div className="upload-head">
                  <span className="upload-name">{upload.name}</span>
                  <span className="muted">
                    {upload.error
                      ? upload.error
                      : `${formatBytes(upload.loaded)} / ${formatBytes(upload.total)} · ${formatRate(
                          elapsed > 0 ? upload.loaded / elapsed : 0,
                        )}`}
                  </span>
                  {!upload.error && (
                    <button className="ghost small" onClick={upload.abort}>
                      취소
                    </button>
                  )}
                </div>
                <div className="progress">
                  <div className="progress-bar" style={{ width: `${percent}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <div className="attachment-panel">
        <div className="card-head">
          <h3>보고 자료 ({attachments.length})</h3>
          {editable && (
            <div className="attach-actions">
              <span className="hint">엑셀·이미지를 끌어다 놓아도 됩니다.</span>
              <button className="attach-button" onClick={() => fileInputRef.current?.click()}>
                📎 파일 첨부
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                hidden
                onChange={(event) => {
                  void handleFiles(Array.from(event.target.files ?? []));
                  event.target.value = "";
                }}
              />
            </div>
          )}
        </div>
        {/* 확정된 보고의 첨부는 지우지 않는다 — 그 문서는 "그때 무엇을 보고했는가" 다
            (본문·삭제를 막는 것과 같은 이유, TODO 103-F). 확정을 풀면 지울 수 있다. */}
        {/* 편집기 안의 [삭제] 는 "지울 예정" 으로만 — [저장] 할 때 지우고, 버리면 아무 일도 없다 (TODO 213 ③ ⑥) */}
        <AttachmentList
          attachments={attachments}
          onPreview={(attachment) => setPreviewing(attachment)}
          onInsert={editable ? (attachment) => insertAtCursor(attachment.markdown) : undefined}
          pending={editable ? (attachment) => ledger.isDoomed(attachment.id) : undefined}
          onRestore={editable ? (attachment) => ledger.toggleDoomed(attachment.id) : undefined}
          onDelete={
            !editable
              ? undefined
              : (attachment) => {
                  // 본문에서 쓰이는 중이면 그 사실을 말해 준다 (TODO 129). 막지는 않는다 — 급할 때 못 쓴다.
                  const stored = attachment.rel_path.split("/").pop() ?? "";
                  const used = stored !== "" && body.includes(stored);
                  if (
                    used &&
                    !window.confirm(
                      `${attachment.orig_name} 은(는) 본문에서 쓰이는 중입니다. 지우면 그 자리가 깨집니다.\n\n[저장] 할 때 지우도록 표시할까요?`,
                    )
                  )
                    return;
                  ledger.toggleDoomed(attachment.id);
                }
          }
        />
        {editable && ledger.doomed.length > 0 && (
          <p className="hint pending-note">지울 예정인 보고 자료 {ledger.doomed.length}건은 [저장] 할 때 삭제 보관함으로 옮깁니다.</p>
        )}
      </div>

      {restored && dirty && (
        <p className="hint restored">
          저장하지 않은 작성 중 내용을 복구했습니다.{" "}
          <button
            className="ghost small"
            onClick={() => {
              dropDraft(draftKey);
              setBody(report.body ?? "");
              setDirty(false);
              setRestored(false);
            }}
          >
            복구한 내용 버리기
          </button>
        </p>
      )}
      {notice && <p className="hint notice">{notice}</p>}
      {error && <p className="form-error">{error}</p>}

      {/* 읽기 전용 공유에는 저장 · 확정 · 확정 해제가 없다 — 눌러 봐야 403 이다 (TODO 208) */}
      {!readonly && (
      <div className="editor-footer">
        <span className="muted save-state">
          {dirty || !ledger.empty ? "저장 안 됨" : lastSavedAt ? `${lastSavedAt} 저장됨` : ""}
        </span>
        <div className="form-actions">
          {frozen ? (
            <button
              className="ghost"
              onClick={async () => {
                if (!window.confirm("확정을 해제하면 문서를 다시 고칠 수 있습니다. 해제할까요?")) return;
                if (await attempt(() => api.unfreezeReport(report.id))) onChanged();
              }}
            >
              확정 해제
            </button>
          ) : (
            <>
              {/* 초안을 잘못 만들었을 때 만든 자리에서 바로 지운다. 지금까지는 편집기를 닫고
                  과제 상세의 보고 이력 목록까지 가야 했다. 확정된 보고에는 두지 않는다 —
                  그 문서는 "언제 무엇을 보고했는가"라는 기록이라, 확정을 먼저 풀어야 한다. */}
              <button
                className="ghost danger"
                disabled={busy}
                onClick={async () => {
                  if (!window.confirm("이 보고 초안을 삭제 보관함으로 옮길까요?\n\n설정 → 삭제 보관함에서 되돌릴 수 있습니다."))
                    return;
                  setBusy(true);
                  try {
                    await api.deleteReport(report.id);
                    // onChanged 를 쓰면 안 된다 — 그쪽은 "바뀌었으니 이 보고를 다시 읽어라"
                    // 라는 뜻이라, 방금 지운 문서를 다시 불러 404 가 난다.
                    onDeleted();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                삭제
              </button>
              <button data-write className="ghost" disabled={busy || (!dirty && ledger.empty)} onClick={() => void runSave()}>
                {busy ? "저장 중…" : "저장"}
              </button>
              <button
                className="commit"
                disabled={busy}
                onClick={async () => {
                  if (!window.confirm("보고를 확정하면 이 문서는 읽기 전용이 되고, 미보고 분량이 초기화됩니다.")) return;
                  setBusy(true);
                  try {
                    if (dirty || !ledger.empty) await save();
                    await api.freezeReport(report.id);
                    onChanged();
                  } catch (err) {
                    setError((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                보고 확정
              </button>
            </>
          )}
        </div>
      </div>
      )}

      {previewing && <XlsxPreview attachment={previewing} onClose={() => setPreviewing(null)} />}
    </div>
  );
}
