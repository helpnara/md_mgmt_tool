import { useEffect, useState } from "react";
import { api } from "../api";
import type { ClassificationInfo, ClassificationKey, Meta, Partner, Project } from "../types";
import TagSuggestions from "./TagSuggestions";
import UnknownOwners from "./UnknownOwners";
import { useFormUnsaved } from "../unsaved";
import { confirmDiscard, dateOrderProblem } from "../util";

interface Props {
  meta: Meta;
  /** 명부에 사람을 새로 넣었을 때 상단 meta 를 다시 읽는다 */
  onMetaChange?: () => void;
  initial?: Partial<Project>;
  submitLabel: string;
  onSubmit: (payload: Partial<Project>) => Promise<void>;
  onCancel: () => void;
}

export default function ProjectForm({ meta, initial, submitLabel, onSubmit, onCancel, onMetaChange = () => undefined }: Props) {
  // 자동완성은 명부를 먼저 보여 주고, 명부에 없지만 이미 쓰이는 이름을 뒤에 붙인다.
  // 떠난 사람은 고르는 자리에서 뺀다 (TODO 122) — 새 과제에 실수로 들어가는 것을 막는다.
  // 이미 그 사람이 담당인 과제를 고칠 때는 값이 그대로 있으므로 사라지지 않는다.
  const left = new Set((meta.people_left ?? []).map((person) => person.name));
  const ownerOptions = [
    ...meta.people.filter((name) => !left.has(name)),
    ...meta.owners.filter((name) => !meta.people.includes(name) && !left.has(name)),
  ];
  // 선행 과제 고르기 (TODO 172) — 번호와 이름을 함께 보여 고른다. 자기 자신은 뺀다.
  // 폼을 열 때마다 전체 과제를 받지 않는다 — 창마다 한 번 받은 번호 · 제목을 쓴다 (TODO 212, api.projectOptions)
  const [projectOptions, setProjectOptions] = useState<{ id: string; title: string }[]>([]);
  useEffect(() => {
    let alive = true;
    api
      .projectOptions()
      .then((rows) => alive && setProjectOptions(rows.filter((row) => row.id !== initial?.id)))
      .catch(() => alive && setProjectOptions([]));
    return () => {
      alive = false;
    };
  }, [initial?.id]);
  // 선행 과제 — 여럿일 수 있다(앞 단계 과제 둘을 이어받는 과제). 칩으로 넣고 뺀다 (TODO 172)
  const [predecessors, setPredecessors] = useState<string[]>(initial?.predecessors ?? []);
  const [predecessorInput, setPredecessorInput] = useState("");
  const addPredecessor = (raw: string) => {
    const id = raw.trim().split(/\s+/)[0];
    if (!id) return;
    setPredecessors((prev) => (prev.includes(id) ? prev : [...prev, id]));
    setPredecessorInput("");
  };
  const [form, setForm] = useState({
    title: initial?.title ?? "",
    status: initial?.status ?? "in_progress",
    type: initial?.type ?? "",
    group: initial?.group ?? "",
    owners: (initial?.owners ?? []).join(", "),
    start_date: initial?.start_date ?? "",
    due_date: initial?.due_date ?? "",
    completed_at: initial?.completed_at ?? "",
    effect_expected: initial?.effect_expected?.toString() ?? "",
    effect_verified: initial?.effect_verified?.toString() ?? "",
    tags: (initial?.tags ?? []).join(", "),
  });
  /**
   * 유관부서 (TODO 92). 한 줄이 팀 하나이고, 담당자는 그 줄 안에서 쉼표로 적는다.
   *
   * **팀과 사람을 한 칸에 섞어 적게 하지 않는다.** "설비기술팀 김철수" 처럼 한 칸에 두면
   * 어디까지가 팀이고 어디부터가 사람인지 아무도 모른다. 줄을 나누는 편이 입력은
   * 한 번 더지만, 그 뒤로 집계·검색·표시가 전부 흔들리지 않는다.
   */
  const [partners, setPartners] = useState<{ team: string; people: string }[]>(
    () => (initial?.partners ?? []).map((row) => ({ team: row.team, people: row.people.join(", ") })),
  );
  const setPartner = (index: number, key: "team" | "people", value: string) =>
    setPartners((prev) => prev.map((row, i) => (i === index ? { ...row, [key]: value } : row)));

  /**
   * 과제 분류 넷 (TODO 136) — 성격 · 분류 · 수행 방식 · 비용구분.
   * 입력 칸은 **분류를 쓰는 속성(스마트과제)일 때만** 선다. 속성을 바꿔 칸이 숨어도 값은 지우지
   * 않는다 — 실수로 속성을 잠깐 바꿨다가 되돌렸을 때 적어 둔 것이 사라지면 안 된다.
   */
  const [classes, setClasses] = useState<Record<ClassificationKey, string>>(() => ({
    nature: initial?.nature ?? "",
    category: initial?.category ?? "",
    delivery: initial?.delivery ?? "",
    cost_kind: initial?.cost_kind ?? "",
  }));

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * 저장하면 붙을 과제 번호 (TODO 95).
   *
   * 번호의 연도는 **등록한 날이 아니라 착수년도**다. 그 사실은 문장으로 적어 두는 것보다
   * **실제 번호를 미리 보여 주는 편**이 확실하다 — 지난해 과제를 등록하면서 시작일을
   * 비워 둔 채 저장하면 올해 번호가 붙는데, 저장 뒤에는 알아채기 어렵다.
   * 고칠 때는 띄우지 않는다 — 이미 붙은 번호는 이 폼이 바꾸지 않는다.
   */
  const creating = !initial?.id;
  const [nextId, setNextId] = useState<string | null>(null);
  useEffect(() => {
    if (!creating) return;
    let alive = true;
    api
      .nextProjectId(form.start_date)
      .then((row) => alive && setNextId(row.id))
      .catch(() => alive && setNextId(null));
    return () => {
      alive = false;
    };
  }, [creating, form.start_date]);

  const update = (key: string, value: string) => setForm((prev) => ({ ...prev, [key]: value }));

  // 비우면 null 로 보낸다 — "아직 안 정했다"와 "0원"은 다른 뜻이다.
  const effect = (value: string): number | null => (value.trim() === "" ? null : Number(value));
  // 단순 현황 관리를 과제로 세운 경우. 보고 대상 후보에서만 빠진다 (TODO 80).
  const [noReport, setNoReport] = useState(Boolean(initial?.no_report));
  // 금액으로 재지 않는 과제 (TODO 125). 유지보수·기획보고처럼 효과 금액을 적지 않는 일이
  // "완료했는데 실증효과 미입력" 에 계속 남으면, 줄지 않는 그 숫자를 곧 안 보게 된다.
  const [noEffect, setNoEffect] = useState(Boolean(initial?.no_effect));
  // 쓰다가 떠나면 묻는다 (TODO 162). 유관부서 · 분류 · 적다 만 선행 과제 칸까지 (TODO 211 ①)
  const snapshot = { form, noReport, noEffect, predecessors, predecessorInput, partners, classes };
  useFormUnsaved(`project-form:${initial?.id ?? "new"}`, snapshot, busy);
  const [initialSnapshot] = useState(() => JSON.stringify(snapshot));
  const dirty = JSON.stringify(snapshot) !== initialSnapshot;
  // [취소] · Esc — 고친 것이 있으면 버릴지 묻는다 (TODO 211 ①)
  const cancel = () => {
    if (busy || confirmDiscard(dirty)) onCancel();
  };
  // 시작 > 마감 — 서버 422 전에 화면에서 (TODO 212)
  const dateProblem = dateOrderProblem(form.start_date, form.due_date, "시작일", "마감일");

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (dateProblem) return;
    setBusy(true);
    setError(null);
    try {
      await onSubmit({
        title: form.title.trim(),
        status: form.status,
        type: form.type || null,
        group: form.group.trim() || null,
        owners: form.owners
          .split(",")
          .map((name) => name.trim())
          .filter(Boolean),
        start_date: form.start_date || null,
        due_date: form.due_date || null,
        // 완료 상태가 아니면 완료일을 보내지 않는다 — 서버가 비운다 (TODO 104).
        ...(form.status === "done" ? { completed_at: form.completed_at || null } : {}),
        effect_expected: effect(form.effect_expected),
        effect_verified: effect(form.effect_verified),
        no_report: noReport,
        no_effect: noEffect,
        nature: classes.nature || null,
        category: classes.category || null,
        delivery: classes.delivery || null,
        cost_kind: classes.cost_kind || null,
        // 칸에 적어 두고 [추가] 를 안 눌렀어도 함께 보낸다 — 번호만(서버도 번호만 쓴다). [] 이면 모두 끊는다.
        predecessors: [
          ...predecessors,
          ...(predecessorInput.trim() && !predecessors.includes(predecessorInput.trim().split(/\s+/)[0])
            ? [predecessorInput.trim().split(/\s+/)[0]]
            : []),
        ],
        // 팀 이름이 빈 줄은 보내지 않는다. 사람 이름을 나누는 일은 **서버가** 한다 (TODO 74).
        partners: partners
          .filter((row) => row.team.trim())
          .map((row) => ({ team: row.team.trim(), people: row.people })) as unknown as Partner[],
        tags: form.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean),
      });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      className="project-form"
      onSubmit={handleSubmit}
      onKeyDown={(event) => {
        // Esc = [취소] (TODO 211 ①). 자동완성 목록이 열려 있으면 브라우저가 먼저 닫는다
        if (event.key === "Escape" && !event.defaultPrevented) {
          event.preventDefault();
          cancel();
        }
      }}
    >
      <label>
        과제명
        <input
          value={form.title}
          onChange={(event) => update("title", event.target.value)}
          required
          autoFocus
        />
      </label>
      <div className="form-row">
        <label>
          상태
          <select value={form.status} onChange={(event) => update("status", event.target.value)}>
            {meta.statuses.map((status) => (
              <option key={status.key} value={status.key}>
                {status.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          속성
          <select value={form.type ?? ""} onChange={(event) => update("type", event.target.value)}>
            <option value="">선택 안 함</option>
            {meta.types.map((type) => (
              <option key={type.key} value={type.key}>
                {type.label}
              </option>
            ))}
          </select>
        </label>
        <div className="label-like predecessor-field">
          <span>선행 과제 (다년도 과제의 앞 단계 — 여럿이면 하나씩 추가)</span>
          <div className="predecessor-chips">
            {predecessors.map((id) => (
              <span key={id} className="chip predecessor-chip">
                {id} {projectOptions.find((option) => option.id === id)?.title ?? ""}
                <button
                  type="button"
                  className="ghost small"
                  aria-label={`${id} 빼기`}
                  onClick={() => setPredecessors((prev) => prev.filter((item) => item !== id))}
                >
                  ×
                </button>
              </span>
            ))}
            <input
              list="predecessor-options"
              value={predecessorInput}
              onChange={(event) => {
                const value = event.target.value;
                // 목록에서 고르면 바로 칩으로
                if (projectOptions.some((option) => option.id === value.trim())) addPredecessor(value);
                else setPredecessorInput(value);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  addPredecessor(predecessorInput);
                }
              }}
              placeholder={predecessors.length ? "더 이을 과제 번호" : "예: 2025-003 — 1단계면 비워 둡니다"}
              aria-label="선행 과제 번호"
            />
            <datalist id="predecessor-options">
              {projectOptions
                .filter((option) => !predecessors.includes(option.id))
                .map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.title}
                  </option>
                ))}
            </datalist>
          </div>
        </div>
        <label>
          그룹 (예 : 회의체, 지시사항 등)
          <input
            list="group-options"
            value={form.group ?? ""}
            onChange={(event) => update("group", event.target.value)}
            placeholder="예: 회의체"
          />
          <datalist id="group-options">
            {meta.groups.map((group) => (
              <option key={group} value={group} />
            ))}
          </datalist>
        </label>
        <label>
          담당자 (여러 명은 쉼표로)
          <input
            list="owner-options"
            value={form.owners}
            onChange={(event) => update("owners", event.target.value)}
            placeholder="예: 권경락, 홍길동"
          />
          <datalist id="owner-options">
            {ownerOptions.map((name) => (
              <option key={name} value={name} />
            ))}
          </datalist>
          <UnknownOwners
            known={meta.people}
            value={form.owners}
            onAdded={onMetaChange}
          />
        </label>
      </div>
      {/* ── 과제 분류 넷 (TODO 136) ─────────────────────────────────────
          스마트과제일 때만 선다. 다른 속성에 이미 값이 있으면(예전에 적어 둔 것) 그대로 보인다. */}
      {(form.type === meta.classified_type || Object.values(classes).some(Boolean)) && (
        <div className="form-row class-row">
          {meta.classifications.map((info) => (
            <ClassSelect
              key={info.key}
              info={info}
              value={classes[info.key]}
              onChange={(value) => setClasses((prev) => ({ ...prev, [info.key]: value }))}
            />
          ))}
        </div>
      )}
      {creating && form.type === meta.classified_type && (
        <p className="hint intake-hint">
          스마트과제는 <a href="#/intakes">접수</a>에서 승격해 만들 수도 있습니다 — 접수 번호와 인터뷰 기록이 과제에
          함께 이어집니다. 급한 건은 여기서 바로 만들어도 됩니다.
        </p>
      )}
      {/* ── 유관부서 (TODO 92) ────────────────────────────────────────
          두 팀 이상이 함께 하고, 팀마다 담당자가 여럿인 일이 흔하다.
          팀은 줄로, 사람은 그 줄 안에서 쉼표로 나눈다. */}
      <div className="partner-field">
        <div className="partner-head">
          <span>유관부서</span>
          <span className="hint">함께 일하는 팀과 그쪽 담당자입니다. 담당자는 나중에 채워도 됩니다.</span>
        </div>
        {partners.length > 0 && (
          <ul className="partner-rows">
            {partners.map((row, index) => (
              <li key={index}>
                <input
                  list="partner-team-options"
                  value={row.team}
                  onChange={(event) => setPartner(index, "team", event.target.value)}
                  placeholder="부서 (예: 설비기술팀)"
                  aria-label={`유관부서 ${index + 1} 부서명`}
                />
                <input
                  list="partner-person-options"
                  value={row.people}
                  onChange={(event) => setPartner(index, "people", event.target.value)}
                  placeholder="담당자 (여러 명은 쉼표로)"
                  aria-label={`유관부서 ${index + 1} 담당자`}
                />
                <button
                  type="button"
                  className="ghost small danger"
                  onClick={() => setPartners((prev) => prev.filter((_, i) => i !== index))}
                >
                  삭제
                </button>
              </li>
            ))}
          </ul>
        )}
        <button data-write
          type="button"
          className="ghost small"
          onClick={() => setPartners((prev) => [...prev, { team: "", people: "" }])}
        >
          + 부서 추가
        </button>
        <datalist id="partner-team-options">
          {meta.partner_teams?.map((team) => (
            <option key={team} value={team} />
          ))}
        </datalist>
        <datalist id="partner-person-options">
          {meta.partner_people?.map((name) => (
            <option key={name} value={name} />
          ))}
        </datalist>
      </div>

      <div className="form-row">
        <label>
          시작일
          <input
            type="date"
            value={form.start_date ?? ""}
            onChange={(event) => update("start_date", event.target.value)}
          />
        </label>
        <label>
          마감일
          <input
            type="date"
            value={form.due_date ?? ""}
            onChange={(event) => update("due_date", event.target.value)}
            aria-invalid={dateProblem ? true : undefined}
          />
          {dateProblem && <span className="form-warn date-warn">{dateProblem}</span>}
        </label>
        {/* 완료일 (TODO 104) — 상태가 완료일 때만 선다. 비워 두면 오늘로 남는다.
            지난 과제를 뒤늦게 넣을 때는 여기서 실제 끝난 날을 적는다. */}
        {form.status === "done" && (
          <label>
            완료일
            <input
              type="date"
              value={form.completed_at ?? ""}
              onChange={(event) => update("completed_at", event.target.value)}
            />
            <span className="hint">비워 두면 오늘 날짜로 남습니다</span>
          </label>
        )}

        <label>
          태그(예 : 공정, 쉼표 구분)
          <input
            value={form.tags}
            onChange={(event) => update("tags", event.target.value)}
            placeholder="예: 공정, 수명평가"
          />
          <TagSuggestions
            known={meta.tags}
            value={form.tags}
            onPick={(next) => update("tags", next)}
          />
        </label>
      </div>
      {/* 번호의 연도는 등록한 날이 아니라 **착수년도**다 (TODO 95).
          적어 두기보다 붙을 번호를 그대로 보여 주는 편이 확실하다. */}
      {creating && (
        <p className="hint next-id-hint">
          과제 번호는 <b>시작일의 연도</b>로 붙습니다
          {nextId && (
            <>
              {" "}— 지금 저장하면 <b className="next-id">{nextId}</b>
            </>
          )}
          .{!form.start_date && " 시작일을 비워 두면 올해로 붙습니다."}
        </p>
      )}
      <div className="form-row">
        <label>
          기대효과 (억원/년)
          <input
            type="number"
            step="0.01"
            min="0"
            value={form.effect_expected}
            onChange={(event) => update("effect_expected", event.target.value)}
            placeholder="예: 1.2"
          />
        </label>
        <label>
          실증효과 (억원/년)
          <input
            type="number"
            step="0.01"
            min="0"
            value={form.effect_verified}
            onChange={(event) => update("effect_verified", event.target.value)}
            placeholder="과제가 끝난 뒤 채웁니다"
          />
          {/* 완료로 바꾸는 순간 한 번 묻는다 (TODO 106-C). 막지는 않는다 — 아직 모를 수 있다. */}
          {form.status === "done" && form.effect_verified.trim() === "" && (
            <span className="hint warn-text">
              완료 과제입니다. 실증효과를 적어 두면 홈의 실증 합계에 잡힙니다. (모르면 비워 두어도 됩니다)
            </span>
          )}
        </label>
        <p className="hint effect-hint">
          <b>소수점 둘째 자리까지</b> 적을 수 있습니다 (억원/년 단위라 둘째 자리가 100만 원).
          <br />
          정성적 효과와 산출 근거는 <b>과제 개요</b>에 적습니다.
          근거 자료(엑셀·PPT)는 개요의 [파일 첨부]로 붙일 수 있습니다.
        </p>
      </div>

      <div className="form-row">
        <label className="check-label">
          <input
            type="checkbox"
            checked={noEffect}
            onChange={(event) => setNoEffect(event.target.checked)}
          />
          <span>
            <b>효과성 관리 비대상 과제</b>
            <span className="hint">
              유지보수처럼 <b>금액으로 재지 않는</b> 과제입니다. 체크하면 홈의{" "}
              <b>[완료했는데 실증효과 미입력]</b> 에서 빠지고, 효과 금액의 분모에도 들어가지 않습니다.
              과제 자체는 그대로 관리됩니다.
            </span>
          </span>
        </label>
      </div>

      <div className="form-row">
        <label className="check-label">
          <input
            type="checkbox"
            checked={noReport}
            onChange={(event) => setNoReport(event.target.checked)}
          />
          <span>
            <b>별도 보고 불필요</b>
            <span className="hint">
              단순 현황 관리처럼 주간보고에 올리지 않는 과제입니다. 체크하면{" "}
              <b>보고 대상 후보에서 빠집니다</b> — 필요할 때 손으로 보고를 남기는 길은 그대로입니다.
            </span>
          </span>
        </label>
      </div>
      {/* 서버가 거절한 사유(항목 이름이 든 한국어)는 단추 바로 위에 — 아래 알림만으로는 어느 칸인지 놓친다 (TODO 205) */}
      {error && <p className="form-error" role="alert">{error}</p>}
      {dateProblem && <p className="hint warn-text">날짜를 고쳐야 저장할 수 있습니다.</p>}
      <div className="form-actions">
        <button type="button" className="ghost" onClick={cancel}>
          취소
        </button>
        <button type="submit" disabled={busy || Boolean(dateProblem)}>
          {busy ? "저장 중…" : submitLabel}
        </button>
      </div>
    </form>
  );
}

/** 분류 하나의 선택 상자. 목록에서 빠진 예전 값도 그대로 보인다 — 빈칸으로 바뀌면 안 된다. */
function ClassSelect({
  info,
  value,
  onChange,
}: {
  info: ClassificationInfo;
  value: string;
  onChange: (value: string) => void;
}) {
  const items = value && !info.items.includes(value) ? [...info.items, value] : info.items;
  return (
    <label>
      {info.label}
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        <option value="">선택 안 함</option>
        {items.map((item) => (
          <option key={item} value={item}>
            {item}
            {!info.items.includes(item) ? " (목록에 없음)" : ""}
          </option>
        ))}
      </select>
    </label>
  );
}
