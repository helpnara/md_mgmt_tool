import { useEffect, useRef } from "react";

/**
 * 화면 이동 — 어디서 왔는지와 무엇을 걸러 놨는지를 **주소가 기억한다.**
 *
 * 과제 상세로 들어오는 길은 다섯이다 (메인·보고 대상·보고 이력·검색·과제 목록).
 * 그런데 나가는 길은 "과제 목록" 하나뿐이라, 보고 이력에서 과제를 열어 본 뒤에는
 * 메뉴를 다시 눌러 돌아가야 했다.
 *
 * 클릭 이력을 따로 들고 있는 방법도 있지만 쓰지 않는다. 기억과 주소가 따로 놀기
 * 시작하면 새로고침·주소 복사·탭 두 개에서 어긋나고, 그때 나는 오류는 재현이 안 된다.
 * 대신 **온 곳을 주소에 실어 보낸다.** 기억할 것이 없으면 어긋날 것도 없다.
 *
 * 거른 조건도 같은 이유로 주소에 둔다. 되돌아왔을 때 조건이 그대로 살아 있고,
 * 덤으로 자주 보는 조건을 즐겨찾기해 둘 수 있다.
 */

/** 되돌아갈 곳을 담는 주소 칸. */
export const BACK_PARAM = "back";

/**
 * 홈에서 왔다는 표시 (TODO 127).
 *
 * 홈의 주소는 `#/` 라 `currentLocation()` 이 **빈 글자**를 돌려준다. 그것을 그대로 실으면
 * "온 곳을 모른다"(빈 값)와 구분되지 않아 홈으로 돌아갈 수 없었다. 이름을 따로 준다.
 */
export const HOME_BACK = "home";

const LABELS: Record<string, string> = {
  "": "홈",
  [HOME_BACK]: "홈",
  projects: "과제 목록",
  reports: "보고 대상",
  history: "보고 이력",
  roadmap: "로드맵",
  skills: "팀원 역량",
  search: "검색 결과",
  help: "도움말",
  // 과제 접수 풀 (TODO 136)
  intakes: "접수",
};

/** 지금 주소에서 `#/` 를 뗀 부분. 되돌아갈 곳으로 그대로 쓴다. */
export function currentLocation(): string {
  return window.location.hash.replace(/^#\/?/, "");
}

/**
 * 지금 화면을 `back` 에 실을 때 쓸 값. 홈이면 빈 글자가 아니라 `home` 이다 (TODO 127).
 *
 * 이미 과제 상세에 있으면 **그 화면의 back 을 그대로 물려준다** — 그러지 않으면
 * 상세 → 상세로 이어질 때 되돌아갈 곳이 상세 자신이 되어 제자리를 맴돈다.
 */
export function backValue(): string {
  const here = currentLocation();
  if (here.split("?")[0].startsWith("projects/")) {
    return queryOf(here).get(BACK_PARAM) ?? "";
  }
  // 홈의 기준 연도 · 기간도 주소에 있다 (TODO 210 ④) — `?year=2025` 만 실으면 "온 곳 모름" 과 섞이므로 `home?…` 으로
  if (here.split("?")[0].replace(/\/$/, "") === "") {
    const query = here.split("?")[1] ?? "";
    return query ? `${HOME_BACK}?${query}` : HOME_BACK;
  }
  return here;
}

/** 주소의 물음표 뒷부분. */
export function queryOf(location: string): URLSearchParams {
  return new URLSearchParams(location.split("?")[1] ?? "");
}

/**
 * 과제 상세로 가는 주소. 지금 화면을 `back` 에 실어 보낸다.
 *
 * 이미 상세 화면에 있을 때(보고 문서 열기 등)는 **그 화면의 back 을 그대로 물려준다.**
 * 그러지 않으면 상세 → 상세로 이어질 때 되돌아갈 곳이 상세 자신이 되어 제자리를 맴돈다.
 */
export function projectLink(projectId: string, extra?: Record<string, string | number | undefined>): string {
  const back = backValue();

  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(extra ?? {})) {
    if (value !== undefined && value !== "") params.set(key, String(value));
  }
  if (back) params.set(BACK_PARAM, back);
  const query = params.toString();
  return `#/projects/${projectId}${query ? `?${query}` : ""}`;
}

/**
 * 어느 화면으로든 가는 주소 (TODO 127 · 128).
 *
 * **`projectLink` 와 같은 규칙으로 `back` 을 싣는다.** 예전에는 홈과 과제 상세가 각자
 * 같은 함수를 따로 들고 있었고 둘 다 온 곳을 안 실었다 — 그래서 홈에서 숫자를 누르면
 * 화면은 제대로 걸러지는데 돌아올 길이 없었다. 주소를 만드는 자리를 하나로 모아 두면
 * 다음에 링크를 붙일 때 저절로 따라온다.
 */
export function screenLink(
  screen: string,
  params: Record<string, string | number | undefined> = {},
): string {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== "") query.set(key, String(value));
  }
  const back = backValue();
  // 같은 화면 안에서 조건만 바뀌는 경우는 온 곳을 덮어쓰지 않는다 — 덮어쓰면
  // 되돌아갈 곳이 자기 자신이 되어 제자리를 맴돈다.
  if (back && back.split("?")[0].replace(/\/$/, "") !== screen) {
    query.set(BACK_PARAM, back);
  } else {
    const inherited = queryOf(currentLocation()).get(BACK_PARAM);
    if (inherited) query.set(BACK_PARAM, inherited);
  }
  const text = query.toString();
  return `#/${screen}${text ? `?${text}` : ""}`;
}

/**
 * 과제 상세에서 그 과제의 접수 건으로 가는 주소 (TODO 136).
 *
 * `screenLink` 는 과제 상세에서 떠날 때 상세가 물려받은 back 을 넘긴다. 그러면 승격 직후
 * (back = 그 접수 건) 과제 → 접수로 갔을 때 되돌아갈 곳이 접수 자신이 되어 제자리를 맴돈다.
 * 접수 건은 과제의 **곁가지**이므로 되돌아갈 곳은 지금 보던 과제다.
 */
export function intakeBackLink(intakeId: string): string {
  const query = new URLSearchParams({ [BACK_PARAM]: currentLocation() });
  return `#/intakes/${encodeURIComponent(intakeId)}?${query.toString()}`;
}

/** 과제 목록으로 가는 주소 — 가장 많이 쓰는 길이라 이름을 따로 둔다. */
export function listLink(params: Record<string, string | number | undefined> = {}): string {
  return screenLink("projects", params);
}

/** 뒤로 가기가 가리킬 곳과 거기에 쓸 문구. */
export function backTarget(back: string | null | undefined): { href: string; label: string } {
  // 어디서 왔는지 모르면 과제 목록으로 보낸다. 홈이 아니라 목록인 이유는,
  // 과제 상세를 여는 길이 대부분 목록이기 때문이다.
  if (!back) return { href: "#/projects", label: "과제 목록" };
  const path = back.split("?")[0].replace(/\/$/, "");
  // 홈은 주소가 `#/` 라 이름을 따로 쓴다 (TODO 127). 연도 · 기간이 실려 있으면 그대로 되살린다 (TODO 210 ④)
  if (path === HOME_BACK || path === "") {
    const query = back.split("?")[1] ?? "";
    return { href: query ? `#/?${query}` : "#/", label: "홈" };
  }
  // 과제 상세에서 온 경우 — 유관부서 링크처럼 상세에서 목록으로 가는 길이 있다.
  if (path.startsWith("projects/")) return { href: `#/${back}`, label: "과제" };
  // 사람별 이력에서 온 경우 (TODO 238) — 그 사람의 과제를 열었다가 돌아간다
  if (path.startsWith("person/")) return { href: `#/${back}`, label: "이력" };
  // 접수 상세에서 온 경우 (TODO 136) — 승격된 과제나 병합 대상 과제를 열었다가 돌아간다.
  if (path.startsWith("intakes/")) return { href: `#/${back}`, label: "접수" };
  const label = LABELS[path];
  // 아는 화면이 아니면(주소를 손으로 고쳤다든가) 안전하게 과제 목록으로 보낸다.
  if (label === undefined) return { href: "#/projects", label: "과제 목록" };
  return { href: `#/${back}`, label };
}

function buildQuery(values: Record<string, string>): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value) params.set(key, value);
  }
  return params.toString();
}

/**
 * 거른 조건을 주소에 반영한다.
 *
 * `replaceState` 를 쓰는 이유: 조건을 하나 고를 때마다 방문 기록이 쌓이면
 * 브라우저 뒤로가기를 열 번 눌러야 이전 화면으로 나가게 된다. 조건 바꾸기는
 * "이동"이 아니라 "지금 화면을 다듬는 일"이므로 기록을 남기지 않는다.
 */
export function syncQuery(screen: string, values: Record<string, string>): void {
  const query = buildQuery(values);
  const next = `#/${screen}${query ? `?${query}` : ""}`;
  if (window.location.hash !== next) {
    // 기록 칸의 차례 번호(App 의 history.state.idx)는 그대로 둔다 — 지우면 "머물기" 가 방향을 잃는다 (TODO 210 ⑥)
    window.history.replaceState(window.history.state, "", next);
  }
}

/**
 * 화면의 조건과 주소를 양쪽으로 맞춘다.
 *
 * 나가는 쪽: 조건이 바뀌면 주소에 적는다.
 * 들어오는 쪽: **우리가 적지 않은 주소 변화**(상단 메뉴를 눌렀다든가)면 조건을 그리로 맞춘다.
 *   이게 없으면 `#/?status=done` 에서 [과제] 메뉴를 눌렀을 때 주소는 `#/` 인데
 *   목록은 여전히 걸러진 채로 남아, 주소가 화면을 속이게 된다.
 */
export function useAddressBar(
  screen: string,
  values: Record<string, string>,
  onAddressChanged: (params: URLSearchParams) => void,
): void {
  const written = useRef<string | null>(null);
  const handler = useRef(onAddressChanged);
  handler.current = onAddressChanged;
  const signature = JSON.stringify(values);

  useEffect(() => {
    written.current = buildQuery(values);
    syncQuery(screen, values);
    // values 는 매번 새 객체라 내용(signature)으로 비교한다.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, signature]);

  // 들어오는 쪽은 **주소를 직접 읽는다.**
  //
  // 화면 위쪽에서 넘겨주는 값을 믿으면 안 된다. 조건을 바꿀 때 쓰는 replaceState 는
  // hashchange 를 일으키지 않아, 위쪽이 기억하는 주소가 실제 주소보다 뒤처져 있다.
  // 그 상태로 비교하면 "메뉴를 눌러 조건 없는 주소로 왔다"를 알아채지 못한다.
  useEffect(() => {
    const onHashChange = () => {
      const here = currentLocation();
      // 다른 화면으로 떠나는 중이면 이 화면의 조건을 건드릴 이유가 없다.
      if (here.split("?")[0].replace(/\/$/, "") !== screen) return;
      const params = queryOf(here);
      if (written.current !== null && buildQuery(Object.fromEntries(params)) !== written.current) {
        handler.current(params);
      }
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, [screen]);
}


/** 메뉴 화면의 브라우저 탭 제목 (TODO 169). 탭 이름과 같다. */
export const SCREEN_TITLES: Record<string, string> = {
  home: "홈",
  intakes: "접수",
  list: "과제목록",
  reports: "보고대상",
  history: "보고이력",
  roadmap: "로드맵",
  skills: "팀원역량",
  settings: "설정",
  help: "도움말",
  search: "검색",
  person: "이력",
};

/** 브라우저 탭 제목 — 과제 · 접수를 여러 탭으로 열어도 구분되게 (TODO 169). */
export function setPageTitle(text: string): void {
  document.title = text ? `${text} · 느린 나이테` : "느린 나이테";
}

/**
 * 사람별 이력 화면의 주소 (TODO 238) — 온 곳을 실어 [← 돌아가기] 가 그리로.
 *
 * 과제 상세에서 열면 **그 과제**가 돌아갈 곳이다. `backValue()` 는 상세 → 상세를 위해 상세가 물려받은 back 을 주므로
 * (과제 목록 등) 여기서는 쓰지 않는다 — 접수 링크(`intakeBackLink`)와 같은 까닭이다.
 */
export function personLink(name: string): string {
  const path = `person/${encodeURIComponent(name)}`;
  const here = currentLocation().split("?")[0];
  if (here.startsWith("projects/")) return `#/${path}?${new URLSearchParams({ [BACK_PARAM]: here }).toString()}`;
  return screenLink(path);
}
