"""홈(첫 화면) 집계 (TODO 56 · ROADMAP R1).

대시보드가 **"지금 무엇을 봐야 하는가"** 라면, 홈은 **"우리 팀이 올해 무엇을 했는가"** 다.
목적이 다르므로 한 함수에 담지 않는다 — 대시보드는 지표를 늘리지 않기로 한 자리다.

**연도 기준이 둘이라는 점을 기억한다.**

| 무엇 | 기준 | 왜 |
|---|---|---|
| 과제 수 · 상태 | **수행기간이 그 해와 겹치는 과제**(TODO 181, `period`) — 다년도 과제는 해마다 하나씩 | 대시보드·목록과 같은 기준이어야 수가 어긋나지 않는다 (DESIGN 5.8) |
| 효과 금액 | **끝나는 해**(완료년도, 아니면 마감년도) — 기대 · 실증을 같은 해에 | 해마다 겹쳐 세지 않게. 계획 대비 실적을 그 해에 맞춰 본다 (181) |
| 신규 | **과제 번호 앞 네 자리**(착수년도) | 그 해에 새로 시작한 과제 (181) |
| 보고 횟수 | **보고일(`report_date`)의 연도** | "올해 몇 번 보고했나"는 보고한 날로 세는 것이 자연스럽다 |

둘을 억지로 하나로 맞추면 어느 한쪽이 이상해진다. 대신 **화면이 이 사실을 글자로 밝힌다.**

**보고 횟수는 확정된 보고만 센다.** 초안은 아직 보고한 것이 아니다.

**담당자별 수의 합은 팀 합계보다 클 수 있다.** 한 과제에 담당자가 여럿이면 양쪽에 잡힌다.
효과 금액에서 특히 위험해서(사람별로 더하면 팀 합계를 넘는다) 팀 합계는 **과제 기준**으로
따로 내고, 화면은 사람별 표에 "담당 중복 포함" 이라고 적는다.
"""
from __future__ import annotations

import sqlite3
from datetime import date as date_cls

from .. import clock
from ..config import CLASSIFICATION_KEYS, CLASSIFIED_TYPE, FINISHED_STATUSES, STATUS_KEYS, STATUSES
from . import intakes as intakes_service
from . import period as period_service
from . import reports as reports_service
from . import settings as settings_service

# 연도 비교 막대에 세우는 해의 수. 더 늘리면 막대가 얇아지기만 한다.
COMPARE_YEARS = 5
# "오래 방치된 과제" 로 보여 줄 수. 셋을 넘으면 목록이지 요약이 아니다.
STALE_LIMIT = 3

_DONE = "done"


def _by_status(rows: list[sqlite3.Row], key: str) -> dict[str, dict[str, int]]:
    """`[{key, status, n}, …]` → `{key: {status: n}}`.

    팀원별과 속성별이 **같은 함수를 쓴다.** 따로 짜면 언젠가 한쪽만 고치게 되고,
    같은 화면의 두 표가 다르게 세기 시작한다 (TODO 75).
    """
    out: dict[str, dict[str, int]] = {}
    for row in rows:
        out.setdefault(row[key], {})[row["status"]] = row["n"]
    return out


def _full(counts: dict[str, int] | None) -> dict[str, int]:
    """상태 여섯 칸을 모두 채운다. **0 이라고 빼지 않는다.**

    이 표들은 줄끼리 세로로 견주는 자리라, 칸이 줄마다 달라지면 비교가 안 된다.
    (대시보드는 반대로 0인 칩을 보내지 않는다 — 거기서는 누를 것 없는 칩이 늘 뿐이다)
    """
    counts = counts or {}
    return {key: counts.get(key, 0) for key in STATUS_KEYS}


def _year_clause(year: str | None, alias: str = "p") -> tuple[str, list]:
    """과제 연도 조건 — 수행기간이 그 해와 겹치는 과제 (TODO 181, `period` 하나가 정한다)."""
    return period_service.overlap(year, alias)


def years(conn: sqlite3.Connection) -> list[str]:
    """고를 수 있는 해 — 수행기간이 걸친 해 전부. 최근 것부터 (TODO 181)."""
    return period_service.years(conn)


def _team(conn: sqlite3.Connection, year: str | None, period: str | None = None) -> dict:
    # 그 해의 과제 · 그 해의 상태 · 그 해에 세는 효과 금액 (TODO 181)
    source, params = period_service.scope(year)
    row = conn.execute(
        "SELECT COUNT(*) AS total,"
        f"       SUM(CASE WHEN y_status = '{_DONE}' THEN 1 ELSE 0 END) AS done,"
        "       SUM(CASE WHEN y_status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,"
        "       SUM(y_new) AS new_count,"
        "       COALESCE(SUM(y_ee), 0) AS effect_expected,"
        "       COALESCE(SUM(y_ev), 0) AS effect_verified,"
        "       SUM(CASE WHEN COALESCE(y_ee, 0) > 0 THEN 1 ELSE 0 END) AS ee_n,"
        "       SUM(CASE WHEN COALESCE(y_ev, 0) > 0 THEN 1 ELSE 0 END) AS ev_n,"
        # 실증 합계 가운데 진행중 과제의 중간 결산 (TODO 217) — 완료 결산과 섞여도 얼마가 중간 값인지 읽히게
        f"       COALESCE(SUM(CASE WHEN y_status <> '{_DONE}' THEN y_ev END), 0) AS ev_interim,"
        f"       SUM(CASE WHEN y_status <> '{_DONE}' AND COALESCE(y_ev, 0) > 0 THEN 1 ELSE 0 END) AS ev_interim_n,"
        # 완료했는데 실증효과를 안 적은 과제 (TODO 106-C). 홈이 세어 두어야 연말에 빈칸을 만난다.
        # **효과성 관리 비대상은 뺀다** (TODO 125) — 금액으로 재지 않는 과제가 여기 계속
        # 남으면 숫자가 줄지 않고, 줄지 않는 경고는 곧 안 보게 된다.
        f"       SUM(CASE WHEN y_status = '{_DONE}' AND no_effect = 0"
        "             AND COALESCE(effect_verified, 0) <= 0 THEN 1 ELSE 0 END) AS done_unverified,"
        # 효과 금액으로 관리하는 과제 수 — 분모를 "전체" 라고 적으면 비대상까지 센 것처럼 읽힌다.
        "       SUM(CASE WHEN no_effect = 0 THEN 1 ELSE 0 END) AS managed_n"
        f" FROM {source}",
        params,
    ).fetchone()
    return {
        "total": row["total"] or 0,
        "done": row["done"] or 0,
        "in_progress": row["in_progress"] or 0,
        # 그 해에 새로 착수한 과제 — 번호의 연도 (TODO 181). 연도를 고르지 않으면 0.
        "new": row["new_count"] or 0,
        "effect_expected": round(row["effect_expected"] or 0, 2),
        "effect_verified": round(row["effect_verified"] or 0, 2),
        # 효과 금액에는 **분모를 함께 보낸다** (TODO 86). 기대와 실증을 화살표로 잇기만 하면
        # "42.9 중 10.5 달성 = 24%" 로 읽히는데, 실증은 끝난 과제에서만 나오므로 그 비율은
        # 성립하지 않는다. 몇 건에서 나온 값인지 밝히면 오해가 생기지 않는다.
        "effect_expected_projects": row["ee_n"] or 0,
        "effect_verified_projects": row["ev_n"] or 0,
        # 그중 진행중(그 해의 상태) 과제의 중간 결산 — 금액과 건수 (TODO 217)
        "effect_verified_interim": round(row["ev_interim"] or 0, 2),
        "effect_verified_interim_projects": row["ev_interim_n"] or 0,
        "done_unverified": row["done_unverified"] or 0,
        # 효과 금액으로 관리하는 과제 수 (TODO 125). total 과 같으면 비대상이 없다는 뜻이다.
        "effect_managed": row["managed_n"] or 0,
        "reports": _report_count(conn, year, period=period),
        # 완료일 기준 (TODO 104). 위의 done 은 **번호의 연도**로 세어, 지난해 시작해 올해
        # 끝낸 과제가 올해 성과에 잡히지 않는다. 어느 쪽이 "성과" 인지는 사용자가 정할
        # 일이라 둘을 나란히 준다. 연도가 없으면(전체) 완료일이 적힌 것 전부.
        "done_in_year": _done_in_year(conn, year, period),
    }


def _done_in_year(conn: sqlite3.Connection, year: str | None, period: str | None = None) -> int:
    sql = "SELECT COUNT(*) AS n FROM project WHERE completed_at IS NOT NULL AND status = ?"
    params: list = [_DONE]
    clause, more = _date_clause("completed_at", year, period)
    sql += clause
    params.extend(more)
    return conn.execute(sql, params).fetchone()["n"]


# ── 기간 (TODO 110) ────────────────────────────────────────────────────────
#
# 분기 실적·상반기 보고는 연도로 안 된다. 다만 **자를 수 있는 것만 자른다** — 보고 횟수
# (보고일)·끝낸 과제(완료일)·역량 이력(활동일)처럼 날짜가 있는 수치다. 과제 수·효과 금액은
# 번호의 연도에 매여 있어 분기로 나눌 수 없고, 화면이 그 사실을 적는다.

PERIODS = {
    "H1": ("01-01", "06-30"),
    "H2": ("07-01", "12-31"),
    "Q1": ("01-01", "03-31"),
    "Q2": ("04-01", "06-30"),
    "Q3": ("07-01", "09-30"),
    "Q4": ("10-01", "12-31"),
}


def _date_range(year: str | None, period: str | None) -> tuple[str, str] | None:
    """연도와 기간을 날짜 구간으로. 연도가 없으면 기간도 없다 — 어느 해의 1분기인지 모른다."""
    if not year:
        return None
    if period in PERIODS:
        start, end = PERIODS[period]
        return f"{year}-{start}", f"{year}-{end}"
    return f"{year}-01-01", f"{year}-12-31"


def _date_clause(column: str, year: str | None, period: str | None) -> tuple[str, list]:
    span = _date_range(year, period)
    if span is None:
        return "", []
    return f" AND {column} BETWEEN ? AND ?", list(span)


def _report_count(
    conn: sqlite3.Connection, year: str | None, owner: str | None = None, period: str | None = None
) -> int:
    """확정된 보고의 수. 연도는 **보고일** 기준이다. 기간을 주면 그 안만 (TODO 110)."""
    sql = "SELECT COUNT(*) AS n FROM report r WHERE r.frozen_at IS NOT NULL"
    clause, params = _date_clause("r.report_date", year, period)
    sql += clause
    if owner is not None:
        sql += " AND EXISTS (SELECT 1 FROM project_owner po WHERE po.project_id = r.project_id AND po.name = ?)"
        params.append(owner)
    return conn.execute(sql, params).fetchone()["n"]


def _activity_counts(conn: sqlite3.Connection, year: str | None, period: str | None = None) -> dict[str, int]:
    """사람별 역량 이력 건수. **연도는 활동한 날** 기준이다 (TODO 89).

    면담 준비를 한 화면에서 끝내기 위한 것이다 — 지금까지는 홈(과제 성과)과
    팀원 역량 두 화면을 오가야 "이 사람이 올해 무엇을 맡았고 무엇을 배웠나"가 나왔다.
    """
    sql = "SELECT person, COUNT(*) AS n FROM activity WHERE 1=1"
    clause, params = _date_clause("date", year, period)
    sql += clause
    return {row["person"]: row["n"] for row in conn.execute(sql + " GROUP BY person", params)}


def _members(conn: sqlite3.Connection, year: str | None, period: str | None = None) -> list[dict]:
    """팀원별 성과. 사용자가 정한 네 가지 — 담당 건수 · 완료 · 효과 금액 · 보고 횟수.

    여기에 **역량 이력 건수**를 한 칸 더 붙였다 (TODO 89).
    """
    source, params = period_service.scope(year)
    activities = _activity_counts(conn, year, period)
    rows = conn.execute(
        "SELECT po.name AS name, COUNT(*) AS total,"
        "       COALESCE(SUM(p.y_ee), 0) AS effect_expected,"
        "       COALESCE(SUM(p.y_ev), 0) AS effect_verified"
        f" FROM project_owner po JOIN {source} ON p.id = po.project_id"
        " GROUP BY po.name",
        params,
    ).fetchall()
    statuses = _by_status(
        conn.execute(
            "SELECT po.name AS name, p.y_status AS status, COUNT(*) AS n"
            f" FROM project_owner po JOIN {source} ON p.id = po.project_id"
            " GROUP BY po.name, p.y_status",
            params,
        ).fetchall(),
        "name",
    )

    members = []
    for row in rows:
        last = conn.execute(
            "SELECT MAX(r.report_date) AS d FROM report r"
            " JOIN project_owner po ON po.project_id = r.project_id"
            " WHERE po.name = ? AND r.frozen_at IS NOT NULL",
            (row["name"],),
        ).fetchone()["d"]
        by_status = _full(statuses.get(row["name"]))
        members.append(
            {
                "name": row["name"],
                "total": row["total"],
                # 상태 여섯 칸. 합은 total 과 같다.
                "by_status": by_status,
                "done": by_status[_DONE],
                "in_progress": by_status["in_progress"],
                "effect_expected": round(row["effect_expected"] or 0, 2),
                "effect_verified": round(row["effect_verified"] or 0, 2),
                "reports": _report_count(conn, year, owner=row["name"], period=period),
                # 과제가 아니라 사람에게 쌓인 것. 0 이면 그 자체가 면담 이야깃거리다.
                "activities": activities.get(row["name"], 0),
                # 마지막 보고는 연도를 걸지 않는다 — "이 사람이 마지막으로 보고한 때"가
                # 궁금한 것이지 "올해 안에서 마지막"이 궁금한 것이 아니다.
                "last_reported_at": last,
            }
        )
    members.sort(key=lambda item: (-item["total"], item["name"]))
    return members


def _types(conn: sqlite3.Connection, year: str | None) -> list[dict]:
    """속성별 과제 수와 효과 금액. 상부 보고에서 자주 요구되는 절단면이다."""
    source, params = period_service.scope(year)
    rows = {
        (row["type"] or ""): row
        for row in conn.execute(
            "SELECT type, COUNT(*) AS n,"
            "       COALESCE(SUM(y_ee), 0) AS ee,"
            "       COALESCE(SUM(y_ev), 0) AS ev"
            f" FROM {source} GROUP BY type",
            params,
        )
    }
    statuses = _by_status(
        conn.execute(
            "SELECT COALESCE(type, '') AS type, y_status AS status, COUNT(*) AS n"
            f" FROM {source} GROUP BY type, y_status",
            params,
        ).fetchall(),
        "type",
    )
    out = []
    # 속성 목록은 설정에서 온다 — 화면·거르기·대시보드가 모두 같은 목록을 본다 (TODO 100).
    types = [(item["key"], item["label"]) for item in settings_service.project_types()]
    for key, label in [*types, ("none", "미지정")]:
        stored = "" if key == "none" else key
        row = rows.get(stored)
        if not row:
            continue
        by_status = _full(statuses.get(stored))
        out.append(
            {
                "key": key,
                "label": label,
                "count": row["n"],
                # 팀원별과 같은 모양이다. 한 화면에서 같은 것을 다르게 세지 않는다.
                "by_status": by_status,
                "done": by_status[_DONE],
                "effect_expected": round(row["ee"] or 0, 2),
                "effect_verified": round(row["ev"] or 0, 2),
            }
        )
    return out


def _groups(conn: sqlite3.Connection, year: str | None) -> list[dict]:
    """그룹별 과제 수와 효과 금액 (TODO 90).

    속성(R&D·투자…)은 과제의 *성격*이고 그룹(차세대전지·소재…)은 *주제*다.
    목록에는 그룹 필터가 있는데 홈에만 이 축이 없어서, "올해 차세대전지 쪽이 어땠나"를
    볼 자리가 없었다. 표 모양은 속성별과 같게 둔다 — 같은 화면에서 같은 것을
    다르게 세지 않기 위해서다.

    **그룹은 자유 입력이라 수가 늘 수 있다.** 화면이 접어서 보여 준다.
    """
    source, params = period_service.scope(year)
    rows = conn.execute(
        "SELECT COALESCE(NULLIF(TRIM(grp), ''), '') AS g, COUNT(*) AS n,"
        "       COALESCE(SUM(y_ee), 0) AS ee,"
        "       COALESCE(SUM(y_ev), 0) AS ev"
        f" FROM {source} GROUP BY g",
        params,
    ).fetchall()
    statuses = _by_status(
        conn.execute(
            "SELECT COALESCE(NULLIF(TRIM(grp), ''), '') AS g, y_status AS status, COUNT(*) AS n"
            f" FROM {source} GROUP BY g, y_status",
            params,
        ).fetchall(),
        "g",
    )
    out = []
    for row in rows:
        by_status = _full(statuses.get(row["g"]))
        out.append(
            {
                # 빈 그룹도 세고, 눌러서 거를 수 있게 키를 준다 (속성별과 같은 규칙).
                "key": row["g"] or "none",
                "label": row["g"] or "미지정",
                "count": row["n"],
                "by_status": by_status,
                "done": by_status[_DONE],
                "effect_expected": round(row["ee"] or 0, 2),
                "effect_verified": round(row["ev"] or 0, 2),
            }
        )
    # 많은 것부터. 이름순은 "어디가 큰가"를 묻는 자리에서 쓸모가 없다.
    # **미지정은 언제나 맨 아래.** 속성별 표와 같은 규칙이라 두 표가 같게 읽힌다.
    out.sort(key=lambda item: (item["key"] == "none", -item["count"], item["label"]))
    return out


def _classified(conn: sqlite3.Connection, year: str | None, column: str) -> list[dict]:
    """과제 분류(성격·분류)별 과제 수와 효과 금액 (TODO 136). 속성별 표와 같은 모양이다.

    **세는 곳과 거르는 곳이 같아야 한다** (DESIGN 5.8). 값이 있는 줄은 속성과 무관하게 그 값을
    가진 과제 전부를 세고, *미지정* 줄은 **분류를 쓰는 속성(스마트과제)인데 비어 있는 것**만 센다 —
    기획보고·유지보수가 미지정에 쌓이면 그 줄은 늘 가장 크고 아무 뜻이 없다.
    그래서 줄마다 목록으로 이어 줄 거르기 조건(`filter`)을 함께 보낸다.
    """
    if column not in CLASSIFICATION_KEYS:
        raise ValueError(column)
    source, params = period_service.scope(year)
    value = f"COALESCE(NULLIF(TRIM(p.{column}), ''), '')"
    scope = f"(p.type = ? OR {value} <> '')"
    rows = {
        row["v"]: row
        for row in conn.execute(
            f"SELECT {value} AS v, COUNT(*) AS n,"
            "       COALESCE(SUM(y_ee), 0) AS ee,"
            "       COALESCE(SUM(y_ev), 0) AS ev"
            f" FROM {source} WHERE {scope} GROUP BY v",
            (*params, CLASSIFIED_TYPE),
        )
    }
    statuses = _by_status(
        conn.execute(
            f"SELECT {value} AS v, y_status AS status, COUNT(*) AS n"
            f" FROM {source} WHERE {scope} GROUP BY v, y_status",
            (*params, CLASSIFIED_TYPE),
        ).fetchall(),
        "v",
    )
    listed = settings_service.classifications()[column]
    # 목록 순서 → 목록에 없는 값(예전 이름) → 미지정
    order = [*listed, *sorted(v for v in rows if v and v not in listed), ""]
    out = []
    for key in order:
        row = rows.get(key)
        if not row:
            continue
        by_status = _full(statuses.get(key))
        out.append({
            "key": key or "none",
            "label": key or "미지정",
            "listed": key in listed,
            "count": row["n"],
            "by_status": by_status,
            "done": by_status[_DONE],
            "effect_expected": round(row["ee"] or 0, 2),
            "effect_verified": round(row["ev"] or 0, 2),
            "filter": {column: key} if key else {column: "none", "type": CLASSIFIED_TYPE},
        })
    return out


def _effect_by_cost(conn: sqlite3.Connection, year: str | None) -> list[dict]:
    """기대효과를 비용구분(고정비·변동비·혼합)으로 나눠 본다 (TODO 136). 적힌 과제만."""
    source, params = period_service.scope(year)
    rows = conn.execute(
        "SELECT TRIM(cost_kind) AS k, COUNT(*) AS n,"
        "       COALESCE(SUM(y_ee), 0) AS ee,"
        "       COALESCE(SUM(y_ev), 0) AS ev"
        f" FROM {source} WHERE cost_kind IS NOT NULL AND TRIM(cost_kind) <> ''"
        " GROUP BY k",
        params,
    ).fetchall()
    listed = settings_service.classifications()["cost_kind"]
    rank = {name: index for index, name in enumerate(listed)}
    out = [
        {"key": row["k"], "count": row["n"],
         "effect_expected": round(row["ee"] or 0, 2), "effect_verified": round(row["ev"] or 0, 2)}
        for row in rows
    ]
    out.sort(key=lambda item: (rank.get(item["key"], len(rank)), item["key"]))
    return out


def _compare(conn: sqlite3.Connection) -> list[dict]:
    """최근 몇 해를 나란히. 한 해만 보면 늘고 있는지 줄고 있는지 알 수 없다."""
    return [
        {"year": year, **{k: v for k, v in _team(conn, year).items()}}
        # 아직 오지 않은 해(다년도 과제의 마감년도)는 추이에 세우지 않는다 (TODO 181)
        for year in [item for item in years(conn) if item <= str(clock.today().year)][:COMPARE_YEARS]
    ][::-1]  # 화면에는 왼쪽이 과거


def _stale(candidates: list[dict], limit: int = STALE_LIMIT) -> tuple[list[dict], int]:
    """오래 방치된 과제와 **자르기 전 수**. 보고 대상과 겹쳐 보이지만 뜻이 다르다 —
    저쪽은 *이번 주에 할 일*, 이쪽은 *이미 새어 나간 것*.

    앞의 몇 건만 세우되 전체 수를 함께 준다 (TODO 103-B). 세 건만 세워 놓고 잘렸다고
    말하지 않으면 세 건만 있는 줄 안다 — TODO 82 와 같은 결함이 같은 카드에 남아 있었다.
    """
    items = [
        item
        for item in candidates  # summary 가 한 번 센 것을 받는다 — 두 번 세지 않는다 (TODO 190)
        if not item["not_started"] and (item["days_since_report"] or 0) > 0
    ]
    return items[:limit], len(items)


# 홈에 세우는 '다음 할 일' 줄 수. 그 위는 과제 상세가 맡는다.
PLAN_LIMIT = 6


OWNER_GAP_LIMIT = 6


def _owner_gaps(conn: sqlite3.Connection) -> tuple[list[dict], int]:
    """떠난 담당자가 그대로 남아 있는 **끝나지 않은** 과제 (TODO 122).

    연도를 따르지 않는다 — 지난해 과제라도 아직 안 끝났으면 오늘 정해야 할 일이다
    (쓰다 만 보고와 같은 규칙, TODO 101).
    """
    left = {person["name"]: person for person in settings_service.left_people()}
    if not left:
        return [], 0
    marks = ",".join("?" for _ in left)
    unfinished = ",".join("?" for _ in FINISHED_STATUSES)
    rows = conn.execute(
        "SELECT p.id, p.title, p.status, po.name AS owner"
        " FROM project p JOIN project_owner po ON po.project_id = p.id"
        f" WHERE p.status NOT IN ({unfinished}) AND po.name IN ({marks})"
        " ORDER BY p.id",
        (*FINISHED_STATUSES, *left),
    ).fetchall()
    items = [
        {
            "id": row["id"],
            "title": row["title"],
            "status": row["status"],
            "owner": row["owner"],
            "left_reason": left[row["owner"]]["left_reason"],
            "left_on": left[row["owner"]]["left_on"],
        }
        for row in rows
    ]
    # 한 과제에 떠난 사람이 둘이면 줄이 둘이 된다. 건수는 **과제 수**로 센다.
    total = len({item["id"] for item in items})
    return items[:OWNER_GAP_LIMIT], total


def _plans(conn: sqlite3.Connection) -> tuple[list[dict], int]:
    """마지막 진행일지에 계획을 적어 둔 **진행 중인** 과제 (TODO 112). 최근 기록 순."""
    from .entries import PLAN_LOOKBACK, latest_plan_from_rows

    active = {key for key, _, candidate in STATUSES if candidate}
    # 과제마다 최근 기록을 따로 묻지 않는다 (TODO 190) — 과제별 최근 N건을 창 함수 한 문장으로 모아 같은 규칙으로 고른다.
    recent: dict[str, list[sqlite3.Row]] = {}
    for row in conn.execute(
        "SELECT project_id, id, date, title, body FROM ("
        "  SELECT project_id, id, date, title, body,"
        "         ROW_NUMBER() OVER (PARTITION BY project_id ORDER BY date DESC, id DESC) AS rn FROM entry)"
        " WHERE rn <= ? ORDER BY project_id, rn",
        (PLAN_LOOKBACK,),
    ):
        recent.setdefault(row["project_id"], []).append(row)
    found = []
    for project in conn.execute("SELECT id, title, status FROM project ORDER BY updated_at DESC"):
        if project["status"] not in active:
            continue
        plan = latest_plan_from_rows(recent.get(project["id"], []))
        if plan:
            found.append({
                "project_id": project["id"],
                "project_title": project["title"],
                "entry_id": plan["entry_id"],
                "date": plan["date"],
                # 첫 줄만 — 홈은 훑는 자리다. 전부는 과제 상세에서.
                "text": plan["text"].splitlines()[0],
            })
    found.sort(key=lambda item: item["date"], reverse=True)
    return found[:PLAN_LIMIT], len(found)


def summary(conn: sqlite3.Connection, year: str | None = None, period: str | None = None) -> dict:
    available = years(conn)
    if period not in PERIODS:
        period = None

    placeholders = ",".join("?" * len(FINISHED_STATUSES))
    clause, params = _year_clause(year)
    overdue = conn.execute(
        "SELECT COUNT(*) AS n FROM project p"
        " WHERE due_date IS NOT NULL AND due_date < app_today()"
        f"   AND status NOT IN ({placeholders}){clause}",
        (*FINISHED_STATUSES, *params),
    ).fetchone()["n"]
    due_soon = conn.execute(
        "SELECT COUNT(*) AS n FROM project p"
        " WHERE due_date IS NOT NULL AND due_date >= app_today()"
        "   AND due_date <= DATE(app_today(), '+7 day')"
        f"   AND status NOT IN ({placeholders}){clause}",
        (*FINISHED_STATUSES, *params),
    ).fetchone()["n"]

    candidates = reports_service.candidates(conn)
    # 쓰다 만 보고는 보고일이 지나도 사라지지 않고 조용히 쌓인다 (TODO 101).
    # 배너(TODO 91)는 보고하는 날에만 뜨므로, 지난주에 쓰다 만 것은 다음 보고일까지
    # 아무 데도 보이지 않았다. [이번 주 할 일]이 그것을 계속 들고 있는다.
    drafts = reports_service.unfinished_drafts(conn)
    stale, stale_total = _stale(candidates)
    plans, plans_total = _plans(conn)
    owner_gaps, owner_gaps_total = _owner_gaps(conn)
    return {
        "year": year,
        "period": period,
        "years": available,
        "today": clock.today().isoformat(),
        "this_week": {
            "report_date": reports_service.default_report_date(),
            "candidates": len(candidates),
            "due_soon": due_soon,
            "overdue": overdue,
            "stale": stale,
            "stale_total": stale_total,
            # 아직 확정하지 않은 보고 — 날짜를 가리지 않는다.
            # 건수는 자르기 전 수고, 목록은 앞의 몇 건이다 (TODO 82 와 같은 규칙).
            "drafts": drafts["total"],
            "drafts_overdue": drafts["overdue"],
            "draft_items": drafts["items"],
            # 마지막 진행일지에 적어 둔 계획 (TODO 112). 표시만 한다.
            "plans": plans,
            "plans_total": plans_total,
            # 떠난 담당자가 남아 있는 끝나지 않은 과제 (TODO 122). 건수는 **과제 수**다.
            "owner_gaps": owner_gaps,
            "owner_gaps_total": owner_gaps_total,
        },
        "team": _team(conn, year, period),
        "compare": _compare(conn),
        "members": _members(conn, year, period),
        "types": _types(conn, year),
        "groups": _groups(conn, year),
        # 과제 분류 넷 중 표로 세우는 둘 · 기대효과의 비용구분 (TODO 136)
        "natures": _classified(conn, year, "nature"),
        "categories": _classified(conn, year, "category"),
        "effect_by_cost": _effect_by_cost(conn, year),
        # 접수 풀 (TODO 136) — 과제 집계와 **섞지 않고** 따로 한 덩이로 보낸다
        "intakes": intakes_service.summary(conn, year),
    }


__all__ = ["summary", "years", "COMPARE_YEARS", "STALE_LIMIT"]
